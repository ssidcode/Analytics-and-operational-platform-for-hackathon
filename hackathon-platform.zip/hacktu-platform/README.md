# HackTU Analytics & Operations Platform

End-to-end data platform for a 550-participant student hackathon: a
normalised OLTP database, a star schema for analytics, a validated Python
ETL, a PySpark job for the multi-edition archive, a Slack assistant that
answers questions in natural language, and a Streamlit dashboard the
assistant links back to.

**PostgreSQL · Python · PySpark · Slack Bolt · Streamlit · Plotly · LLM agents**

![Registrations](docs/screenshots/01_registrations.png)

---

## What problem this solves

A hackathon generates a surprising amount of operational data and almost no
tooling to use it. Registrations arrive through a form export full of
duplicates and typos. Organisers want answers (*how many from Thapar? are we
over capacity on AI/ML? did the Instagram push work?*) and the only person
who can get them is whoever knows SQL — who is also the person running the
event.

This platform fixes both halves: a pipeline that makes the data
trustworthy, and an interface that lets non-technical organisers query it
from Slack, where they already are.

---

## Architecture

```
  registration export (CSV)
            │
            ▼
   ┌──────────────────┐   rejected rows ──▶ ops.rejected_registration
   │  Python ETL      │   rule failures ──▶ ops.data_quality_event
   │  extract         │   folded dupes  ──▶ ops.duplicate_registration
   │  validate (10)   │   run metrics   ──▶ ops.etl_run
   │  transform       │
   │  deduplicate     │
   │  load            │
   └────────┬─────────┘
            ▼
   ┌──────────────────┐        ┌───────────────────────────┐
   │  ops  (3NF OLTP) │───────▶│  analytics  (star schema) │
   │  participants    │ stored │  fact_registration        │
   │  teams, scores   │  procs │  fact_score               │
   │  pipeline audit  │        │  fact_pipeline_run        │
   └──────────────────┘        └─────────────┬─────────────┘
                                             │ SELECT only,
                                             │ hacktu_readonly role
                              ┌──────────────┴──────────────┐
                              ▼                             ▼
                   ┌─────────────────────┐      ┌────────────────────┐
                   │  Slack bot (Bolt)   │─────▶│  Streamlit + Plotly│
                   │  text-to-SQL agent  │ link │  registrations     │
                   │  4-layer safety     │      │  pipeline health   │
                   └─────────────────────┘      │  judging           │
                                                └────────────────────┘
  multi-edition archive (Parquet) ──▶ PySpark rollup job
```

---

## Measured results

Every number below was produced by a script in this repository, on 2 cores
and 7 GB of RAM. Re-run them with `scripts/rebuild_all.sh` and the
benchmark commands in [docs/BENCHMARKS.md](docs/BENCHMARKS.md).

### Data quality

| Metric | Value |
|---|---|
| Raw rows in the export | 624 |
| Distinct people | 550 |
| Duplicate rows folded | **71 (11.4% of intake)** |
| Dedupe recall / precision | **100% / 100%** (0 false positives) |
| Rows rejected (unusable identity) | 15 |
| Participants loaded | 538 |
| Pipeline runtime, full load | 0.61 s |

`scripts/verify_dedupe.py` scores the ETL against the generator's ground
truth. The duplicates are not just exact copies — 51 of the 71 are the same
mailbox reached by a different spelling (`Priya.Sharma@`, `priya.sharma+hacktu@`,
`priyasharma@gmail` with dots stripped), which a `SELECT DISTINCT email`
misses entirely.

### Text-to-SQL safety layer

`python -m slackbot.test_sql_guard` — **41/41 checks pass**, including all
**27 attack cases**: stacked statements, `DeLeTe` case evasion,
`SELECT … INTO`, `pg_read_file`, `dblink` exfiltration, `pg_sleep` denial of
service, `pg_catalog` and `information_schema` probing, and cross-database
references.

### Spark vs single-node

See [docs/BENCHMARKS.md](docs/BENCHMARKS.md) for the full table and the
honest conclusion about where the crossover actually is.

---

## Quick start

```bash
# 1. Postgres
sudo service postgresql start
sudo -u postgres psql -c "CREATE ROLE hacktu LOGIN PASSWORD 'hacktu_dev' SUPERUSER;"
sudo -u postgres psql -c "CREATE DATABASE hacktu OWNER hacktu;"

# 2. Python
pip install -r requirements.txt

# 3. Build everything: data, schema, ETL, 48-run history, teams, judging
./scripts/rebuild_all.sh

# 4. Dashboard
streamlit run dashboard/app.py          # http://localhost:8501

# 5. Slack bot
export SLACK_BOT_TOKEN=xoxb-...  SLACK_APP_TOKEN=xapp-...
export ANTHROPIC_API_KEY=sk-ant-...
python -m slackbot.app
```

Without Slack credentials the assistant still runs from the terminal:

```bash
python -m slackbot.agent "which colleges sent the most participants?"
python -m slackbot.eval_agent          # 9 scenarios, no API key needed
python -m slackbot.preview_blocks      # renders the Slack payloads
```

---

## The pieces

### Databases

**`ops` — normalised OLTP (3NF).** Participants, colleges, tracks, teams,
members, check-ins, submissions, judges, criteria, scores. Plus four audit
tables that make the pipeline observable: `etl_run`, `data_quality_event`,
`rejected_registration`, `duplicate_registration`.

**`analytics` — star schema.** Three facts (`fact_registration`,
`fact_score`, `fact_pipeline_run`) and six dimensions, rebuilt from `ops` in
one transaction. Denormalised deliberately: a generated query rarely needs
more than one join, which is what makes an LLM reliable at writing against
it.

### Stored procedures

**`ops.assign_tracks(dry_run)`** — capacity-constrained allocation. A team's
track is the modal preference of its members; teams are served in
registration order of their leader; a team that will not fit overflows to
the track with the most headroom and is marked `balanced_overflow` so the
count of people who missed their first choice is reportable rather than
hidden. Capacity is counted in participants, not teams, because that is what
the venue is sized against.

**`ops.aggregate_scores(round)`** — weighted leaderboard. Normalises each
raw score by its criterion's maximum, averages across the judges who scored
it, *then* weights and ranks. Summing instead would let a team judged by
four people out-score a better team judged by two. Teams missing a criterion
are ranked but flagged `is_complete = false`. The procedure refuses to run if
the active criteria weights do not sum to 1.0.

**`ops.refresh_star_schema()`** — full rebuild of the analytics layer.

### ETL

`extract → validate → transform → deduplicate → load → star refresh`, with
ten data-quality rules at three severities:

- **reject** — no usable identity (malformed email, missing name, unparseable
  timestamp). The row goes to `rejected_registration` with the rules it broke,
  so an organiser can chase the person instead of losing them.
- **warn** — loadable, field coerced to NULL and the event recorded. A phone
  number typed as "not available" should not cost somebody their place.
- **info** — observational.

Identity is `normalise_email()`: lower-cased, trimmed, `+tag` stripped, and
dots removed for Gmail-family domains only. The same function exists in
Python and in SQL, and the two are kept in step deliberately.

### Slack assistant

Agentic, not one-shot. The model writes SQL, the guard checks it, the query
runs — and when either step fails, **the error is handed back to the model so
it can correct itself** (capped at 3 attempts). Both self-correction paths
are covered in `slackbot/eval_agent.py`: a guard refusal for reaching into
`ops`, and a hallucinated column name caught by Postgres.

Four layers of read-only enforcement, outermost first:

1. **Role** — `hacktu_readonly` holds `SELECT` on `analytics` and nothing
   else. It cannot see `ops` at all.
2. **Session** — `default_transaction_read_only`, `statement_timeout = 8s`.
3. **AST allowlist** — `sqlglot` parses the statement; exactly one SELECT,
   every table on the approved list, no forbidden node types or functions.
   Not a regex blocklist, which loses to `DeLeTe` and `/*x*/`.
4. **LIMIT injection** — result sets capped; a user's own smaller LIMIT is
   honoured.

### Dashboard

Three tabs. **Registrations** (trend, hour-of-day, colleges, track demand
vs capacity, demographics), **Pipeline health** (run duration and volume,
duplicate rate per run, data-quality rules, how duplicates were caught,
rejected rows), **Judging** (leaderboard, criterion heatmap, judge
leniency).

The pipeline-health tab is the one usually missing from a dashboard like
this, and the reason the rest can be trusted: a registration chart is
worthless if nobody can see that last night's load rejected forty rows.

![Pipeline health](docs/screenshots/02_pipeline_health.png)

---

## Layout

```
sql/        01 OLTP · 02 star schema · 03 stored procs · 04 indexes · 05 RO role
etl/        config · validators (10 rules) · pipeline
slackbot/   sql_guard · schema_context · agent · app (Bolt) · formatting
            test_sql_guard (41 checks) · eval_agent (9 scenarios) · preview_blocks
dashboard/  queries (all SQL in one place) · app (Streamlit)
benchmarks/ aggregation_workload · bench_aggregation · bench_indexes · results/
scripts/    generate_synthetic_data · seed_event_operations · verify_dedupe
            simulate_run_history · rebuild_all.sh · capture_dashboard
data/       hacktu_registrations_raw.csv (624 rows) · ground_truth.json
docs/       BENCHMARKS.md · screenshots/
```

## Synthetic data

`data/hacktu_registrations_raw.csv` is generated, not real. 550 people with
Indian names across 71 institutions, weighted towards the host college and
nearby Punjab/NCR campuses. Registration timestamps follow a bursty arrival
process — launch spike, mid-campaign lull, deadline wall — because a flat
distribution would make the trend chart meaningless.

The dirt is deliberate and counted on the way out into
`data/ground_truth.json`, so the ETL's recall can be scored rather than
asserted: 74 duplicate submissions, 17 malformed emails, 4 placeholder
phone numbers, 6 impossible graduation years, and 30 names in `  SHOUTING  `.
