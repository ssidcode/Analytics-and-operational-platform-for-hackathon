"""
The aggregation workload, defined once and implemented three times.

Keeping the definition in one place is what makes the benchmark honest:
pandas, Postgres and Spark must all produce the *same* result, and the
harness asserts that before reporting any timing.

THE WORKLOAD -- "cross-edition participation rollup"

For every (event, edition, college, track):
    participants        distinct people (identity, not rows -- the same
                        person registers for several events)
    registrations       row count
    checked_in          rows that checked in
    submitted           rows that reached 'submitted'
    avg_score           mean score
    p90_score           90th percentile score
    avg_team_size       mean team size
    returning_rate      share of people seen in an earlier edition

Then, per (event, edition):
    the top 5 colleges by participants, ranked.

Two things make this expensive rather than trivial: the distinct count over
a high-cardinality identity column, and the "returning participant" flag,
which needs each person's first-ever edition before the group-by can run.
"""

from __future__ import annotations

GROUP_KEYS = ["event_name", "edition_year", "college_name", "track_name"]

TOP_N_COLLEGES = 5


# ---------------------------------------------------------------------------
# pandas
# ---------------------------------------------------------------------------

def run_pandas(df):
    import pandas as pd

    # First edition each identity ever appeared in -> "returning" flag.
    first_seen = df.groupby("identity_hash", sort=False)["edition_year"].transform("min")
    df = df.assign(is_returning=(df["edition_year"] > first_seen))

    g = df.groupby(GROUP_KEYS, sort=False, observed=True)
    out = g.agg(
        participants=("identity_hash", "nunique"),
        registrations=("registration_id", "size"),
        checked_in=("checked_in", "sum"),
        avg_score=("score", "mean"),
        avg_team_size=("team_size", "mean"),
        returning=("is_returning", "sum"),
    ).reset_index()

    # p90 is computed as its own vectorised groupby rather than a lambda
    # inside .agg(). A lambda runs the Python interpreter once per group,
    # which at 48k groups costs more than the entire rest of the job and
    # would make this benchmark a measurement of pandas' slowest path
    # rather than a fair comparison.
    p90 = (g["score"].quantile(0.90)
             .rename("p90_score")
             .reset_index())
    out = out.merge(p90, on=GROUP_KEYS, how="left")

    submitted = (df[df["status"] == "submitted"]
                 .groupby(GROUP_KEYS, sort=False, observed=True)
                 .size().rename("submitted").reset_index())
    out = out.merge(submitted, on=GROUP_KEYS, how="left")
    out["submitted"] = out["submitted"].fillna(0).astype("int64")

    out["returning_rate"] = (out["returning"] / out["registrations"] * 100).round(2)
    out["avg_score"] = out["avg_score"].round(2)
    out["p90_score"] = out["p90_score"].round(2)
    out["avg_team_size"] = out["avg_team_size"].round(3)
    out["checked_in"] = out["checked_in"].astype("int64")
    out = out.drop(columns=["returning"])

    # Top colleges per (event, edition).
    out["college_rank"] = (out.groupby(["event_name", "edition_year"])
                              ["participants"]
                              .rank(method="first", ascending=False)
                              .astype("int64"))
    top = out[out["college_rank"] <= TOP_N_COLLEGES].copy()

    return _canonical_pandas(out), _canonical_pandas(top)


def _canonical_pandas(df):
    """Sort and type-normalise so the three engines can be compared."""
    cols = GROUP_KEYS + ["participants", "registrations", "checked_in",
                         "submitted", "avg_score", "p90_score",
                         "avg_team_size", "returning_rate"]
    cols = [c for c in cols if c in df.columns]
    out = df[cols].copy()
    for c in ("avg_score", "p90_score", "avg_team_size", "returning_rate"):
        if c in out.columns:
            out[c] = out[c].astype(float).round(2)
    return (out.sort_values(GROUP_KEYS)
               .reset_index(drop=True))


# ---------------------------------------------------------------------------
# PySpark
# ---------------------------------------------------------------------------

def run_spark(spark, path: str, fmt: str = "parquet"):
    from pyspark.sql import Window
    from pyspark.sql import functions as SF

    reader = spark.read
    df = (reader.parquet(path) if fmt == "parquet"
          else reader.option("header", True).option("inferSchema", True).csv(path))

    # Window over the identity, not a self-join: one shuffle instead of two.
    first_seen = Window.partitionBy("identity_hash")
    df = df.withColumn(
        "is_returning",
        (SF.col("edition_year") > SF.min("edition_year").over(first_seen)).cast("int"))

    agg = (df.groupBy(*GROUP_KEYS)
             .agg(
                 SF.countDistinct("identity_hash").alias("participants"),
                 SF.count(SF.lit(1)).alias("registrations"),
                 SF.sum(SF.col("checked_in").cast("int")).alias("checked_in"),
                 SF.sum(SF.when(SF.col("status") == "submitted", 1)
                          .otherwise(0)).alias("submitted"),
                 SF.round(SF.avg("score"), 2).alias("avg_score"),
                 # Exact percentile with linear interpolation, matching
                 # pandas' .quantile() and Postgres' percentile_cont. Using
                 # percentile_approx here would be faster but would make the
                 # three engines disagree, and an unverifiable speedup is
                 # not a speedup.
                 SF.round(SF.percentile("score", 0.90), 2).alias("p90_score"),
                 SF.round(SF.avg("team_size"), 3).alias("avg_team_size"),
                 SF.sum("is_returning").alias("returning"),
             ))

    agg = (agg.withColumn(
               "returning_rate",
               SF.round(SF.col("returning") / SF.col("registrations") * 100, 2))
              .drop("returning"))

    rank_w = (Window.partitionBy("event_name", "edition_year")
                    .orderBy(SF.col("participants").desc()))
    ranked = agg.withColumn("college_rank", SF.row_number().over(rank_w))
    top = ranked.filter(SF.col("college_rank") <= TOP_N_COLLEGES).drop("college_rank")

    return agg, top


def spark_to_canonical(sdf):
    pdf = sdf.toPandas()
    return _canonical_pandas(pdf)


# ---------------------------------------------------------------------------
# PostgreSQL
# ---------------------------------------------------------------------------

AGG_SQL = """
WITH first_seen AS (
    SELECT identity_hash, MIN(edition_year) AS first_edition
    FROM {table}
    GROUP BY identity_hash
),
flagged AS (
    SELECT a.*,
           (a.edition_year > f.first_edition)::int AS is_returning
    FROM {table} a
    JOIN first_seen f ON f.identity_hash = a.identity_hash
)
SELECT event_name,
       edition_year,
       college_name,
       track_name,
       COUNT(DISTINCT identity_hash)                              AS participants,
       COUNT(*)                                                   AS registrations,
       SUM(checked_in::int)                                       AS checked_in,
       SUM(CASE WHEN status = 'submitted' THEN 1 ELSE 0 END)      AS submitted,
       ROUND(AVG(score)::numeric, 2)                              AS avg_score,
       ROUND(percentile_cont(0.90) WITHIN GROUP (ORDER BY score)::numeric, 2)
                                                                  AS p90_score,
       ROUND(AVG(team_size)::numeric, 3)                          AS avg_team_size,
       ROUND((SUM(is_returning)::numeric / COUNT(*) * 100), 2)    AS returning_rate
FROM flagged
GROUP BY event_name, edition_year, college_name, track_name
"""


def run_postgres(conn, table: str):
    import pandas as pd
    sql = AGG_SQL.format(table=table)
    return pd.read_sql(sql, conn)
