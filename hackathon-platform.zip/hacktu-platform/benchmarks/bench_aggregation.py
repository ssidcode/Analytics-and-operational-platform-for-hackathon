"""
Benchmark the cross-edition rollup: pandas vs PySpark (vs Postgres).

Run under the Spark virtualenv so pyspark is importable:

    ~/.venv-spark/bin/python benchmarks/bench_aggregation.py \
        --scales 200000 1000000 5000000 --repeats 3

Method
------
* Each engine runs the identical workload defined in aggregation_workload.py.
* Results are compared row-for-row before any timing is reported. A faster
  engine that computes something else is not faster.
* Each scale is run `--repeats` times; the median is reported, because a
  first run pays for page cache and JVM warm-up and is not representative.
* I/O is included in the measured time. Excluding it would flatter Spark,
  which reads Parquet in parallel -- and that parallel read is a real part
  of why the job got moved.
* The machine's core count is recorded with the results. On 2 cores Spark
  cannot show more than ~2x on CPU-bound work; the honest reason it wins at
  scale here is memory, not parallelism.
"""

from __future__ import annotations

import argparse
import json
import os
import platform
import statistics
import subprocess
import sys
import time
import traceback
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from benchmarks import aggregation_workload as W      # noqa: E402

ARCHIVE_DIR = ROOT / "data" / "archive"
RESULTS = ROOT / "benchmarks" / "results"
RESULTS.mkdir(parents=True, exist_ok=True)


def peak_rss_mb() -> float:
    import resource
    return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024.0


def ensure_archive(rows: int, fmt: str) -> Path:
    path = ARCHIVE_DIR / f"rows_{rows}"
    if path.exists() and any(path.iterdir()):
        return path
    print(f"  generating archive of {rows:,} rows ...", flush=True)
    subprocess.run(
        [sys.executable, str(ROOT / "benchmarks" / "generate_archive.py"),
         "--rows", str(rows), "--format", fmt],
        check=True, stdout=subprocess.DEVNULL)
    return path


# ---------------------------------------------------------------------------

def time_pandas(path: Path, fmt: str, mem_limit_gb: float,
                dump: Path | None) -> dict:
    """Run pandas in a subprocess so an OOM is reported, not fatal."""
    cmd = [sys.executable, str(ROOT / "benchmarks" / "run_pandas_once.py"),
           "--path", str(path), "--format", fmt,
           "--mem-limit-gb", str(mem_limit_gb)]
    if dump is not None:
        cmd += ["--dump-result", str(dump)]

    proc = subprocess.run(cmd, capture_output=True, text=True)
    stdout = (proc.stdout or "").strip().splitlines()
    for line in reversed(stdout):
        try:
            return json.loads(line)
        except json.JSONDecodeError:
            continue
    # No JSON at all means the process died hard (kernel OOM killer, signal).
    sig = f"exit {proc.returncode}"
    if proc.returncode < 0:
        sig = f"killed by signal {-proc.returncode} (likely OOM killer)"
    return {"ok": False, "elapsed_s": None, "rows": None,
            "peak_rss_mb": None,
            "error": f"pandas process {sig}",
            "stderr_tail": (proc.stderr or "")[-300:]}


def time_spark(spark, path: Path, fmt: str) -> tuple[float, object]:
    t0 = time.perf_counter()
    agg_sdf, _top = W.run_spark(spark, str(path), fmt)
    result = W.spark_to_canonical(agg_sdf)      # forces the action
    elapsed = time.perf_counter() - t0
    return elapsed, result


def build_spark(cores: str, driver_mem: str, shuffle_parts: int):
    from pyspark.sql import SparkSession
    spark = (SparkSession.builder
             .appName("hacktu-archive-rollup")
             .master(f"local[{cores}]")
             .config("spark.driver.memory", driver_mem)
             .config("spark.sql.shuffle.partitions", str(shuffle_parts))
             .config("spark.ui.enabled", "false")
             .config("spark.sql.adaptive.enabled", "true")
             .config("spark.local.dir", "/tmp/spark-tmp")
             .getOrCreate())
    spark.sparkContext.setLogLevel("ERROR")
    return spark


def compare(a, b, label_a: str, label_b: str) -> tuple[bool, str]:
    """Row-for-row equivalence check between two engines' outputs."""
    if a is None or b is None:
        return False, "one side produced nothing"
    if len(a) != len(b):
        return False, f"{label_a} has {len(a)} groups, {label_b} has {len(b)}"

    cols = [c for c in a.columns if c in b.columns]
    import pandas as pd
    aa = a[cols].reset_index(drop=True)
    bb = b[cols].reset_index(drop=True)

    for c in cols:
        if pd.api.types.is_numeric_dtype(aa[c]) and pd.api.types.is_numeric_dtype(bb[c]):
            # All three engines use exact linear-interpolation percentiles,
            # so nothing beyond float rounding should differ.
            tol = 0.051
            diff = (aa[c].astype(float) - bb[c].astype(float)).abs()
            worst = float(diff.max())
            if worst > tol:
                bad = int((diff > tol).sum())
                return False, (f"column `{c}` differs on {bad} row(s), "
                               f"max delta {worst:.3f} (tolerance {tol})")
        else:
            mism = int((aa[c].astype(str) != bb[c].astype(str)).sum())
            if mism:
                return False, f"column `{c}` differs on {mism} row(s)"
    return True, "identical"


def _write_results(args, records: list[dict], n_cores: int) -> Path:
    out = {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "host": platform.platform(),
        "cores": n_cores,
        "python": platform.python_version(),
        "spark_master": f"local[{args.cores}]",
        "driver_memory": args.driver_mem,
        "shuffle_partitions": args.shuffle_partitions,
        "repeats": args.repeats,
        "format": args.format,
        "runs": records,
    }
    path = Path(args.out) if args.out else RESULTS / "aggregation_benchmark.json"
    path.write_text(json.dumps(out, indent=2))
    return path


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--scales", type=int, nargs="+",
                    default=[200_000, 1_000_000, 5_000_000])
    ap.add_argument("--repeats", type=int, default=3)
    ap.add_argument("--format", choices=["parquet", "csv"], default="parquet")
    ap.add_argument("--cores", default="*")
    ap.add_argument("--driver-mem", default="4g")
    ap.add_argument("--shuffle-partitions", type=int, default=8)
    ap.add_argument("--pandas-mem-gb", type=float, default=5.0,
                    help="hard address-space cap for the pandas subprocess")
    ap.add_argument("--skip-pandas-above", type=int, default=0,
                    help="skip the pandas run above this row count "
                         "(use when it OOMs)")
    ap.add_argument("--out", default=None)
    args = ap.parse_args()

    n_cores = os.cpu_count() or 1
    print("=" * 78)
    print("  CROSS-EDITION ROLLUP BENCHMARK -- pandas vs PySpark")
    print("=" * 78)
    print(f"  host         {platform.platform()}")
    print(f"  python       {platform.python_version()}")
    print(f"  cores        {n_cores}")
    print(f"  spark master local[{args.cores}]   driver-mem {args.driver_mem}"
          f"   shuffle-parts {args.shuffle_partitions}")
    print(f"  repeats      {args.repeats} (median reported)")
    print(f"  format       {args.format}")
    print()

    try:
        import pyspark
        print(f"  pyspark      {pyspark.__version__}")
    except ImportError:
        print("  pyspark is not importable in this interpreter.")
        print("  Run with:  ~/.venv-spark/bin/python benchmarks/bench_aggregation.py")
        raise SystemExit(2)

    spark = build_spark(args.cores, args.driver_mem, args.shuffle_partitions)
    print(f"  spark        {spark.version}\n")

    records = []

    for rows in args.scales:
        path = ensure_archive(rows, args.format)
        size_mb = sum(f.stat().st_size for f in path.iterdir()) / 1e6
        print("-" * 78)
        print(f"  SCALE {rows:,} rows   ({size_mb:,.1f} MB on disk)")
        print("-" * 78)

        entry = {"rows": rows, "size_mb": round(size_mb, 1),
                 "cores": n_cores, "format": args.format}

        # ---- pandas (subprocess, memory-capped)
        pandas_times, pandas_result, pandas_err = [], None, None
        pandas_peak = None
        skip = args.skip_pandas_above and rows > args.skip_pandas_above
        if skip:
            print("  pandas       skipped (--skip-pandas-above)")
            pandas_err = "skipped"
        else:
            dump = RESULTS / f"_pandas_agg_{rows}.parquet"
            for i in range(args.repeats):
                r = time_pandas(path, args.format, args.pandas_mem_gb,
                                dump if i == 0 else None)
                if r.get("ok"):
                    pandas_times.append(r["elapsed_s"])
                    pandas_peak = r.get("peak_rss_mb")
                    print(f"  pandas  run {i+1}   {r['elapsed_s']:8.2f}s"
                          f"   peak RSS {r.get('peak_rss_mb')} MB", flush=True)
                else:
                    pandas_err = r.get("error")
                    pandas_peak = r.get("peak_rss_mb")
                    print(f"  pandas  run {i+1}   FAILED: {pandas_err}",
                          flush=True)
                    break
            if pandas_times and dump.exists():
                import pandas as pd
                pandas_result = pd.read_parquet(dump)
                dump.unlink(missing_ok=True)

        # ---- spark
        spark_times, spark_result, spark_err = [], None, None
        for i in range(args.repeats):
            try:
                el, res = time_spark(spark, path, args.format)
                spark_times.append(el)
                spark_result = res
                print(f"  spark   run {i+1}   {el:8.2f}s", flush=True)
            except Exception as exc:                              # noqa: BLE001
                spark_err = f"{type(exc).__name__}: {exc}"
                print(f"  spark   run {i+1}   FAILED: {spark_err}")
                traceback.print_exc(limit=1)
                break

        # ---- equivalence
        if pandas_result is not None and spark_result is not None:
            same, why = compare(pandas_result, spark_result, "pandas", "spark")
            print(f"  equivalence  {'OK' if same else 'MISMATCH'} -- {why}")
            entry["results_match"] = same
            entry["match_detail"] = why
            entry["groups"] = len(pandas_result)
        elif spark_result is not None:
            entry["results_match"] = None
            entry["groups"] = len(spark_result)

        p_med = statistics.median(pandas_times) if pandas_times else None
        s_med = statistics.median(spark_times) if spark_times else None
        entry.update({
            "pandas_times": [round(t, 3) for t in pandas_times],
            "spark_times": [round(t, 3) for t in spark_times],
            "pandas_median_s": round(p_med, 3) if p_med else None,
            "spark_median_s": round(s_med, 3) if s_med else None,
            "pandas_error": pandas_err,
            "spark_error": spark_err,
            "pandas_peak_rss_mb": pandas_peak,
            "pandas_mem_cap_gb": args.pandas_mem_gb,
        })
        if p_med and s_med:
            entry["speedup"] = round(p_med / s_med, 2)
            verdict = ("spark faster" if entry["speedup"] > 1
                       else "pandas faster")
            print(f"  median       pandas {p_med:7.2f}s   spark {s_med:7.2f}s"
                  f"   -> {entry['speedup']}x  ({verdict})")
        elif s_med:
            print(f"  median       pandas  n/a ({pandas_err})   "
                  f"spark {s_med:7.2f}s")
        print()

        records.append(entry)
        _write_results(args, records, n_cores)   # checkpoint after each scale

    # Results are written before the session is torn down, and the teardown
    # is guarded: a JVM that died during the last scale used to take the
    # whole results file with it.
    try:
        spark.stop()
    except Exception as exc:                                      # noqa: BLE001
        print(f"  (spark session teardown failed: {type(exc).__name__})")

    path = _write_results(args, records, n_cores)

    print("=" * 78)
    print(f"  {'rows':>12}  {'pandas':>10}  {'spark':>10}  {'speedup':>9}  match")
    for r in records:
        p = f"{r['pandas_median_s']:.2f}s" if r.get("pandas_median_s") else (r.get("pandas_error") or "-")
        s = f"{r['spark_median_s']:.2f}s" if r.get("spark_median_s") else (r.get("spark_error") or "-")
        sp = f"{r['speedup']}x" if r.get("speedup") else "-"
        m = {True: "yes", False: "NO", None: "-"}.get(r.get("results_match"), "-")
        print(f"  {r['rows']:>12,}  {p:>10}  {s:>10}  {sp:>9}  {m}")
    print("=" * 78)
    print(f"  written to {path}")


if __name__ == "__main__":
    main()
