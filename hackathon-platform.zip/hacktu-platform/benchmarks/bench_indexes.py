"""
Measure what the indexes in sql/04_indexes.sql are actually worth.

Method: time every query the dashboard issues (imported from
dashboard/queries.py, so this measures the real workload rather than a
proxy), drop all the project's indexes, time them again, then restore.

Notes on getting a believable number out of Postgres:
  * Each query is run `--warmup` times before timing, so the comparison is
    warm-cache vs warm-cache. Cold-cache numbers mostly measure the disk.
  * `ANALYZE` is run after dropping and after restoring, because a stale
    plan can make the "after" case look better or worse than the planner
    would actually behave.
  * Primary-key and unique-constraint indexes are *not* dropped: they back
    constraints, cannot be dropped without dropping the constraint, and no
    sane "before" state lacks them.
  * EXPLAIN output is captured for the queries that change the most, so the
    speedup can be traced to a specific plan change rather than asserted.

    python benchmarks/bench_indexes.py
    python benchmarks/bench_indexes.py --repeats 20 --explain
"""

from __future__ import annotations

import argparse
import json
import statistics
import sys
import time
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from dashboard.queries import BENCHMARK_QUERIES          # noqa: E402
from etl.config import SQL_DIR, connect                  # noqa: E402

RESULTS = ROOT / "benchmarks" / "results"
RESULTS.mkdir(parents=True, exist_ok=True)


def project_indexes(cur) -> list[tuple[str, str]]:
    """Our own indexes: everything named ix_* that is not constraint-backed."""
    cur.execute("""
        SELECT schemaname, indexname
        FROM pg_indexes
        WHERE schemaname IN ('ops', 'analytics')
          AND indexname LIKE 'ix_%'
          AND indexname NOT IN (
              SELECT conname FROM pg_constraint
          )
        ORDER BY schemaname, indexname
    """)
    return [(r[0], r[1]) for r in cur.fetchall()]


def time_query(cur, sql: str, params: dict, repeats: int,
               warmup: int) -> list[float]:
    for _ in range(warmup):
        cur.execute(sql, params or None)
        cur.fetchall()
    times = []
    for _ in range(repeats):
        t0 = time.perf_counter()
        cur.execute(sql, params or None)
        cur.fetchall()
        times.append((time.perf_counter() - t0) * 1000.0)
    return times


def measure(conn, repeats: int, warmup: int) -> dict[str, dict]:
    out = {}
    with conn.cursor() as cur:
        for name, (sql, params) in BENCHMARK_QUERIES.items():
            try:
                times = time_query(cur, sql, params, repeats, warmup)
                out[name] = {
                    "median_ms": round(statistics.median(times), 3),
                    "mean_ms": round(statistics.fmean(times), 3),
                    "min_ms": round(min(times), 3),
                    "max_ms": round(max(times), 3),
                }
            except Exception as exc:                              # noqa: BLE001
                out[name] = {"error": f"{type(exc).__name__}: {exc}"[:200]}
                conn.rollback()
    return out


def explain(conn, name: str) -> str:
    sql, params = BENCHMARK_QUERIES[name]
    with conn.cursor() as cur:
        cur.execute("EXPLAIN (ANALYZE, BUFFERS, COSTS OFF, SUMMARY OFF) " + sql,
                    params or None)
        return "\n".join(r[0] for r in cur.fetchall())


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repeats", type=int, default=15)
    ap.add_argument("--warmup", type=int, default=3)
    ap.add_argument("--explain", action="store_true",
                    help="capture EXPLAIN plans for the biggest movers")
    args = ap.parse_args()

    print("=" * 76)
    print("  INDEX BENCHMARK -- the dashboard's own query set")
    print("=" * 76)
    print(f"  {len(BENCHMARK_QUERIES)} queries, {args.repeats} timed runs each "
          f"({args.warmup} warm-up)\n")

    with connect(autocommit=True) as conn:
        with conn.cursor() as cur:
            idx = project_indexes(cur)
        print(f"  {len(idx)} project indexes present\n")

        # ---- WITH indexes
        with conn.cursor() as cur:
            cur.execute("ANALYZE")
        with_idx = measure(conn, args.repeats, args.warmup)
        plans_with = ({n: explain(conn, n) for n in BENCHMARK_QUERIES}
                      if args.explain else {})

        # ---- drop them
        print("  dropping indexes ...")
        with conn.cursor() as cur:
            for schema, name in idx:
                cur.execute(f'DROP INDEX IF EXISTS "{schema}"."{name}"')
            cur.execute("ANALYZE")

        without_idx = measure(conn, args.repeats, args.warmup)
        plans_without = ({n: explain(conn, n) for n in BENCHMARK_QUERIES}
                         if args.explain else {})

        # ---- restore
        print("  restoring indexes ...")
        sql_text = (SQL_DIR / "04_indexes.sql").read_text(encoding="utf-8")
        with conn.cursor() as cur:
            cur.execute(sql_text)
            cur.execute("ANALYZE")
        with conn.cursor() as cur:
            restored = project_indexes(cur)
        print(f"  {len(restored)} indexes restored "
              f"({'OK' if len(restored) == len(idx) else 'MISMATCH'})\n")

    # ---- report
    rows = []
    for name in BENCHMARK_QUERIES:
        a = with_idx.get(name, {})
        b = without_idx.get(name, {})
        if "median_ms" not in a or "median_ms" not in b:
            continue
        rows.append({
            "query": name,
            "with_index_ms": a["median_ms"],
            "without_index_ms": b["median_ms"],
            "speedup": round(b["median_ms"] / a["median_ms"], 2)
                       if a["median_ms"] else None,
            "saved_ms": round(b["median_ms"] - a["median_ms"], 3),
        })

    rows.sort(key=lambda r: r["speedup"] or 0, reverse=True)

    print(f"  {'query':<24}{'with idx':>11}{'no idx':>11}{'speedup':>10}"
          f"{'saved':>10}")
    print("  " + "-" * 64)
    for r in rows:
        print(f"  {r['query']:<24}{r['with_index_ms']:>9.2f}ms"
              f"{r['without_index_ms']:>9.2f}ms"
              f"{r['speedup']:>9.2f}x{r['saved_ms']:>8.2f}ms")

    tot_with = sum(r["with_index_ms"] for r in rows)
    tot_without = sum(r["without_index_ms"] for r in rows)
    print("  " + "-" * 64)
    print(f"  {'FULL DASHBOARD LOAD':<24}{tot_with:>9.2f}ms"
          f"{tot_without:>9.2f}ms{tot_without / tot_with:>9.2f}x"
          f"{tot_without - tot_with:>8.2f}ms")

    payload = {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "repeats": args.repeats,
        "warmup": args.warmup,
        "index_count": len(idx),
        "queries": rows,
        "total_with_index_ms": round(tot_with, 3),
        "total_without_index_ms": round(tot_without, 3),
        "total_speedup": round(tot_without / tot_with, 3),
    }
    if args.explain:
        payload["plans"] = {
            "with_indexes": plans_with,
            "without_indexes": plans_without,
        }

    out = RESULTS / "index_benchmark.json"
    out.write_text(json.dumps(payload, indent=2))
    print(f"\n  written to {out}")

    if args.explain and rows:
        top = rows[0]["query"]
        print(f"\n  EXPLAIN for the biggest mover ({top}):")
        print("\n  --- with indexes ---")
        for line in plans_with[top].splitlines()[:12]:
            print("   " + line)
        print("\n  --- without indexes ---")
        for line in plans_without[top].splitlines()[:12]:
            print("   " + line)


if __name__ == "__main__":
    main()
