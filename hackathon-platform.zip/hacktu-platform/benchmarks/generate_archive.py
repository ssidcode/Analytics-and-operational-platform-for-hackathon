"""
Generate the multi-edition registration archive used by the Spark benchmark.

The live event is ~550 people, which is nowhere near enough to justify
Spark -- and pretending otherwise would be dishonest. The aggregation that
actually got moved to Spark runs over the *archive*: every registration
across every edition of the event and the other hackathons the same
organising body runs, which is where the per-college / per-track / per-year
rollups and the cross-edition identity resolution happen.

This script synthesises that archive at a requested scale so the benchmark
is reproducible on any machine.

    python benchmarks/generate_archive.py --rows 1000000
    python benchmarks/generate_archive.py --rows 5000000 --format parquet
"""

from __future__ import annotations

import argparse
import shutil
import time
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
ARCHIVE_DIR = ROOT / "data" / "archive"

SEED = 4711

FIRST = ["Aarav", "Ananya", "Vivaan", "Diya", "Aditya", "Ira", "Arjun", "Myra",
         "Sai", "Anika", "Reyansh", "Navya", "Krishna", "Riya", "Ishaan",
         "Saanvi", "Rudra", "Kiara", "Yash", "Prisha", "Kabir", "Aarohi",
         "Dhruv", "Avni", "Atharv", "Siya", "Rohan", "Tara", "Karan", "Isha",
         "Siddharth", "Meera", "Harshit", "Nandini", "Nikhil", "Shreya",
         "Rahul", "Pooja", "Ankit", "Neha", "Abhishek", "Priya", "Manpreet",
         "Kavya", "Gurpreet", "Simran", "Jaskaran", "Harleen", "Navdeep",
         "Jasleen", "Tanmay", "Sneha", "Parth", "Divya", "Aryan", "Swati",
         "Kunal", "Trisha", "Varun", "Aditi", "Pranav", "Bhavya", "Raghav",
         "Deepika", "Lakshya", "Esha", "Naman", "Harshita", "Shivam", "Ishita"]

LAST = ["Sharma", "Verma", "Gupta", "Agarwal", "Singh", "Kumar", "Yadav",
        "Mishra", "Tiwari", "Pandey", "Chauhan", "Joshi", "Sidhu", "Dhillon",
        "Gill", "Sandhu", "Grewal", "Bajwa", "Brar", "Randhawa", "Malhotra",
        "Kapoor", "Khanna", "Chopra", "Patel", "Shah", "Desai", "Mehta",
        "Reddy", "Rao", "Naidu", "Iyer", "Krishnan", "Nair", "Menon",
        "Kulkarni", "Deshpande", "Patil", "Jadhav", "Shinde", "Banerjee",
        "Chatterjee", "Mukherjee", "Ghosh", "Bose", "Das", "Dutta", "Sen",
        "Roy", "Chakraborty", "Nayak", "Mohanty", "Khan", "Ahmed", "Ansari",
        "Siddiqui", "Jain", "Bansal", "Goel", "Mittal", "Garg", "Thakur"]

COLLEGES = [
    "Thapar Institute of Engineering and Technology", "Punjab Engineering College",
    "Chitkara University", "Lovely Professional University", "Chandigarh University",
    "Guru Nanak Dev Engineering College", "NIT Jalandhar", "Guru Nanak Dev University",
    "Panjab University", "IIT Ropar", "IIT Delhi", "Delhi Technological University",
    "Netaji Subhas University of Technology", "IIIT Delhi", "Jamia Millia Islamia",
    "Jaypee Institute of Information Technology", "Amity University Noida",
    "Galgotias University", "NIT Kurukshetra", "DCRUST Murthal",
    "The NorthCap University", "Manav Rachna University", "IIT Bombay",
    "IIT Kanpur", "IIT Madras", "IIT Kharagpur", "IIT Roorkee", "IIT Guwahati",
    "IIT Hyderabad", "BITS Pilani", "VIT Vellore", "Manipal Institute of Technology",
    "SRM Institute of Science and Technology", "PES University",
    "RV College of Engineering", "BMS College of Engineering", "NIT Surathkal",
    "NIT Trichy", "NIT Warangal", "College of Engineering Pune", "VJTI Mumbai",
    "Jadavpur University", "IIEST Shibpur", "BIT Mesra", "MNIT Jaipur",
    "IIIT Allahabad", "MNNIT Allahabad", "VNIT Nagpur", "SVNIT Surat",
    "Nirma University", "DA-IICT Gandhinagar", "CUSAT", "CET Trivandrum",
    "NIT Calicut", "Osmania University", "CBIT Hyderabad", "Vasavi College",
    "Andhra University", "Heritage Institute of Technology", "KIIT Bhubaneswar",
]

STATES = ["Punjab", "Haryana", "Delhi", "Chandigarh", "Uttar Pradesh",
          "Maharashtra", "Karnataka", "Tamil Nadu", "Telangana", "West Bengal",
          "Kerala", "Gujarat", "Rajasthan", "Odisha", "Andhra Pradesh",
          "Jharkhand", "Assam", "Uttarakhand"]

TRACKS = ["AI/ML", "Web3 & Blockchain", "HealthTech", "FinTech",
          "Sustainability", "Open Innovation", "AR/VR", "DevTools",
          "Cybersecurity", "EdTech"]

EVENTS = ["HackTU", "HackIndia", "CodeFest", "InnovateX", "BuildIt",
          "DevSprint", "HackVerse", "TechNova"]

EDITIONS = list(range(2017, 2027))

DEGREES = ["B.Tech", "B.E.", "B.Sc", "BCA", "M.Tech", "MCA", "Dual Degree"]
BRANCHES = ["Computer Science and Engineering", "Information Technology",
            "Electronics and Communication", "Electrical Engineering",
            "Mechanical Engineering", "Data Science", "Artificial Intelligence",
            "Mathematics and Computing", "Biotechnology", "Civil Engineering"]
EXPERIENCE = ["First hackathon", "1-2 hackathons", "3-5 hackathons", "5+ hackathons"]
STATUSES = ["registered", "checked_in", "submitted", "withdrawn"]

CHUNK = 250_000


def build_chunk(rng: np.random.Generator, n: int, offset: int) -> pd.DataFrame:
    first = rng.choice(FIRST, n)
    last = rng.choice(LAST, n)

    # A pool of identities smaller than the row count, so the same people
    # recur across editions. That recurrence is the whole reason the
    # cross-edition rollup is expensive: it needs a distinct count per group.
    identity = rng.integers(0, max(n // 3, 1000), n)

    college_idx = rng.integers(0, len(COLLEGES), n)
    event_idx = rng.integers(0, len(EVENTS), n)
    edition = rng.choice(EDITIONS, n)

    # Registration timestamps spread across each edition's window.
    day_offset = rng.integers(0, 45, n)
    base = pd.to_datetime(edition.astype(str) + "-01-05")
    registered_at = base + pd.to_timedelta(day_offset, unit="D") \
        + pd.to_timedelta(rng.integers(0, 86400, n), unit="s")

    return pd.DataFrame({
        "registration_id": np.arange(offset, offset + n, dtype=np.int64),
        "identity_hash": identity,
        "email_key": [f"u{i}@mail.example" for i in identity],
        "full_name": [f"{a} {b}" for a, b in zip(first, last)],
        "event_name": np.asarray(EVENTS)[event_idx],
        "edition_year": edition,
        "college_name": np.asarray(COLLEGES)[college_idx],
        "college_state": np.asarray(STATES)[college_idx % len(STATES)],
        "track_name": rng.choice(TRACKS, n),
        "degree": rng.choice(DEGREES, n),
        "branch": rng.choice(BRANCHES, n),
        "year_of_study": rng.integers(1, 5, n),
        "experience_level": rng.choice(EXPERIENCE, n),
        "status": rng.choice(STATUSES, n, p=[0.18, 0.22, 0.52, 0.08]),
        "team_size": rng.integers(1, 5, n),
        "score": np.round(rng.beta(5, 3, n) * 100, 2),
        "checked_in": rng.random(n) < 0.86,
        "registered_at": registered_at,
    })


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--rows", type=int, default=1_000_000)
    ap.add_argument("--format", choices=["csv", "parquet"], default="parquet")
    ap.add_argument("--out", type=Path, default=None)
    args = ap.parse_args()

    rng = np.random.default_rng(SEED)
    out_dir = args.out or (ARCHIVE_DIR / f"rows_{args.rows}")
    if out_dir.exists():
        shutil.rmtree(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    started = time.perf_counter()
    written = 0
    part = 0
    while written < args.rows:
        n = min(CHUNK, args.rows - written)
        df = build_chunk(rng, n, written)
        if args.format == "parquet":
            df.to_parquet(out_dir / f"part-{part:05d}.parquet", index=False)
        else:
            df.to_csv(out_dir / f"part-{part:05d}.csv", index=False)
        written += n
        part += 1
        print(f"  part {part:>3}  {written:>12,} / {args.rows:,} rows",
              flush=True)

    size_mb = sum(f.stat().st_size for f in out_dir.iterdir()) / 1e6
    print(f"\n  {written:,} rows in {part} file(s), {size_mb:,.1f} MB")
    print(f"  {out_dir}")
    print(f"  generated in {time.perf_counter() - started:.1f}s")


if __name__ == "__main__":
    main()
