"""
Run the pandas implementation once, in its own process, under a memory cap.

Isolating pandas matters for two reasons. An out-of-memory pandas run is
killed by the kernel rather than raising MemoryError, which would take the
whole benchmark harness down and lose every result collected so far. And a
hard RLIMIT_AS turns "the machine started swapping and the number is
meaningless" into a clean, reportable failure at a stated memory budget.

Prints one JSON object on stdout. Not meant to be run by hand.
"""

from __future__ import annotations

import argparse
import glob
import json
import os
import resource
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--path", required=True)
    ap.add_argument("--format", default="parquet")
    ap.add_argument("--mem-limit-gb", type=float, default=5.0)
    ap.add_argument("--dump-result", default=None,
                    help="write the aggregate to this parquet file for the "
                         "cross-engine equivalence check")
    args = ap.parse_args()

    if args.mem_limit_gb > 0:
        cap = int(args.mem_limit_gb * (1024 ** 3))
        resource.setrlimit(resource.RLIMIT_AS, (cap, cap))

    out = {"ok": False, "elapsed_s": None, "rows": None,
           "peak_rss_mb": None, "error": None}

    try:
        import pandas as pd
        from benchmarks import aggregation_workload as W

        t0 = time.perf_counter()
        files = sorted(glob.glob(os.path.join(args.path, f"*.{args.format}")))
        if args.format == "parquet":
            df = pd.concat([pd.read_parquet(f) for f in files], ignore_index=True)
        else:
            df = pd.concat([pd.read_csv(f) for f in files], ignore_index=True)
        rows = len(df)
        agg, _top = W.run_pandas(df)
        elapsed = time.perf_counter() - t0

        out.update({"ok": True, "elapsed_s": round(elapsed, 3), "rows": rows,
                    "groups": len(agg)})
        if args.dump_result:
            agg.to_parquet(args.dump_result, index=False)

    except MemoryError:
        out["error"] = f"MemoryError at {args.mem_limit_gb}GB cap"
    except Exception as exc:                                      # noqa: BLE001
        out["error"] = f"{type(exc).__name__}: {exc}"[:300]

    out["peak_rss_mb"] = round(
        resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024.0, 1)

    print(json.dumps(out))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
