"""
HackTU Analytics & Operations dashboard.

Three tabs, in the order organisers actually needed them:

  Registrations  -- is the campaign working? where from? which tracks?
  Pipeline health -- is the data behind those numbers trustworthy?
  Judging        -- the leaderboard and whether it is complete

The pipeline-health tab is the one that matters most and the one usually
missing from a dashboard like this: a registration chart is worthless if
nobody can see that last night's load rejected forty rows.

    streamlit run dashboard/app.py
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
from plotly.subplots import make_subplots

from dashboard import queries as Q
from etl.config import EVENT

st.set_page_config(page_title="HackTU Analytics",
                   page_icon=":bar_chart:", layout="wide")

# A single palette, used consistently: categorical for tracks/regions,
# and a fixed semantic mapping for pipeline status so green/amber/red
# always mean the same thing.
PALETTE = ["#4C6FFF", "#00B8A9", "#F6A935", "#E8537A",
           "#8B5CF6", "#2DB3A0", "#F2654C", "#5B8DEF"]
STATUS_COLOUR = {"success": "#17B26A", "partial": "#F6A935",
                 "failed": "#E5484D", "running": "#8B8FA3"}

CACHE_TTL = 60


@st.cache_data(ttl=CACHE_TTL)
def load(sql: str, params: dict | None = None) -> pd.DataFrame:
    return Q.q(sql, params)


def metric_row(items: list[tuple[str, str, str | None]]) -> None:
    cols = st.columns(len(items))
    for col, (label, value, delta) in zip(cols, items):
        col.metric(label, value, delta)


def style_fig(fig: go.Figure, height: int = 340) -> go.Figure:
    fig.update_layout(
        height=height,
        margin=dict(l=10, r=10, t=40, b=10),
        plot_bgcolor="rgba(0,0,0,0)",
        paper_bgcolor="rgba(0,0,0,0)",
        legend=dict(orientation="h", yanchor="bottom", y=1.02,
                    xanchor="left", x=0),
        hoverlabel=dict(font_size=12),
    )
    fig.update_xaxes(showgrid=False)
    fig.update_yaxes(gridcolor="rgba(128,128,128,0.18)", zeroline=False)
    return fig


# ===========================================================================
# Header
# ===========================================================================

st.title("HackTU Analytics & Operations")

runs = load(Q.PIPELINE_RUNS)
latest = runs[runs["status"] != "failed"].tail(1)
funnel = load(Q.FUNNEL).iloc[0]

if latest.empty:
    st.error("No successful pipeline run on record. The numbers below are stale.")
    st.stop()

lr = latest.iloc[0]
st.caption(
    f"{EVENT['name']} · registration {EVENT['reg_open']} → {EVENT['reg_close']} · "
    f"last load: run #{int(lr['run_id'])} at "
    f"{pd.to_datetime(lr['started_at']):%d %b %Y %H:%M} "
    f"({float(lr['duration_seconds']):.2f}s, {lr['status']})"
)

tab_reg, tab_pipe, tab_judge = st.tabs(
    ["Registrations", "Pipeline health", "Judging"])


# ===========================================================================
# Registrations
# ===========================================================================

with tab_reg:
    by_day = load(Q.REGISTRATIONS_BY_DAY)
    colleges = load(Q.TOP_COLLEGES, {"limit": 15})
    states = load(Q.BY_STATE)
    tracks = load(Q.TRACK_DEMAND)
    demo = load(Q.DEMOGRAPHICS)

    checked = int(funnel["checked_in"])
    total = int(funnel["participants"])
    peak = by_day.loc[by_day["registrations"].idxmax()] if not by_day.empty else None

    counts = load(Q.HEADLINE_COUNTS).iloc[0]

    metric_row([
        ("Participants", f"{total:,}", None),
        ("Colleges", f"{int(counts['colleges']):,}",
         f"{int(counts['states'])} states"),
        ("Checked in", f"{checked:,}",
         f"{100 * checked / max(total, 1):.0f}% of registered"),
        ("Teams", f"{int(funnel['teams_total']):,}",
         f"{int(funnel['teams_submitted'])} submitted"),
        ("Busiest day",
         f"{pd.to_datetime(peak['full_date']):%d %b}" if peak is not None else "—",
         f"{int(peak['registrations'])} sign-ups" if peak is not None else None),
    ])

    st.divider()

    left, right = st.columns([3, 2])

    with left:
        st.subheader("Registrations over time")
        fig = make_subplots(specs=[[{"secondary_y": True}]])
        fig.add_bar(x=by_day["full_date"], y=by_day["registrations"],
                    name="per day", marker_color=PALETTE[0], opacity=0.75)
        fig.add_scatter(x=by_day["full_date"], y=by_day["cumulative"],
                        name="cumulative", mode="lines",
                        line=dict(color=PALETTE[2], width=3),
                        secondary_y=True)
        fig.update_yaxes(title_text="per day", secondary_y=False)
        fig.update_yaxes(title_text="cumulative", secondary_y=True,
                         showgrid=False)
        st.plotly_chart(style_fig(fig, 380), width='stretch')

        phase = load(Q.REGISTRATIONS_BY_PHASE)
        if not phase.empty:
            final = phase.loc[phase["reg_window_phase"] == "final_week",
                              "registrations"]
            if len(final):
                pct = 100 * int(final.iloc[0]) / max(total, 1)
                st.caption(
                    f"**{pct:.0f}%** of all registrations arrived in the final "
                    f"week before the form closed — the deadline wall that "
                    f"drives the capacity planning on the Tracks chart.")

    with right:
        st.subheader("When people register")
        hourly = load(Q.REGISTRATIONS_BY_HOUR)
        fig = px.bar(hourly, x="hour_of_day", y="registrations",
                     color_discrete_sequence=[PALETTE[1]])
        fig.update_xaxes(title="hour of day", dtick=3)
        fig.update_yaxes(title=None)
        st.plotly_chart(style_fig(fig, 380), width='stretch')

    st.divider()
    c1, c2 = st.columns(2)

    with c1:
        st.subheader("Where they came from")
        top = colleges.head(12).sort_values("participants")
        fig = px.bar(top, x="participants", y="college_name",
                     orientation="h",
                     color="is_host_college",
                     color_discrete_map={True: PALETTE[2], False: PALETTE[0]},
                     labels={"college_name": "", "participants": "participants"})
        fig.update_layout(showlegend=False)
        st.plotly_chart(style_fig(fig, 420), width='stretch')

    with c2:
        st.subheader("Track demand vs capacity")
        t = tracks.copy()
        fig = go.Figure()
        fig.add_bar(x=t["track_name"], y=t["capacity"], name="capacity",
                    marker_color="rgba(140,145,165,0.35)")
        fig.add_bar(x=t["track_name"], y=t["preferred_by"], name="preferred by",
                    marker_color=PALETTE[0])
        fig.add_bar(x=t["track_name"], y=t["assigned_to"], name="assigned",
                    marker_color=PALETTE[1])
        fig.update_layout(barmode="group")
        fig.update_xaxes(tickangle=-20)
        st.plotly_chart(style_fig(fig, 420), width='stretch')

        over = t[t["preferred_by"] > t["capacity"]]
        if not over.empty:
            names = ", ".join(over["track_name"])
            st.caption(f"Oversubscribed on preference: **{names}** — the "
                       f"overflow is what `ops.assign_tracks()` resolves.")

    st.divider()
    st.subheader("Who they are")
    d1, d2, d3 = st.columns(3)

    with d1:
        yr = (demo.groupby("year_of_study").size()
                  .rename("n").reset_index().dropna())
        yr["year_of_study"] = yr["year_of_study"].astype(int).astype(str)
        fig = px.bar(yr, x="year_of_study", y="n",
                     color_discrete_sequence=[PALETTE[0]],
                     labels={"year_of_study": "year of study", "n": ""})
        st.plotly_chart(style_fig(fig, 280), width='stretch')

    with d2:
        ex = demo.groupby("experience_level").size().rename("n").reset_index()
        fig = px.pie(ex, names="experience_level", values="n", hole=0.55,
                     color_discrete_sequence=PALETTE)
        fig.update_traces(textposition="inside", textinfo="percent")
        st.plotly_chart(style_fig(fig, 280), width='stretch')

    with d3:
        src = (demo.groupby("heard_from").size().rename("n")
                   .reset_index().sort_values("n"))
        fig = px.bar(src, x="n", y="heard_from", orientation="h",
                     color_discrete_sequence=[PALETTE[4]],
                     labels={"heard_from": "", "n": "participants"})
        st.plotly_chart(style_fig(fig, 280), width='stretch')

    with st.expander("College table"):
        st.dataframe(colleges, width='stretch', hide_index=True)


# ===========================================================================
# Pipeline health
# ===========================================================================

with tab_pipe:
    # Runs are plotted against their sequence number, not wall-clock time:
    # the 47 runs of the registration window sit in Jan-Feb while any re-load
    # since then lands months later, and a date axis turns that into one
    # long empty corridor. Pipeline health is read run-over-run anyway.
    runs = runs.copy()
    runs["seq"] = range(1, len(runs) + 1)
    runs["run_label"] = runs.apply(
        lambda r: f"run #{r['seq']} - "
                  f"{pd.to_datetime(r['started_at']):%d %b %Y %H:%M}", axis=1)
    ok_runs = runs[runs["status"] != "failed"].copy()
    failed = runs[runs["status"] == "failed"]
    dq_rules = load(Q.DQ_BY_RULE)
    dq_latest = load(Q.DQ_LATEST_RUN)
    dupes = load(Q.DUPLICATE_BREAKDOWN)

    last = ok_runs.iloc[-1]
    prev = ok_runs.iloc[-2] if len(ok_runs) > 1 else last

    dur_delta = float(last["duration_seconds"]) - float(prev["duration_seconds"])
    dup_delta = float(last["duplicate_rate_pct"]) - float(prev["duplicate_rate_pct"])

    metric_row([
        ("Last run", f"{float(last['duration_seconds']):.2f}s",
         f"{dur_delta:+.2f}s vs previous"),
        ("Duplicate rate", f"{float(last['duplicate_rate_pct']):.2f}%",
         f"{dup_delta:+.2f} pts"),
        ("Validation failures", f"{int(last['validation_failures']):,}",
         f"{int(last['reject_rule_count'])} reject rules firing"),
        ("Rows rejected", f"{int(last['rows_rejected']):,}",
         f"of {int(last['rows_extracted']):,} extracted"),
        ("Failed runs", f"{len(failed)}",
         f"of {len(runs)} total"),
    ])

    st.divider()
    p1, p2 = st.columns([3, 2])

    with p1:
        st.subheader("Run duration and volume")
        fig = make_subplots(specs=[[{"secondary_y": True}]])
        fig.add_bar(x=ok_runs["seq"], y=ok_runs["rows_extracted"],
                    name="rows extracted",
                    marker_color="rgba(76,111,255,0.35)",
                    customdata=ok_runs["run_label"],
                    hovertemplate="%{customdata}<br>%{y:,} rows<extra></extra>")
        fig.add_scatter(x=ok_runs["seq"],
                        y=ok_runs["duration_seconds"].astype(float),
                        name="duration (s)", mode="lines+markers",
                        line=dict(color=PALETTE[2], width=2),
                        marker=dict(size=5), secondary_y=True,
                        customdata=ok_runs["run_label"],
                        hovertemplate="%{customdata}<br>%{y:.2f}s<extra></extra>")
        for _, r in failed.iterrows():
            fig.add_vline(x=r["seq"], line_width=2, line_dash="dot",
                          line_color=STATUS_COLOUR["failed"])
        fig.update_xaxes(title_text="run #")
        fig.update_yaxes(title_text="rows", secondary_y=False)
        fig.update_yaxes(title_text="seconds", secondary_y=True, showgrid=False)
        st.plotly_chart(style_fig(fig, 360), width='stretch')
        if len(failed):
            st.caption(f"Dotted red lines mark the **{len(failed)} failed "
                       f"run(s)** — an empty export and a schema drift.")

    with p2:
        st.subheader("Duplicate rate per run")
        fig = px.line(ok_runs, x="seq",
                      y=ok_runs["duplicate_rate_pct"].astype(float),
                      markers=True, hover_name="run_label",
                      color_discrete_sequence=[PALETTE[3]],
                      labels={"y": "duplicate %", "seq": "run #"})
        fig.add_hline(y=float(ok_runs["duplicate_rate_pct"].astype(float).mean()),
                      line_dash="dash", line_color="rgba(128,128,128,0.6)",
                      annotation_text="mean")
        fig.update_yaxes(title="duplicate %")
        st.plotly_chart(style_fig(fig, 360), width='stretch')

    st.divider()
    q1, q2 = st.columns([3, 2])

    with q1:
        st.subheader("Data-quality rules — latest run")
        if dq_latest.empty:
            st.info("No data-quality events recorded for the latest run.")
        else:
            d = dq_latest.sort_values("failure_count")
            d = d[d["failure_count"] > 0]
            if d.empty:
                st.success("Every rule passed on the latest run.")
            else:
                fig = px.bar(
                    d, x="failure_count", y="rule_name", orientation="h",
                    color="severity",
                    color_discrete_map={"reject": "#E5484D",
                                        "warn": "#F6A935",
                                        "info": "#5B8DEF"},
                    labels={"rule_name": "", "failure_count": "rows failing"})
                st.plotly_chart(style_fig(fig, 340), width='stretch')
            st.caption("`reject` rules drop the row into "
                       "`rejected_registration`; `warn` rules null the field "
                       "and keep the participant.")

    with q2:
        st.subheader("How duplicates were caught")
        if dupes.empty:
            st.info("No duplicates on the latest run.")
        else:
            label = {"exact_row": "Identical re-submission",
                     "normalised_email": "Same mailbox, different spelling",
                     "phone_and_name": "Phone + name match"}
            d = dupes.copy()
            d["match_type"] = d["match_type"].map(lambda m: label.get(m, m))
            fig = px.pie(d, names="match_type", values="duplicates", hole=0.55,
                         color_discrete_sequence=[PALETTE[3], PALETTE[0], PALETTE[2]])
            fig.update_traces(textposition="inside", textinfo="value+percent")
            st.plotly_chart(style_fig(fig, 340), width='stretch')
            st.caption("The second category is the one a naive "
                       "`SELECT DISTINCT email` misses entirely.")

    st.divider()
    r1, r2 = st.columns(2)
    with r1:
        st.subheader("Rule history across all runs")
        st.dataframe(dq_rules, width='stretch', hide_index=True)
    with r2:
        st.subheader("Rejected rows (latest run)")
        st.dataframe(load(Q.REJECTED_SAMPLE, {"limit": 25}),
                     width='stretch', hide_index=True)

    with st.expander("All pipeline runs"):
        st.dataframe(runs.sort_values("run_id", ascending=False),
                     width='stretch', hide_index=True)


# ===========================================================================
# Judging
# ===========================================================================

with tab_judge:
    lb = load(Q.LEADERBOARD, {"limit": 40})
    dist = load(Q.SCORE_DISTRIBUTION)
    bias = load(Q.JUDGE_BIAS)

    if lb.empty:
        st.info("No scores recorded yet.")
    else:
        incomplete = int((~lb["fully_judged"]).sum())
        metric_row([
            ("Teams scored", f"{len(lb):,}", None),
            ("Top score", f"{float(lb['total_weighted_score'].max()):.2f}",
             "out of 100"),
            ("Median score",
             f"{float(lb['total_weighted_score'].median()):.2f}", None),
            ("Partly judged", f"{incomplete}",
             "missing a criterion" if incomplete else "all complete"),
        ])

        st.divider()
        j1, j2 = st.columns([3, 2])

        with j1:
            st.subheader("Leaderboard")
            top = lb.head(15).sort_values("total_weighted_score")
            fig = px.bar(top, x="total_weighted_score", y="team_name",
                         orientation="h", color="track_name",
                         color_discrete_sequence=PALETTE,
                         labels={"team_name": "",
                                 "total_weighted_score": "weighted score"})
            st.plotly_chart(style_fig(fig, 470), width='stretch')
            if incomplete:
                st.caption(f"**{incomplete}** team(s) are missing at least one "
                           f"criterion — flagged by `ops.aggregate_scores()` "
                           f"as `is_complete = false`. Check before awarding.")

        with j2:
            st.subheader("Average score by criterion")
            pivot = dist.pivot_table(index="criterion_name",
                                     columns="track_name",
                                     values="avg_raw")
            fig = px.imshow(pivot, text_auto=".1f", aspect="auto",
                            color_continuous_scale="Teal",
                            labels=dict(color="avg raw"))
            fig.update_xaxes(tickangle=-25)
            st.plotly_chart(style_fig(fig, 470), width='stretch')

        st.divider()
        st.subheader("Judge leniency")
        st.caption("Average raw score by judge. A wide spread is why the "
                   "roll-up averages across judges before weighting rather "
                   "than summing.")
        b = bias.sort_values("avg_raw_score")
        fig = px.bar(b, x="avg_raw_score", y="judge_name", orientation="h",
                     color="avg_raw_score", color_continuous_scale="RdYlGn",
                     labels={"judge_name": "", "avg_raw_score": "avg raw score"})
        fig.update_layout(coloraxis_showscale=False)
        st.plotly_chart(style_fig(fig, 460), width='stretch')

        with st.expander("Full leaderboard"):
            st.dataframe(lb, width='stretch', hide_index=True)
