"""
Every query the dashboard runs, in one place.

Kept separate from the Streamlit layout so the SQL can be read, tested and
EXPLAINed without launching a web server -- and so the index benchmark can
time exactly the queries the dashboard actually issues rather than a
hand-written approximation of them.

All of these run as the read-only role against the star schema.
"""

from __future__ import annotations

import pandas as pd

from etl.config import connect

# ---------------------------------------------------------------------------
# Registration trends
# ---------------------------------------------------------------------------

REGISTRATIONS_BY_DAY = """
SELECT d.full_date,
       d.day_name,
       d.is_weekend,
       d.reg_window_phase,
       COUNT(*)                                   AS registrations,
       SUM(COUNT(*)) OVER (ORDER BY d.full_date)  AS cumulative
FROM analytics.fact_registration f
JOIN analytics.dim_date d ON d.date_key = f.date_key
GROUP BY d.full_date, d.day_name, d.is_weekend, d.reg_window_phase
ORDER BY d.full_date
"""

REGISTRATIONS_BY_HOUR = """
SELECT EXTRACT(HOUR FROM registered_at)::int AS hour_of_day,
       COUNT(*)                              AS registrations
FROM analytics.fact_registration
GROUP BY 1
ORDER BY 1
"""

REGISTRATIONS_BY_PHASE = """
SELECT d.reg_window_phase,
       COUNT(*) AS registrations
FROM analytics.fact_registration f
JOIN analytics.dim_date d ON d.date_key = f.date_key
GROUP BY d.reg_window_phase
ORDER BY registrations DESC
"""

TOP_COLLEGES = """
SELECT c.college_name,
       c.city,
       c.state,
       c.region,
       c.is_host_college,
       COUNT(*)                             AS participants,
       COUNT(*) FILTER (WHERE f.checked_in) AS checked_in
FROM analytics.fact_registration f
JOIN analytics.dim_college c ON c.college_key = f.college_key
GROUP BY c.college_name, c.city, c.state, c.region, c.is_host_college
ORDER BY participants DESC
LIMIT %(limit)s
"""

BY_STATE = """
SELECT c.state,
       c.region,
       COUNT(*) AS participants
FROM analytics.fact_registration f
JOIN analytics.dim_college c ON c.college_key = f.college_key
GROUP BY c.state, c.region
ORDER BY participants DESC
"""

TRACK_DEMAND = """
SELECT t.track_name,
       t.capacity,
       COUNT(*) FILTER (WHERE f.preferred_track_key = t.track_key) AS preferred_by,
       COUNT(*) FILTER (WHERE f.assigned_track_key  = t.track_key) AS assigned_to
FROM analytics.dim_track t
LEFT JOIN analytics.fact_registration f
       ON t.track_key IN (f.preferred_track_key, f.assigned_track_key)
GROUP BY t.track_name, t.capacity, t.track_key
ORDER BY assigned_to DESC
"""

DEMOGRAPHICS = """
SELECT p.year_of_study,
       p.experience_level,
       p.gender,
       p.degree,
       p.has_github,
       p.heard_from,
       f.checked_in
FROM analytics.fact_registration f
JOIN analytics.dim_participant p ON p.participant_key = f.participant_key
"""

HEADLINE_COUNTS = """
SELECT (SELECT COUNT(*) FROM analytics.dim_college)  AS colleges,
       (SELECT COUNT(DISTINCT state) FROM analytics.dim_college) AS states,
       (SELECT COUNT(*) FROM analytics.dim_track)    AS tracks
"""

FUNNEL = """
SELECT
    (SELECT SUM(rows_extracted) FROM analytics.fact_pipeline_run
      WHERE run_id = (SELECT MAX(run_id) FROM analytics.fact_pipeline_run
                       WHERE status <> 'failed'))              AS raw_submissions,
    (SELECT COUNT(*) FROM analytics.fact_registration)         AS participants,
    (SELECT COUNT(*) FROM analytics.fact_registration
      WHERE team_key IS NOT NULL)                              AS on_a_team,
    (SELECT COUNT(*) FROM analytics.fact_registration
      WHERE checked_in)                                        AS checked_in,
    (SELECT COUNT(*) FROM analytics.dim_team
      WHERE has_submission)                                    AS teams_submitted,
    (SELECT COUNT(*) FROM analytics.dim_team)                  AS teams_total
"""

# ---------------------------------------------------------------------------
# Pipeline health
# ---------------------------------------------------------------------------

PIPELINE_RUNS = """
SELECT run_id,
       pipeline_name,
       started_at,
       duration_seconds,
       status,
       rows_extracted,
       rows_rejected,
       rows_deduplicated,
       rows_loaded,
       duplicate_rate_pct,
       validation_failures,
       reject_rule_count,
       warn_rule_count
FROM analytics.fact_pipeline_run
ORDER BY started_at
"""

DQ_BY_RULE = """
SELECT rule_name, severity, column_name,
       total_failures, runs_triggered, runs_evaluated, worst_run
FROM analytics.v_dq_rule_history
ORDER BY total_failures DESC
"""

DQ_LATEST_RUN = """
SELECT rule_name, severity, column_name, failure_count,
       rows_checked, failure_pct, sample_values
FROM analytics.v_dq_latest_run
ORDER BY (severity = 'reject') DESC, failure_count DESC
"""

DUPLICATE_BREAKDOWN = """
SELECT match_type, duplicates
FROM analytics.v_duplicate_breakdown
ORDER BY duplicates DESC
"""

REJECTED_SAMPLE = """
SELECT source_registration_id, failed_rules,
       full_name, email, college_name, registered_at
FROM analytics.v_rejected_registration
ORDER BY source_registration_id
LIMIT %(limit)s
"""

STAGE_SUMMARY = """
SELECT status, COUNT(*) AS runs,
       ROUND(AVG(duration_seconds)::numeric, 3) AS avg_seconds
FROM analytics.fact_pipeline_run
GROUP BY status
ORDER BY runs DESC
"""

# ---------------------------------------------------------------------------
# Judging
# ---------------------------------------------------------------------------

LEADERBOARD = """
SELECT team_name, track_name, team_size, status,
       total_weighted_score, judges_scored, criteria_scored, fully_judged
FROM analytics.v_leaderboard
ORDER BY total_weighted_score DESC
LIMIT %(limit)s
"""

SCORE_DISTRIBUTION = """
SELECT t.track_name,
       s.criterion_name,
       ROUND(AVG(s.raw_score)::numeric, 2) AS avg_raw,
       COUNT(*)                            AS cells
FROM analytics.fact_score s
JOIN analytics.dim_team t ON t.team_key = s.team_key
GROUP BY t.track_name, s.criterion_name
ORDER BY t.track_name, s.criterion_name
"""

JUDGE_BIAS = """
SELECT j.judge_name,
       j.organisation,
       COUNT(DISTINCT s.team_key)          AS teams_scored,
       ROUND(AVG(s.raw_score)::numeric, 2) AS avg_raw_score
FROM analytics.fact_score s
JOIN analytics.dim_judge j ON j.judge_key = s.judge_key
GROUP BY j.judge_name, j.organisation
ORDER BY avg_raw_score DESC
"""


_ENGINE = None


def _engine():
    """A pooled SQLAlchemy engine for the read-only role.

    pandas warns (correctly) about raw DBAPI connections, and the dashboard
    issues ~15 queries per page load, so a connection pool is worth having
    rather than opening a socket per chart.
    """
    global _ENGINE
    if _ENGINE is None:
        from sqlalchemy import create_engine
        from etl.config import READONLY_DB as R
        _ENGINE = create_engine(
            f"postgresql+psycopg2://{R['user']}:{R['password']}"
            f"@{R['host']}:{R['port']}/{R['dbname']}",
            pool_size=4, max_overflow=4, pool_pre_ping=True,
            connect_args={"options": "-c default_transaction_read_only=on"},
        )
    return _ENGINE


def q(sql: str, params: dict | None = None) -> pd.DataFrame:
    """Run a query as the read-only role and return a DataFrame."""
    return pd.read_sql(sql, _engine(), params=params)


# The dashboard's own SQL, used by the index benchmark so it measures the
# real workload rather than a proxy for it.
BENCHMARK_QUERIES: dict[str, tuple[str, dict]] = {
    "registrations_by_day":   (REGISTRATIONS_BY_DAY, {}),
    "registrations_by_hour":  (REGISTRATIONS_BY_HOUR, {}),
    "registrations_by_phase": (REGISTRATIONS_BY_PHASE, {}),
    "top_colleges":           (TOP_COLLEGES, {"limit": 20}),
    "by_state":               (BY_STATE, {}),
    "track_demand":           (TRACK_DEMAND, {}),
    "funnel":                 (FUNNEL, {}),
    "pipeline_runs":          (PIPELINE_RUNS, {}),
    "dq_by_rule":             (DQ_BY_RULE, {}),
    "dq_latest_run":          (DQ_LATEST_RUN, {}),
    "duplicate_breakdown":    (DUPLICATE_BREAKDOWN, {}),
    "leaderboard":            (LEADERBOARD, {"limit": 25}),
    "score_distribution":     (SCORE_DISTRIBUTION, {}),
    "judge_bias":             (JUDGE_BIAS, {}),
}
