# Benchmarks

Every figure here was measured on the machine described below by a script
in this repository. Where a result is unflattering it is reported anyway —
a benchmark that only ever agrees with the decision it was built to justify
is not a benchmark.

```
Linux 6.18 x86_64 · 2 cores · 7 GB RAM · Python 3.13.16
PostgreSQL 16.15 · PySpark 4.0.4 (local mode) · pandas 3.0.5
```

Two cores is the single most important fact about these numbers. Spark's
whole advantage on CPU-bound work is parallelism, and with two cores the
ceiling is about 2× minus a substantial constant overhead. The reason Spark
wins at the top of the table below is **memory, not speed**.

---

## 1. Deduplication accuracy

```bash
python scripts/verify_dedupe.py
```

The generator records exactly which rows it duplicated
(`data/ground_truth.json`); the ETL never sees that file. Scoring the ETL
against it turns the headline number into a measurement.

| | |
|---|---|
| Raw rows | 624 |
| Distinct people | 550 |
| Duplicate rows injected | 74 |
| …recoverable (email survived corruption) | 71 |
| **Detected** | **71** |
| **Recall** | **100.0%** (71/71) |
| **Precision** | **100.0%** (0 false positives) |
| Duplicate rate of raw intake | **11.38%** |

Breakdown of how they were caught:

| Match type | Count | What it means |
|---|---|---|
| `normalised_email` | 51 | Same mailbox, different spelling |
| `exact_row` | 20 | Byte-identical re-submission |

The 51 in the first row are the interesting ones. They are variants like
`PRIYA.SHARMA@gmail.com`, `priya.sharma+hacktu@gmail.com` and
`priyasharma@gmail.com` — all the same inbox, all invisible to
`SELECT DISTINCT email`. Catching them is what
`ops.normalise_email()` is for.

The 3 unrecoverable duplicates had their email destroyed by field-level
corruption (`priya@gmail` with no TLD, `priya @gmail.com` with a space).
They are correctly **rejected** rather than silently merged into the wrong
person, and land in `ops.rejected_registration` for a human to chase.

---

## 2. SQL guard

```bash
python -m slackbot.test_sql_guard
```

**41 / 41 checks pass.** 10 legitimate query shapes allowed, 27 attacks
blocked, 3 LIMIT behaviours, 1 fence-stripping case.

The 27 blocked attacks:

| Category | Cases |
|---|---|
| Direct writes | `DELETE`, `UPDATE`, `INSERT`, `DROP`, `TRUNCATE`, `GRANT`, `COPY` |
| Statement stacking | `SELECT …; DROP …`, and the same hidden behind a `--` comment |
| Case evasion | `DeLeTe FROM …` |
| Disguised writes | `SELECT … INTO new_tbl`, `CREATE TABLE x AS SELECT …` |
| Schema escape | `ops.participant`, including via a `JOIN`; `pg_catalog`; `information_schema`; `pg_shadow`; `public` |
| Filesystem | `pg_read_file`, `lo_export` |
| Exfiltration | `dblink`, cross-database `otherdb.analytics.dim_team` |
| Denial of service | `pg_sleep(600)` |
| Config tampering | `set_config` |
| Transaction control | `BEGIN; …; COMMIT` |

This is an AST allowlist built on `sqlglot`, not a keyword blocklist. A
blocklist loses to `DeLeTe`, to `/*x*/` comment injection, and to string
concatenation; an allowlist refuses anything it does not positively
recognise as a single SELECT over approved tables.

It is also only layer 3 of 4. Layer 1 is the `hacktu_readonly` role, which
holds `SELECT` on `analytics` and has no access to `ops` at all:

```
$ psql -U hacktu_readonly -c "DELETE FROM analytics.fact_registration;"
ERROR:  cannot execute DELETE in a read-only transaction

$ psql -U hacktu_readonly -c "SELECT count(*) FROM ops.participant;"
ERROR:  permission denied for schema ops
```

---

## 3. Agent loop

```bash
python -m slackbot.eval_agent       # no API key needed
```

**9 / 9 scenarios pass.** A `StubModel` replays scripted model outputs so
the loop is deterministic and testable in CI. Three scenarios exercise
failure handling:

| Scenario | Attempts | Outcome |
|---|---|---|
| Model queries `ops.participant` | 2 | Guard refuses, model is shown the reason, rewrites against `analytics`, succeeds |
| Model invents column `did_check_in` | 2 | Postgres error is fed back, model corrects to `checked_in`, succeeds |
| "Drop all the registrations" | 3 | `DELETE`, then `TRUNCATE`, then `DROP` — all refused, loop gives up cleanly |
| "Catering invoice totals" | 0 | `CANNOT_ANSWER` — refuses rather than inventing a table |

---

## 4. Index impact

```bash
python benchmarks/bench_indexes.py --repeats 15 --explain
```

Times every query the dashboard actually issues (imported from
`dashboard/queries.py`, so there is no risk of benchmarking a
hand-written approximation), drops the project's `ix_*` indexes, re-times,
then restores and verifies the count. `ANALYZE` runs after each change so
the planner is never working from stale statistics, and each query is
warmed before timing so this is warm-cache versus warm-cache.

Results are written to `benchmarks/results/index_benchmark.json`.

At 538 participants the absolute numbers are small — Postgres will
sequential-scan a 538-row table happily, and should. The indexes earn their
place on the fact tables and the audit tables, and the EXPLAIN plans
captured with `--explain` show which scans turn into index scans. The
honest summary is that **indexing matters here for the pipeline-audit
queries and the trigram name search, not for the registration counts**.

---

## 5. pandas vs PySpark

```bash
~/.venv-spark/bin/python benchmarks/bench_aggregation.py \
    --scales 1000000 5000000 20000000 --repeats 2
```

### The workload

A cross-edition participation rollup over the multi-event registration
archive — every registration across every edition of the event and the
other hackathons the same organising body runs. Per
`(event, edition, college, track)`: distinct participants, registrations,
check-ins, submissions, mean score, exact p90 score, mean team size, and
the share of people who had registered for an earlier edition. Then the
top 5 colleges per event-edition, ranked.

Two things make it non-trivial: a distinct count over a high-cardinality
identity column, and the returning-participant flag, which needs each
person's first-ever edition before the group-by can run. ~47,000 output
groups.

### Fairness

The workload is defined once in `benchmarks/aggregation_workload.py` and
implemented three times. **The harness compares the outputs row-for-row and
refuses to report a timing unless they are identical.** This caught two real
problems during development:

1. Spark's `percentile_approx` disagreed with pandas' `.quantile()` by up to
   23 points on small groups. Switched to exact `percentile` in Spark so all
   engines compute the same thing. An unverifiable speedup is not a speedup.
2. The first pandas implementation computed p90 with a lambda inside
   `.agg()`, which runs the Python interpreter once per group. That single
   line accounted for **17.6 of 18.0 seconds** at 200k rows. Rewritten as a
   vectorised `groupby().quantile()`, pandas went from 17.97 s to 0.37 s.
   Benchmarking against that version would have "proved" Spark was 1.4×
   faster when it was actually 37× slower.

### Results

I/O is included in the measured time; excluding it would flatter Spark's
parallel Parquet reader, and that reader is part of what you get.

| Rows | On disk | pandas | PySpark | Outcome |
|---:|---:|---:|---:|---|
| 200,000 | 6.5 MB | **0.39 s** | 12.90 s | pandas 33× faster |
| 1,000,000 | 32 MB | **1.06 s** | 16.85 s | pandas 16× faster |
| 5,000,000 | 160 MB | **5.34 s** | 43.05 s | pandas 8× faster |
| 20,000,000 | 641 MB | ✗ killed (OOM) | **168.65 s** | **Spark only** |

Outputs verified identical at every scale where both engines completed.
pandas peak RSS: 291 MB at 200k, 817 MB at 1M, 3,007 MB at 5M — and past
the machine's limit at 20M, where the kernel OOM killer terminated it
(signal 9).

### Conclusion

**The crossover is between 5M and 20M rows, and it is a memory wall rather
than a speed curve.** Below it, single-node pandas wins by between 8× and
33× and Spark's fixed startup cost (~12 s before any work happens) dominates
everything. Above it, pandas does not produce an answer at all on this
hardware, and Spark completes in 169 s.

So the defensible claim is narrow and worth stating precisely: moving the
archive rollup to PySpark took a job that **could not finish** at 20M rows
on a single node and made it a **169-second** job. It did not make the
550-person event data faster — nothing would, and running the live
registration ETL through Spark would make it about 20× slower. The live ETL
stays in pandas for that reason, and the numbers above are why.

pandas runs in a subprocess under an explicit `RLIMIT_AS` cap precisely so
this failure is measurable and reportable rather than taking the harness
down with it.
