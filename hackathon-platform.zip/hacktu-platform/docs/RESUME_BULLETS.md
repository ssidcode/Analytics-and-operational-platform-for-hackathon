# Resume bullets — with the brackets filled in

Every number below traces to a script in this repo. The command that
produces it is listed under each bullet so you can re-run it before an
interview and so you can answer "how did you measure that?" without
hesitating.

---

## The bullets

> **HackTU Analytics & Operations Platform**
> PostgreSQL, Python, PySpark, Slack API (Bolt), Streamlit, Plotly, LLM Agents

- Designed normalized OLTP (3NF) and OLAP (star schema) databases for a
  550-participant hackathon across 71 institutions; wrote stored procedures
  for capacity-constrained track assignment and weighted score aggregation
  across 1,897 judge scores.

- Built a Python ETL pipeline with 10 data-quality rules at three
  severities and indexing-based query optimization, eliminating **100% of
  recoverable duplicate registrations (71 of 624 raw rows, an 11.4%
  duplicate rate)** at 100% precision, verified against ground truth; moved
  the cross-edition archive rollup to PySpark, taking a job that **exceeded
  single-node memory and could not complete at 20M records** down to **169
  seconds**.

- Built a Slack bot (Slack API, Bolt) with an agentic text-to-SQL assistant
  that self-corrects from guard refusals and database errors, behind a
  four-layer read-only safety stack (scoped Postgres role, read-only
  session with 8s timeout, AST allowlist, LIMIT injection) that **blocks
  27/27 adversarial SQL cases**, letting non-technical organizers query the
  database in natural language from the channels they already use.

- Developed a Streamlit and Plotly dashboard for registration trends and
  pipeline health — **run duration, validation failures, duplicate rate per
  run, data-quality rule breakdown, and rejected-row inspection across 48
  recorded ETL runs** — linked directly from the bot's replies.

---

## Where each number comes from

| Number | Source | Command |
|---|---|---|
| 550 participants, 71 institutions, 17 states | generator + loaded DB | `python scripts/generate_synthetic_data.py` |
| 624 raw rows → 538 loaded | ETL run record | `python -m etl.pipeline` |
| **71 duplicates, 11.4%, 100% recall / precision** | ground-truth scoring | `python scripts/verify_dedupe.py` |
| 10 data-quality rules, 3 severities | `etl/validators.py` | `build_rules()` |
| 15 rows rejected | `ops.rejected_registration` | `python -m etl.pipeline` |
| 1,897 judge scores, 171 teams, 18 judges | seeded operations | `python scripts/seed_event_operations.py` |
| **27/27 attacks blocked, 41/41 checks** | guard test suite | `python -m slackbot.test_sql_guard` |
| 9/9 agent scenarios, 2 self-correction paths | agent eval | `python -m slackbot.eval_agent` |
| **20M rows: pandas OOM → Spark 169 s** | scale sweep | `~/.venv-spark/bin/python benchmarks/bench_aggregation.py` |
| 48 ETL runs, 0.61 s full load | replayed run history | `python scripts/simulate_run_history.py` |

---

## The one number you have to supply

The original draft had *"letting [N] non-technical organizers query the
database"*. That is a fact about **people, not about code**, and nothing in
this repository can measure it. Put in the real size of your organising
team — the people who actually had the bot in their channel. If that was 8
organisers, say 8. If you are not sure, the bullet above reads fine without
a number, and an unverifiable count is worse than no count.

The same applies to anything you want to say about time saved. If you
tracked it, use it. If you did not, "reducing manual work" without a
fabricated percentage is the stronger claim, because you can defend it.

---

## What changed from the draft, and why

**"cutting duplicate registration records by [X%]" → "eliminating 100% of
recoverable duplicates (71 of 624 raw rows, an 11.4% duplicate rate)"**

"Cutting duplicates by X%" is ambiguous — it could mean the pipeline removed
X% of rows, or reduced the duplicate rate by X percentage points. The
measured facts are cleaner: duplicates were 11.4% of raw intake, and the ETL
caught all of the ones that were still identifiable, with no false
positives. The qualifier "recoverable" is doing real work: 3 of the 74
injected duplicates had their email destroyed by other corruption and were
correctly **rejected** rather than merged into the wrong person. If an
interviewer asks "so you missed 3?", that is the answer, and it is a better
answer than 96%.

**"reducing runtime from [A] to [B] on [N] records" → "exceeded single-node
memory and could not complete at 20M records, down to 169 seconds"**

This is the change worth understanding before you are asked about it. I
benchmarked pandas against PySpark on the identical workload at four scales,
with row-for-row output verification. **PySpark is dramatically slower at
small scale** — 33× slower at 200k rows, 8× slower at 5M — because its
fixed startup cost is about 12 seconds and this machine has 2 cores. It only
wins at 20M rows, and it wins because pandas gets killed by the OOM killer
there, not because Spark is fast.

So the honest framing is a *capability* claim, not a *latency* claim: Spark
made a job possible that was not possible on one node. Claiming "reduced
runtime from 45s to 8s" would be the kind of number that collapses the
moment someone asks what the baseline was.

It also means the bullet should **not** suggest you ran the 550-person
registration ETL through Spark. You did not, and should not have — it runs
in 0.61 seconds in pandas and Spark would make it roughly 20× slower.
Knowing when *not* to reach for Spark is a better signal than the speedup
would have been. `docs/BENCHMARKS.md` has the full table if you want to walk
someone through it.

**Dashboard metrics confirmed, not changed**

The draft listed run duration, validation failures and duplicate rate as a
plan. All three are now really on the Pipeline Health tab, so the bullet
stands — and I added what else is actually there (per-rule data-quality
breakdown, duplicate match-type split, rejected-row inspection, 48 runs of
history including 2 genuine failures), since those are the parts that make
it an operations tool rather than a chart.

---

## Questions this invites, and the answers

**"Why is the duplicate rate 11.4% — isn't that high?"**
It is realistic. Students re-submit when they do not get a confirmation
email. 20 of the 71 were byte-identical re-posts; 51 were the same mailbox
reached by a different spelling (casing, Gmail dots, `+tags`).

**"How do you know the dedupe is correct?"**
The generator writes `data/ground_truth.json` recording exactly which rows
it duplicated. The ETL never reads it. `verify_dedupe.py` scores one against
the other: 71/71 recall, 0 false positives.

**"Your star schema is only 538 rows. Why bother?"**
The star schema is not there for query speed at 538 rows — Postgres will
scan that happily. It is there because the text-to-SQL agent writes against
it, and a denormalised model where most questions need zero or one join is
what makes generated SQL reliable. The read-only role is scoped to that
schema alone, which is also the first layer of the safety story.

**"What stops the LLM from dropping a table?"**
Four things, and the outermost does not depend on my code being right: the
role it connects as holds `SELECT` on one schema and cannot see `ops` at
all. Then a read-only session with an 8-second statement timeout, then an
AST allowlist (not a regex blocklist — those lose to `DeLeTe` and comment
injection), then LIMIT injection.

**"Why not just use `SELECT DISTINCT email`?"**
It would have caught 20 of 71 duplicates and missed the other 51.
