"""Shared configuration and database connection helpers."""

from __future__ import annotations

import os
from contextlib import contextmanager
from pathlib import Path

import psycopg2
import psycopg2.extras

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:                                  # dotenv is optional
    pass

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
SQL_DIR = ROOT / "sql"
BENCH_DIR = ROOT / "benchmarks"

DB = {
    "host":     os.getenv("PGHOST", "127.0.0.1"),
    "port":     int(os.getenv("PGPORT", "5432")),
    "dbname":   os.getenv("PGDATABASE", "hacktu"),
    "user":     os.getenv("PGUSER", "hacktu"),
    "password": os.getenv("PGPASSWORD", "hacktu_dev"),
}

# A second role used by the Slack bot. It holds SELECT on `analytics` and
# nothing else -- the first layer of the read-only guarantee, enforced by the
# database rather than by the agent's good intentions.
READONLY_DB = {**DB,
               "user": os.getenv("HACKTU_RO_USER", "hacktu_readonly"),
               "password": os.getenv("HACKTU_RO_PASSWORD", "hacktu_ro_dev")}

EVENT = {
    "name": "HackTU 6.0",
    "host_college": "Thapar Institute of Engineering and Technology",
    "host_state": "Punjab",
    "reg_open": "2026-01-05",
    "reg_close": "2026-02-18",
    "event_start": "2026-02-20",
}

DASHBOARD_URL = os.getenv("HACKTU_DASHBOARD_URL", "http://localhost:8501")


def dsn(readonly: bool = False) -> str:
    cfg = READONLY_DB if readonly else DB
    return (f"host={cfg['host']} port={cfg['port']} dbname={cfg['dbname']} "
            f"user={cfg['user']} password={cfg['password']}")


@contextmanager
def connect(readonly: bool = False, autocommit: bool = False):
    cfg = READONLY_DB if readonly else DB
    conn = psycopg2.connect(**cfg)
    conn.autocommit = autocommit
    if readonly:
        # Belt and braces: even if the role were over-granted, the session
        # itself refuses to write.
        with conn.cursor() as cur:
            cur.execute("SET default_transaction_read_only = on")
        conn.commit()
    try:
        yield conn
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


@contextmanager
def cursor(readonly: bool = False, autocommit: bool = False, dict_rows: bool = True):
    with connect(readonly=readonly, autocommit=autocommit) as conn:
        factory = psycopg2.extras.RealDictCursor if dict_rows else None
        with conn.cursor(cursor_factory=factory) as cur:
            yield cur
        if not autocommit and not readonly:
            conn.commit()
