"""
HackTU registration ETL.

    extract -> validate -> transform -> deduplicate -> load -> star refresh

Every stage reports into ops.etl_run / ops.data_quality_event, which is what
the dashboard's pipeline-health tab and the Slack bot's /pipeline command
read. Nothing is dropped silently: rejected rows land in
ops.rejected_registration and every collapsed duplicate is recorded in
ops.duplicate_registration with the pair of registration ids involved.

Usage
-----
    python -m etl.pipeline                       # full run on the default CSV
    python -m etl.pipeline --source path.csv
    python -m etl.pipeline --skip-star           # load OLTP only
"""

from __future__ import annotations

import argparse
import json
import logging
import subprocess
import time
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path

import pandas as pd
import psycopg2.extras

from etl import validators as V
from etl.config import DATA_DIR, EVENT, connect

LOG = logging.getLogger("hacktu.etl")

RAW_COLUMNS = [
    "registration_id", "full_name", "email", "phone", "gender",
    "college_name", "college_city", "college_state", "degree", "branch",
    "year_of_study", "graduation_year", "roll_number", "preferred_track",
    "experience_level", "github_handle", "tshirt_size", "dietary_preference",
    "accommodation_required", "heard_from", "registered_at",
]


@dataclass
class RunMetrics:
    run_id: int | None = None
    pipeline_name: str = "registration_intake"
    source_file: str = ""
    started_at: datetime | None = None
    finished_at: datetime | None = None
    duration_seconds: float = 0.0
    status: str = "running"
    rows_extracted: int = 0
    rows_rejected: int = 0
    rows_deduplicated: int = 0
    rows_loaded: int = 0
    duplicate_rate_pct: float = 0.0
    validation_failures: int = 0
    stage_timings: dict = None
    error_message: str | None = None

    def as_dict(self) -> dict:
        d = asdict(self)
        for k in ("started_at", "finished_at"):
            if d[k] is not None:
                d[k] = d[k].isoformat()
        return d


def _git_sha() -> str | None:
    try:
        return subprocess.check_output(
            ["git", "rev-parse", "--short", "HEAD"],
            stderr=subprocess.DEVNULL, text=True).strip()
    except Exception:
        return None


# ===========================================================================
# Stages
# ===========================================================================

def extract(source: Path) -> pd.DataFrame:
    """Read the raw export. Everything stays a string until validated."""
    df = pd.read_csv(source, dtype=str, keep_default_na=False, na_values=[""])
    missing = [c for c in RAW_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"source file is missing required columns: {missing}")
    LOG.info("extracted %d rows from %s", len(df), source.name)
    return df


def validate(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, list[V.RuleResult]]:
    """Split the frame into rows that can be loaded and rows that cannot."""
    reg_open = datetime.fromisoformat(EVENT["reg_open"])
    reg_close = datetime.fromisoformat(EVENT["reg_close"] + "T23:59:59")

    rules = V.build_rules(reg_open, reg_close)
    results = V.run_rules(df, rules)

    reject_mask = pd.Series(False, index=df.index)
    failed_rules: dict[int, list[str]] = {}
    for res in results:
        if res.rule.severity != "reject":
            continue
        reject_mask |= res.mask
        for idx in df.index[res.mask]:
            failed_rules.setdefault(idx, []).append(res.rule.name)

    rejected = df.loc[reject_mask].copy()
    rejected["_failed_rules"] = [failed_rules.get(i, []) for i in rejected.index]
    accepted = df.loc[~reject_mask].copy()

    total_failures = sum(r.failure_count for r in results
                         if r.rule.severity in ("reject", "warn"))
    LOG.info("validation: %d accepted, %d rejected, %d rule failures "
             "across %d rules", len(accepted), len(rejected), total_failures,
             sum(1 for r in results if r.failure_count))
    return accepted, rejected, results


def transform(df: pd.DataFrame) -> pd.DataFrame:
    """Coerce to typed, canonical values. Warn-level dirt becomes NULL."""
    out = pd.DataFrame(index=df.index)
    out["source_registration_id"] = df["registration_id"].astype(str).str.strip()
    out["full_name"] = df["full_name"].map(V.normalise_name)
    out["email"] = df["email"].astype(str).str.strip().str.lower()
    out["email_key"] = df["email"].map(V.normalise_email)
    out["phone_e164"] = df["phone"].map(V.normalise_phone)
    out["gender"] = df["gender"].map(
        lambda v: None if v is None or str(v).strip() == "" else str(v).strip())

    out["college_name"] = df["college_name"].map(V.normalise_college)
    out["college_key"] = df["college_name"].map(V.college_key)
    out["college_city"] = df["college_city"].map(
        lambda v: None if v is None or str(v).strip() == "" else str(v).strip())
    out["college_state"] = df["college_state"].map(
        lambda v: None if v is None or str(v).strip() == "" else str(v).strip())

    out["degree"] = df["degree"].str.strip()
    out["branch"] = df["branch"].str.strip()

    study = pd.to_numeric(df["year_of_study"], errors="coerce")
    out["year_of_study"] = study.where(
        study.between(V.MIN_STUDY_YEAR, V.MAX_STUDY_YEAR)).astype("Int64")

    grad = pd.to_numeric(df["graduation_year"], errors="coerce")
    out["graduation_year"] = grad.where(
        grad.between(V.MIN_GRAD_YEAR, V.MAX_GRAD_YEAR)).astype("Int64")

    out["roll_number"] = df["roll_number"].str.strip()
    out["preferred_track"] = df["preferred_track"].str.strip()
    out["experience_level"] = df["experience_level"].str.strip()
    out["github_handle"] = df["github_handle"].fillna("").str.strip()

    tshirt = df["tshirt_size"].fillna("").str.strip().str.upper()
    out["tshirt_size"] = tshirt.where(tshirt.isin(V.VALID_TSHIRT))

    out["dietary_preference"] = df["dietary_preference"].str.strip()
    out["accommodation_required"] = (
        df["accommodation_required"].fillna("No").str.strip().str.lower()
        .isin({"yes", "y", "true", "1"}))
    out["heard_from"] = df["heard_from"].str.strip()
    out["registered_at"] = pd.to_datetime(df["registered_at"], errors="coerce")
    return out


def deduplicate(df: pd.DataFrame) -> tuple[pd.DataFrame, list[dict]]:
    """
    Collapse multiple submissions by the same person.

    Identity is `email_key` (see validators.normalise_email). The surviving
    row is the *earliest* submission -- the person's first intent -- except
    that non-null values from later submissions fill gaps in it, because a
    re-submission is usually someone correcting a field they left blank.

    Returns the deduplicated frame plus an audit record per dropped row.
    """
    df = df.sort_values(["email_key", "registered_at", "source_registration_id"],
                        kind="mergesort")

    dup_mask = df.duplicated(subset=["email_key"], keep="first")

    # Classify each dropped row against the keeper it collapses into:
    #   exact_row        -- byte-identical submission, the form was double-posted
    #   normalised_email -- same mailbox, different spelling (case, dots, +tag)
    # Done as a merge rather than a per-row lookup so the cost stays linear;
    # at 600 rows it is irrelevant, at the 1M-row scale used in the Spark
    # benchmark a Python loop here would dominate the whole pipeline.
    audit: list[dict] = []
    if dup_mask.any():
        keepers = (df.loc[~dup_mask]
                     .drop_duplicates(subset=["email_key"], keep="first")
                     .set_index("email_key"))
        dropped = df.loc[dup_mask]

        # Compare every substantive field; identity fields and the timestamp
        # are excluded because they differ by construction.
        compare_cols = [c for c in df.columns
                        if c not in {"source_registration_id", "registered_at",
                                     "email_key"}]

        aligned = keepers.reindex(dropped["email_key"].to_numpy())
        same = pd.Series(True, index=dropped.index)
        for col in compare_cols:
            left = dropped[col].to_numpy()
            right = aligned[col].to_numpy()
            eq = pd.Series(left, index=dropped.index).eq(
                pd.Series(right, index=dropped.index))
            both_na = pd.isna(left) & pd.isna(right)
            same &= eq | pd.Series(both_na, index=dropped.index)

        audit = [
            {
                "kept_registration_id": kept_id,
                "dropped_registration_id": dropped_id,
                "email_key": key,
                "match_type": "exact_row" if is_same else "normalised_email",
            }
            for kept_id, dropped_id, key, is_same in zip(
                aligned["source_registration_id"].to_numpy(),
                dropped["source_registration_id"].to_numpy(),
                dropped["email_key"].to_numpy(),
                same.to_numpy(),
            )
        ]

    # Gap-fill the keeper from its later submissions before dropping them.
    fillable = ["phone_e164", "college_name", "college_key", "college_city",
                "college_state", "github_handle", "tshirt_size",
                "year_of_study", "graduation_year", "roll_number"]
    grouped = df.groupby("email_key", sort=False)
    filled = grouped[fillable].transform(lambda s: s.ffill().bfill())
    df[fillable] = filled

    deduped = df.loc[~dup_mask].copy()
    deduped["source_row_count"] = (
        grouped["source_registration_id"].transform("size").loc[~dup_mask].astype(int))

    LOG.info("dedupe: %d -> %d rows (%d duplicates folded)",
             len(df), len(deduped), int(dup_mask.sum()))
    return deduped, audit


# ===========================================================================
# Load
# ===========================================================================

def _start_run(conn, metrics: RunMetrics) -> int:
    with conn.cursor() as cur:
        cur.execute("""
            INSERT INTO ops.etl_run
                (pipeline_name, started_at, status, source_file, git_sha)
            VALUES (%s, %s, 'running', %s, %s)
            RETURNING run_id
        """, (metrics.pipeline_name, metrics.started_at,
              metrics.source_file, _git_sha()))
        return cur.fetchone()[0]


def _finish_run(conn, metrics: RunMetrics) -> None:
    with conn.cursor() as cur:
        cur.execute("""
            UPDATE ops.etl_run
               SET finished_at = %s, duration_seconds = %s, status = %s,
                   rows_extracted = %s, rows_rejected = %s,
                   rows_deduplicated = %s, rows_loaded = %s,
                   duplicate_rate_pct = %s, error_message = %s
             WHERE run_id = %s
        """, (metrics.finished_at, metrics.duration_seconds, metrics.status,
              metrics.rows_extracted, metrics.rows_rejected,
              metrics.rows_deduplicated, metrics.rows_loaded,
              metrics.duplicate_rate_pct, metrics.error_message,
              metrics.run_id))


def _record_quality(conn, run_id: int, results: list[V.RuleResult]) -> None:
    rows = [(run_id, r.rule.name, r.rule.severity, r.rule.column,
             r.failure_count, r.rows_checked, json.dumps(r.sample_values))
            for r in results]
    with conn.cursor() as cur:
        psycopg2.extras.execute_values(cur, """
            INSERT INTO ops.data_quality_event
                (run_id, rule_name, severity, column_name,
                 failure_count, rows_checked, sample_values)
            VALUES %s
        """, rows)


def _record_rejects(conn, run_id: int, rejected: pd.DataFrame) -> None:
    if rejected.empty:
        return
    rows = []
    for _, row in rejected.iterrows():
        payload = {k: (None if pd.isna(v) else str(v))
                   for k, v in row.items() if k != "_failed_rules"}
        rows.append((run_id, row.get("registration_id"),
                     json.dumps(payload), row["_failed_rules"]))
    with conn.cursor() as cur:
        psycopg2.extras.execute_values(cur, """
            INSERT INTO ops.rejected_registration
                (run_id, source_registration_id, payload, failed_rules)
            VALUES %s
        """, rows)


def _record_duplicates(conn, run_id: int, audit: list[dict]) -> None:
    if not audit:
        return
    rows = [(run_id, a["kept_registration_id"], a["dropped_registration_id"],
             a["email_key"], a["match_type"]) for a in audit]
    with conn.cursor() as cur:
        psycopg2.extras.execute_values(cur, """
            INSERT INTO ops.duplicate_registration
                (run_id, kept_registration_id, dropped_registration_id,
                 email_key, match_type)
            VALUES %s
        """, rows)


def _upsert_colleges(conn, df: pd.DataFrame) -> dict[str, int]:
    have = df[df["college_key"].notna()][
        ["college_key", "college_name", "college_city", "college_state"]
    ].drop_duplicates(subset=["college_key"])
    if have.empty:
        return {}
    rows = [(r.college_name, r.college_city or "Unknown",
             r.college_state or "Unknown", r.college_key)
            for r in have.itertuples()]
    with conn.cursor() as cur:
        psycopg2.extras.execute_values(cur, """
            INSERT INTO ops.college (college_name, city, state, name_key)
            VALUES %s
            ON CONFLICT (name_key) DO UPDATE SET college_name = EXCLUDED.college_name
        """, rows)
        cur.execute("SELECT name_key, college_id FROM ops.college")
        return dict(cur.fetchall())


def _seed_tracks(conn) -> dict[str, int]:
    tracks_csv = DATA_DIR / "tracks.csv"
    if tracks_csv.exists():
        tdf = pd.read_csv(tracks_csv)
        rows = [(r.track_name, r.description, int(r.capacity))
                for r in tdf.itertuples()]
        with conn.cursor() as cur:
            psycopg2.extras.execute_values(cur, """
                INSERT INTO ops.track (track_name, description, capacity)
                VALUES %s
                ON CONFLICT (track_name) DO UPDATE
                   SET description = EXCLUDED.description,
                       capacity    = EXCLUDED.capacity
            """, rows)
    with conn.cursor() as cur:
        cur.execute("SELECT track_name, track_id FROM ops.track")
        return dict(cur.fetchall())


def load(conn, df: pd.DataFrame) -> int:
    track_ids = _seed_tracks(conn)
    college_ids = _upsert_colleges(conn, df)

    rows = []
    for r in df.itertuples():
        rows.append((
            r.source_registration_id,
            r.full_name,
            r.email,
            r.email_key,
            r.phone_e164,
            r.gender,
            college_ids.get(r.college_key) if r.college_key else None,
            r.degree,
            r.branch,
            None if pd.isna(r.year_of_study) else int(r.year_of_study),
            None if pd.isna(r.graduation_year) else int(r.graduation_year),
            r.roll_number,
            r.experience_level,
            r.github_handle or None,
            r.tshirt_size if isinstance(r.tshirt_size, str) else None,
            r.dietary_preference,
            bool(r.accommodation_required),
            r.heard_from,
            track_ids.get(r.preferred_track),
            r.registered_at.to_pydatetime(),
            int(r.source_row_count),
        ))

    with conn.cursor() as cur:
        psycopg2.extras.execute_values(cur, """
            INSERT INTO ops.participant (
                source_registration_id, full_name, email, email_key, phone_e164,
                gender, college_id, degree, branch, year_of_study,
                graduation_year, roll_number, experience_level, github_handle,
                tshirt_size, dietary_preference, accommodation_required,
                heard_from, preferred_track_id, registered_at, source_row_count)
            VALUES %s
            ON CONFLICT (email_key) DO UPDATE SET
                full_name        = EXCLUDED.full_name,
                phone_e164       = COALESCE(EXCLUDED.phone_e164, ops.participant.phone_e164),
                college_id       = COALESCE(EXCLUDED.college_id, ops.participant.college_id),
                source_row_count = EXCLUDED.source_row_count,
                updated_at       = now()
        """, rows, page_size=500)
        return cur.rowcount


# ===========================================================================
# Orchestration
# ===========================================================================

def run_pipeline(source: Path, skip_star: bool = False,
                 truncate: bool = True) -> RunMetrics:
    metrics = RunMetrics(source_file=str(source.name),
                         started_at=datetime.now())
    metrics.stage_timings = {}
    wall = time.perf_counter()

    with connect() as conn:
        metrics.run_id = _start_run(conn, metrics)
        conn.commit()

        try:
            if truncate:
                with conn.cursor() as cur:
                    cur.execute("""
                        TRUNCATE ops.participant RESTART IDENTITY CASCADE;
                        TRUNCATE ops.college RESTART IDENTITY CASCADE;
                    """)

            t = time.perf_counter()
            raw = extract(source)
            metrics.rows_extracted = len(raw)
            metrics.stage_timings["extract"] = time.perf_counter() - t

            t = time.perf_counter()
            accepted, rejected, results = validate(raw)
            metrics.rows_rejected = len(rejected)
            metrics.validation_failures = sum(
                r.failure_count for r in results
                if r.rule.severity in ("reject", "warn"))
            metrics.stage_timings["validate"] = time.perf_counter() - t

            t = time.perf_counter()
            typed = transform(accepted)
            metrics.stage_timings["transform"] = time.perf_counter() - t

            t = time.perf_counter()
            deduped, audit = deduplicate(typed)
            metrics.rows_deduplicated = len(audit)
            metrics.stage_timings["deduplicate"] = time.perf_counter() - t

            t = time.perf_counter()
            load(conn, deduped)
            metrics.rows_loaded = len(deduped)
            metrics.stage_timings["load"] = time.perf_counter() - t

            _record_quality(conn, metrics.run_id, results)
            _record_rejects(conn, metrics.run_id, rejected)
            _record_duplicates(conn, metrics.run_id, audit)

            metrics.duplicate_rate_pct = round(
                100.0 * metrics.rows_deduplicated / max(metrics.rows_extracted, 1), 3)
            metrics.status = "success" if metrics.rows_rejected == 0 else "partial"

        except Exception as exc:                                  # noqa: BLE001
            conn.rollback()
            metrics.status = "failed"
            metrics.error_message = f"{type(exc).__name__}: {exc}"[:2000]
            metrics.finished_at = datetime.now()
            metrics.duration_seconds = round(time.perf_counter() - wall, 3)
            with connect() as c2:
                _finish_run(c2, metrics)
                c2.commit()
            LOG.exception("pipeline failed")
            raise

        metrics.finished_at = datetime.now()
        metrics.duration_seconds = round(time.perf_counter() - wall, 3)
        _finish_run(conn, metrics)
        conn.commit()

    if not skip_star:
        t = time.perf_counter()
        with connect() as conn:
            with conn.cursor() as cur:
                cur.execute("CALL ops.refresh_star_schema(%s, %s, %s, %s)", (
                    EVENT["event_start"], EVENT["reg_close"],
                    EVENT["host_state"], EVENT["host_college"]))
            conn.commit()
        metrics.stage_timings["star_refresh"] = time.perf_counter() - t

    return metrics


def main() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s  %(levelname)-7s %(name)s  %(message)s",
        datefmt="%H:%M:%S")

    ap = argparse.ArgumentParser(description="HackTU registration ETL")
    ap.add_argument("--source", type=Path,
                    default=DATA_DIR / "hacktu_registrations_raw.csv")
    ap.add_argument("--skip-star", action="store_true",
                    help="load OLTP only, do not rebuild the star schema")
    ap.add_argument("--no-truncate", action="store_true",
                    help="append to existing participants instead of reloading")
    ap.add_argument("--json", action="store_true", help="print metrics as JSON")
    args = ap.parse_args()

    metrics = run_pipeline(args.source, skip_star=args.skip_star,
                           truncate=not args.no_truncate)

    if args.json:
        print(json.dumps(metrics.as_dict(), indent=2, default=str))
    else:
        print()
        print(f"  run #{metrics.run_id}  [{metrics.status}]  "
              f"{metrics.duration_seconds:.3f}s")
        print(f"  extracted   {metrics.rows_extracted:>6}")
        print(f"  rejected    {metrics.rows_rejected:>6}")
        print(f"  duplicates  {metrics.rows_deduplicated:>6}  "
              f"({metrics.duplicate_rate_pct}% of extracted)")
        print(f"  loaded      {metrics.rows_loaded:>6}")
        print(f"  dq failures {metrics.validation_failures:>6}")
        print("  stages: " + "  ".join(
            f"{k}={v:.3f}s" for k, v in metrics.stage_timings.items()))


if __name__ == "__main__":
    main()
