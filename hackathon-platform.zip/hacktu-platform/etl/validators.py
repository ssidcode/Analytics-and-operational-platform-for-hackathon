"""
Data-quality rules for the registration intake.

Each rule is a small, independently testable callable. A rule returns the
boolean mask of rows that *fail* it, which keeps the engine uniform and the
reporting honest: `failure_count` is always `mask.sum()`.

Severity decides what happens to a failing row:

    reject  -- the row cannot be loaded (no usable identity). It is written
               to ops.rejected_registration with the rules it broke, so an
               organiser can chase the person rather than losing them.
    warn    -- the row is loaded, but the bad field is nulled or coerced and
               the event is recorded. Most dirt is this: a phone number typed
               as "not available" should not cost somebody their place.
    info    -- observational only; nothing changes.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import datetime
from typing import Callable

import pandas as pd

# Deliberately not RFC 5322. This is the "could a human plausibly receive
# mail here" test: one @, a dot-bearing domain, no spaces.
EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$")
PHONE_DIGITS_RE = re.compile(r"\D+")

VALID_TSHIRT = {"XS", "S", "M", "L", "XL", "XXL"}
MIN_GRAD_YEAR, MAX_GRAD_YEAR = 2020, 2035
MIN_STUDY_YEAR, MAX_STUDY_YEAR = 1, 6


@dataclass
class Rule:
    name: str
    severity: str                       # 'reject' | 'warn' | 'info'
    column: str | None
    check: Callable[[pd.DataFrame], pd.Series]
    description: str = ""


@dataclass
class RuleResult:
    rule: Rule
    failure_count: int
    rows_checked: int
    sample_values: list = field(default_factory=list)
    mask: pd.Series | None = None


# ---------------------------------------------------------------------------
# Normalisation helpers -- used by both the validators and the transform step
# so the two can never disagree about what a value means.
# ---------------------------------------------------------------------------

def normalise_email(value: object) -> str | None:
    """Mirror of ops.normalise_email() in SQL. Keep the two in step."""
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return None
    text = str(value).strip().lower()
    if not text or "@" not in text:
        return None
    local, _, domain = text.partition("@")
    local = local.split("+", 1)[0]
    if domain in {"gmail.com", "googlemail.com"}:
        local = local.replace(".", "")
    if not local or not domain:
        return None
    return f"{local}@{domain}"


def normalise_phone(value: object) -> str | None:
    """Return an E.164 Indian mobile, or None if it isn't one."""
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return None
    digits = PHONE_DIGITS_RE.sub("", str(value))
    if digits.startswith("91") and len(digits) == 12:
        digits = digits[2:]
    elif digits.startswith("0") and len(digits) == 11:
        digits = digits[1:]
    if len(digits) != 10 or digits[0] not in "6789":
        return None
    # A number that is all one digit, or a flat run like 1234567890, is a
    # placeholder someone typed to get past a required field.
    if len(set(digits)) <= 2:
        return None
    return f"+91{digits}"


def normalise_name(value: object) -> str | None:
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return None
    text = " ".join(str(value).split())
    if not text:
        return None
    # Forms collect SHOUTED names; title-case them unless the name is
    # genuinely mixed-case already (which suggests the person typed it well).
    if text.isupper() or text.islower():
        text = text.title()
    return text


def normalise_college(value: object) -> str | None:
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return None
    text = " ".join(str(value).split())
    if text.lower() in {"", "-", "n/a", "na", "none", "nil", "."}:
        return None
    return text


def college_key(value: object) -> str | None:
    text = normalise_college(value)
    if text is None:
        return None
    return re.sub(r"[^a-z0-9]+", "", text.lower()) or None


# ---------------------------------------------------------------------------
# Rule definitions
# ---------------------------------------------------------------------------

def _missing(df: pd.DataFrame, col: str) -> pd.Series:
    if col not in df.columns:
        return pd.Series(True, index=df.index)
    s = df[col]
    return s.isna() | (s.astype(str).str.strip() == "")


def _email_malformed(df: pd.DataFrame) -> pd.Series:
    raw = df["email"].fillna("").astype(str).str.strip()
    return ~raw.str.match(EMAIL_RE)


def _phone_invalid(df: pd.DataFrame) -> pd.Series:
    return df["phone"].map(lambda v: normalise_phone(v) is None)


def _grad_year_out_of_range(df: pd.DataFrame) -> pd.Series:
    years = pd.to_numeric(df["graduation_year"], errors="coerce")
    return years.isna() | (years < MIN_GRAD_YEAR) | (years > MAX_GRAD_YEAR)


def _study_year_invalid(df: pd.DataFrame) -> pd.Series:
    years = pd.to_numeric(df["year_of_study"], errors="coerce")
    return years.isna() | (years < MIN_STUDY_YEAR) | (years > MAX_STUDY_YEAR)


def _college_missing(df: pd.DataFrame) -> pd.Series:
    return df["college_name"].map(lambda v: normalise_college(v) is None)


def _name_missing(df: pd.DataFrame) -> pd.Series:
    return df["full_name"].map(lambda v: normalise_name(v) is None)


def _tshirt_invalid(df: pd.DataFrame) -> pd.Series:
    return ~df["tshirt_size"].fillna("").astype(str).str.strip().str.upper().isin(VALID_TSHIRT)


def _timestamp_unparseable(df: pd.DataFrame) -> pd.Series:
    return pd.to_datetime(df["registered_at"], errors="coerce").isna()


def _timestamp_outside_window(df: pd.DataFrame, open_at: datetime, close_at: datetime) -> pd.Series:
    ts = pd.to_datetime(df["registered_at"], errors="coerce")
    return ts.notna() & ((ts < open_at) | (ts > close_at))


def _name_needed_cleanup(df: pd.DataFrame) -> pd.Series:
    raw = df["full_name"].fillna("").astype(str)
    return raw != raw.map(lambda v: normalise_name(v) or "")


def build_rules(reg_open: datetime, reg_close: datetime) -> list[Rule]:
    """The rule set, in the order it is reported."""
    return [
        # --- reject: no usable identity -----------------------------------
        Rule("email_malformed", "reject", "email", _email_malformed,
             "Email is not deliverable-shaped; the participant cannot be contacted "
             "or de-duplicated."),
        Rule("name_missing", "reject", "full_name", _name_missing,
             "No name on the registration."),
        Rule("timestamp_unparseable", "reject", "registered_at", _timestamp_unparseable,
             "Registration timestamp could not be parsed, so the row cannot be "
             "placed on the trend line or ordered for first-come-first-served."),

        # --- warn: loadable, field coerced --------------------------------
        Rule("phone_invalid", "warn", "phone", _phone_invalid,
             "Phone is not a valid Indian mobile; stored as NULL."),
        Rule("college_missing", "warn", "college_name", _college_missing,
             "College blank or a placeholder; participant loaded without a "
             "college link."),
        Rule("graduation_year_out_of_range", "warn", "graduation_year",
             _grad_year_out_of_range,
             f"Graduation year outside {MIN_GRAD_YEAR}-{MAX_GRAD_YEAR}; stored as NULL."),
        Rule("year_of_study_invalid", "warn", "year_of_study", _study_year_invalid,
             f"Year of study outside {MIN_STUDY_YEAR}-{MAX_STUDY_YEAR}; stored as NULL."),
        Rule("tshirt_size_invalid", "warn", "tshirt_size", _tshirt_invalid,
             "T-shirt size not in the ordered size set; stored as NULL."),
        Rule("timestamp_outside_window", "warn", "registered_at",
             lambda df: _timestamp_outside_window(df, reg_open, reg_close),
             "Registration timestamp falls outside the advertised window."),

        # --- info: observational ------------------------------------------
        Rule("name_needed_cleanup", "info", "full_name", _name_needed_cleanup,
             "Name required whitespace or casing normalisation."),
    ]


def run_rules(df: pd.DataFrame, rules: list[Rule], sample_n: int = 5) -> list[RuleResult]:
    results: list[RuleResult] = []
    n = len(df)
    for rule in rules:
        mask = rule.check(df).fillna(True).astype(bool)
        count = int(mask.sum())
        samples: list = []
        if count and rule.column and rule.column in df.columns:
            # Keep nulls as JSON null rather than the string "nan" -- the
            # sample is shown to organisers in the dashboard, and "nan" reads
            # as a typo in the data rather than an empty field.
            samples = [
                None if pd.isna(v) else str(v)
                for v in df.loc[mask, rule.column].head(sample_n).tolist()
            ]
        results.append(RuleResult(rule=rule, failure_count=count,
                                  rows_checked=n, sample_values=samples,
                                  mask=mask))
    return results
