"""
Screenshot each dashboard tab, for the README and for visual regressions.

    python scripts/capture_dashboard.py            # dashboard must be running
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SHOTS = ROOT / "docs" / "screenshots"

TABS = ["Registrations", "Pipeline health", "Judging"]


def main() -> int:
    from playwright.sync_api import sync_playwright

    ap = argparse.ArgumentParser()
    ap.add_argument("--url", default="http://localhost:8501")
    ap.add_argument("--width", type=int, default=1680)
    ap.add_argument("--height", type=int, default=1200)
    args = ap.parse_args()

    SHOTS.mkdir(parents=True, exist_ok=True)

    with sync_playwright() as pw:
        browser = pw.chromium.launch(args=["--no-sandbox"])
        page = browser.new_page(
            viewport={"width": args.width, "height": args.height},
            device_scale_factor=2)

        page.goto(args.url, wait_until="networkidle", timeout=120_000)
        # Streamlit streams the page in over the websocket; wait for the
        # last tab's content rather than a fixed sleep.
        page.wait_for_selector("[data-testid='stTab']", timeout=120_000)
        page.wait_for_timeout(9000)

        for i, name in enumerate(TABS):
            tabs = page.query_selector_all("[data-testid='stTab']")
            if i >= len(tabs):
                print(f"  tab {name!r} not found")
                continue
            tabs[i].click()
            page.wait_for_timeout(7000)
            out = SHOTS / f"{i+1:02d}_{name.lower().replace(' ', '_')}.png"
            page.screenshot(path=str(out), full_page=True)
            size_kb = out.stat().st_size / 1024
            print(f"  {out.relative_to(ROOT)}  ({size_kb:,.0f} KB)")

        browser.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
