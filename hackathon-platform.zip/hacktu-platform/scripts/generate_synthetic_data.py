"""
Generate the synthetic HackTU registration dataset.

Produces a deliberately *dirty* raw CSV, the way a real Google-Form /
Devfolio export looks before anyone cleans it:

  - 550 distinct human beings
  - a tail of duplicate registrations (same person submits twice, with
    casing / whitespace / punctuation drift in the email so a naive
    DISTINCT does not catch them)
  - a sprinkle of malformed emails, bad phone numbers, out-of-range
    graduation years, missing colleges and impossible team sizes

The ETL's job is to find all of that. The numbers the ETL reports are
what goes on the resume, so the dirt here is generated with a fixed
seed and counted on the way out -- see data/ground_truth.json.
"""

from __future__ import annotations

import csv
import json
import random
import unicodedata
from datetime import datetime, timedelta
from pathlib import Path

SEED = 20260118
random.seed(SEED)

N_UNIQUE_PARTICIPANTS = 550

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
DATA.mkdir(parents=True, exist_ok=True)

# --------------------------------------------------------------------------
# Name pools -- broad coverage across Indian regions/communities so the
# dataset doesn't read as one state's phone book.
# --------------------------------------------------------------------------

FIRST_NAMES_M = [
    "Aarav", "Vivaan", "Aditya", "Vihaan", "Arjun", "Sai", "Reyansh", "Krishna",
    "Ishaan", "Rudra", "Ayaan", "Yash", "Kabir", "Dhruv", "Atharv", "Rohan",
    "Karan", "Siddharth", "Harshit", "Nikhil", "Rahul", "Ankit", "Abhishek",
    "Manpreet", "Gurpreet", "Jaskaran", "Harsimran", "Navdeep", "Rajvir",
    "Tanmay", "Shaurya", "Devansh", "Parth", "Om", "Aryan", "Kunal", "Varun",
    "Pranav", "Sarthak", "Raghav", "Lakshya", "Naman", "Ritik", "Shivam",
    "Mohit", "Akash", "Vikram", "Sanjay", "Deepak", "Suraj", "Amit", "Rohit",
    "Anirudh", "Hrithik", "Keshav", "Madhav", "Nitin", "Pawan", "Rakesh",
    "Sumit", "Tarun", "Utkarsh", "Yuvraj", "Zubin", "Faisal", "Imran",
    "Mohammed", "Arnav", "Daksh", "Eshan", "Gaurav", "Hardik", "Jatin",
    "Kartik", "Lokesh", "Mayank", "Nishant", "Piyush", "Rishabh", "Sachin",
    "Tushar", "Vaibhav", "Yogesh", "Abhinav", "Bhavesh", "Chirag", "Dinesh",
    "Girish", "Hemant", "Jayesh", "Kaushik", "Milind", "Nilesh", "Prasad",
    "Rohan", "Sandeep", "Tejas", "Umesh", "Vishal", "Aniket", "Bharat",
    "Chaitanya", "Darshan", "Ganesh", "Jeevan", "Karthik", "Manish",
    "Naveen", "Pramod", "Ravi", "Satish", "Venkat", "Arun", "Balaji",
    "Dileep", "Gokul", "Hari", "Jithin", "Mahesh", "Nandan", "Praveen",
    "Sreekanth", "Vinay", "Anup", "Debashish", "Indranil", "Joydeep",
    "Pritam", "Soumya", "Subhrajit", "Tanmoy", "Arindam", "Rupak",
]

FIRST_NAMES_F = [
    "Aadhya", "Ananya", "Diya", "Ira", "Myra", "Pari", "Anika", "Navya",
    "Riya", "Saanvi", "Kiara", "Prisha", "Aarohi", "Avni", "Siya", "Tara",
    "Isha", "Meera", "Nandini", "Shreya", "Pooja", "Neha", "Priya", "Kavya",
    "Simran", "Harleen", "Jasleen", "Manpreet", "Gurleen", "Amrit",
    "Sneha", "Divya", "Swati", "Trisha", "Vaishnavi", "Yamini", "Aditi",
    "Bhavya", "Chitra", "Deepika", "Esha", "Gayatri", "Harshita", "Ishita",
    "Janhvi", "Khushi", "Lavanya", "Mahima", "Nikita", "Oviya", "Palak",
    "Rachna", "Sakshi", "Tanvi", "Urvi", "Vidya", "Anjali", "Bhoomi",
    "Charvi", "Damini", "Ekta", "Garima", "Hina", "Jyoti", "Komal",
    "Madhuri", "Nisha", "Payal", "Radhika", "Sunita", "Tanya", "Vandana",
    "Aishwarya", "Bhavana", "Chandana", "Deepthi", "Gauri", "Keerthi",
    "Lakshmi", "Nivedita", "Pallavi", "Ramya", "Sowmya", "Varsha",
    "Ankita", "Debolina", "Moumita", "Paromita", "Rituparna", "Sohini",
    "Fatima", "Zoya", "Ayesha", "Sana", "Mariam", "Nazia",
]

LAST_NAMES = [
    "Sharma", "Verma", "Gupta", "Agarwal", "Singh", "Kumar", "Yadav", "Mishra",
    "Tiwari", "Pandey", "Chauhan", "Rathore", "Shekhawat", "Joshi", "Bhatt",
    "Sidhu", "Dhillon", "Gill", "Sandhu", "Grewal", "Bajwa", "Brar", "Randhawa",
    "Chaudhary", "Malhotra", "Kapoor", "Khanna", "Mehra", "Chopra", "Sethi",
    "Patel", "Shah", "Desai", "Mehta", "Trivedi", "Parikh", "Vyas", "Dave",
    "Reddy", "Rao", "Naidu", "Chowdary", "Prasad", "Varma",
    "Iyer", "Iyengar", "Krishnan", "Subramanian", "Venkatesh", "Raman",
    "Nair", "Menon", "Pillai", "Kurup", "Warrier",
    "Desai", "Kulkarni", "Deshpande", "Joshi", "Patil", "Jadhav", "Shinde",
    "Pawar", "Gaikwad", "More", "Sawant", "Kadam",
    "Banerjee", "Chatterjee", "Mukherjee", "Bhattacharya", "Ghosh", "Bose",
    "Das", "Dutta", "Sen", "Roy", "Chakraborty", "Majumdar",
    "Nayak", "Mohanty", "Behera", "Sahoo", "Panda",
    "Saikia", "Borah", "Gogoi", "Baruah",
    "Khan", "Ahmed", "Ansari", "Siddiqui", "Qureshi", "Hussain", "Sheikh",
    "Jain", "Bansal", "Goel", "Mittal", "Singhal", "Aggarwal", "Garg",
    "Thakur", "Rawat", "Negi", "Bisht", "Pant",
]

# --------------------------------------------------------------------------
# Colleges -- real institution names, weighted so the host (Thapar) and
# nearby Punjab/NCR colleges dominate, which is what a Patiala hackathon
# actually looks like.
# --------------------------------------------------------------------------

COLLEGES_HOME = [
    ("Thapar Institute of Engineering and Technology", "Patiala", "Punjab"),
]

COLLEGES_REGIONAL = [
    ("Punjab Engineering College", "Chandigarh", "Chandigarh"),
    ("Chitkara University", "Rajpura", "Punjab"),
    ("Lovely Professional University", "Phagwara", "Punjab"),
    ("Guru Nanak Dev Engineering College", "Ludhiana", "Punjab"),
    ("Chandigarh University", "Mohali", "Punjab"),
    ("National Institute of Technology, Jalandhar", "Jalandhar", "Punjab"),
    ("Guru Nanak Dev University", "Amritsar", "Punjab"),
    ("Panjab University", "Chandigarh", "Chandigarh"),
    ("Baba Banda Singh Bahadur Engineering College", "Fatehgarh Sahib", "Punjab"),
    ("Sant Longowal Institute of Engineering and Technology", "Longowal", "Punjab"),
    ("DAV Institute of Engineering and Technology", "Jalandhar", "Punjab"),
    ("Amity University Punjab", "Mohali", "Punjab"),
    ("Maharaja Ranjit Singh Punjab Technical University", "Bathinda", "Punjab"),
    ("Rayat Bahra University", "Mohali", "Punjab"),
    ("National Institute of Technology, Kurukshetra", "Kurukshetra", "Haryana"),
    ("Deenbandhu Chhotu Ram University of Science and Technology", "Murthal", "Haryana"),
    ("The NorthCap University", "Gurugram", "Haryana"),
    ("Manav Rachna University", "Faridabad", "Haryana"),
    ("Indian Institute of Technology Ropar", "Rupnagar", "Punjab"),
    ("Indian Institute of Technology Delhi", "New Delhi", "Delhi"),
    ("Delhi Technological University", "New Delhi", "Delhi"),
    ("Netaji Subhas University of Technology", "New Delhi", "Delhi"),
    ("Indraprastha Institute of Information Technology Delhi", "New Delhi", "Delhi"),
    ("Jamia Millia Islamia", "New Delhi", "Delhi"),
    ("Maharaja Agrasen Institute of Technology", "New Delhi", "Delhi"),
    ("Bharati Vidyapeeth College of Engineering", "New Delhi", "Delhi"),
    ("Jaypee Institute of Information Technology", "Noida", "Uttar Pradesh"),
    ("Amity University Noida", "Noida", "Uttar Pradesh"),
    ("Galgotias University", "Greater Noida", "Uttar Pradesh"),
    ("KIET Group of Institutions", "Ghaziabad", "Uttar Pradesh"),
]

COLLEGES_NATIONAL = [
    ("Indian Institute of Technology Bombay", "Mumbai", "Maharashtra"),
    ("Indian Institute of Technology Kanpur", "Kanpur", "Uttar Pradesh"),
    ("Indian Institute of Technology Madras", "Chennai", "Tamil Nadu"),
    ("Indian Institute of Technology Kharagpur", "Kharagpur", "West Bengal"),
    ("Indian Institute of Technology Roorkee", "Roorkee", "Uttarakhand"),
    ("Indian Institute of Technology Guwahati", "Guwahati", "Assam"),
    ("Indian Institute of Technology Hyderabad", "Hyderabad", "Telangana"),
    ("Birla Institute of Technology and Science, Pilani", "Pilani", "Rajasthan"),
    ("Vellore Institute of Technology", "Vellore", "Tamil Nadu"),
    ("Manipal Institute of Technology", "Manipal", "Karnataka"),
    ("SRM Institute of Science and Technology", "Chennai", "Tamil Nadu"),
    ("PES University", "Bengaluru", "Karnataka"),
    ("RV College of Engineering", "Bengaluru", "Karnataka"),
    ("BMS College of Engineering", "Bengaluru", "Karnataka"),
    ("MS Ramaiah Institute of Technology", "Bengaluru", "Karnataka"),
    ("National Institute of Technology Karnataka, Surathkal", "Mangaluru", "Karnataka"),
    ("National Institute of Technology Trichy", "Tiruchirappalli", "Tamil Nadu"),
    ("National Institute of Technology Warangal", "Warangal", "Telangana"),
    ("College of Engineering, Pune", "Pune", "Maharashtra"),
    ("Veermata Jijabai Technological Institute", "Mumbai", "Maharashtra"),
    ("Sardar Patel Institute of Technology", "Mumbai", "Maharashtra"),
    ("Institute of Chemical Technology", "Mumbai", "Maharashtra"),
    ("Jadavpur University", "Kolkata", "West Bengal"),
    ("Indian Institute of Engineering Science and Technology, Shibpur", "Howrah", "West Bengal"),
    ("Heritage Institute of Technology", "Kolkata", "West Bengal"),
    ("Birla Institute of Technology, Mesra", "Ranchi", "Jharkhand"),
    ("Malaviya National Institute of Technology", "Jaipur", "Rajasthan"),
    ("Indian Institute of Information Technology Allahabad", "Prayagraj", "Uttar Pradesh"),
    ("Motilal Nehru National Institute of Technology", "Prayagraj", "Uttar Pradesh"),
    ("Visvesvaraya National Institute of Technology", "Nagpur", "Maharashtra"),
    ("Sardar Vallabhbhai National Institute of Technology", "Surat", "Gujarat"),
    ("Nirma University", "Ahmedabad", "Gujarat"),
    ("Dhirubhai Ambani Institute of Information and Communication Technology", "Gandhinagar", "Gujarat"),
    ("Cochin University of Science and Technology", "Kochi", "Kerala"),
    ("College of Engineering Trivandrum", "Thiruvananthapuram", "Kerala"),
    ("National Institute of Technology Calicut", "Kozhikode", "Kerala"),
    ("Osmania University", "Hyderabad", "Telangana"),
    ("Chaitanya Bharathi Institute of Technology", "Hyderabad", "Telangana"),
    ("Vasavi College of Engineering", "Hyderabad", "Telangana"),
    ("Andhra University College of Engineering", "Visakhapatnam", "Andhra Pradesh"),
]

TRACKS = [
    ("AI/ML", "Applied machine learning, LLM tooling and MLOps", 150),
    ("Web3 & Blockchain", "Decentralised apps, smart contracts, on-chain data", 70),
    ("HealthTech", "Diagnostics, patient workflow and medical data", 80),
    ("FinTech", "Payments, credit, fraud detection and markets", 90),
    ("Sustainability", "Climate, energy, agriculture and waste", 80),
    ("Open Innovation", "Anything that does not fit the other tracks", 110),
]

DEGREES = ["B.Tech", "B.E.", "B.Sc", "BCA", "M.Tech", "MCA", "Dual Degree"]
BRANCHES = [
    "Computer Science and Engineering", "Information Technology",
    "Electronics and Communication Engineering", "Electrical Engineering",
    "Mechanical Engineering", "Civil Engineering", "Chemical Engineering",
    "Biotechnology", "Data Science and Engineering", "Artificial Intelligence",
    "Mathematics and Computing", "Instrumentation and Control",
]

TSHIRT = ["XS", "S", "M", "L", "XL", "XXL"]
GENDERS = ["Male", "Female", "Non-binary", "Prefer not to say"]
DIET = ["Vegetarian", "Non-vegetarian", "Vegan", "Jain", "No preference"]
SOURCES = ["Instagram", "LinkedIn", "Devfolio", "Unstop", "College notice board",
           "WhatsApp group", "Friend referral", "Twitter/X", "Campus ambassador"]
EXPERIENCE = ["First hackathon", "1-2 hackathons", "3-5 hackathons", "5+ hackathons"]

FREE_MAIL = ["gmail.com", "outlook.com", "yahoo.com", "hotmail.com", "protonmail.com"]

# Registration window: the form opens ~6 weeks before the event and closes
# the night before. Traffic is bursty -- launch spike, mid-campaign lull,
# deadline wall. That shape is the point of the trends chart.
REG_OPEN = datetime(2026, 1, 5, 10, 0)
EVENT_START = datetime(2026, 2, 20, 9, 0)
REG_CLOSE = datetime(2026, 2, 18, 23, 59)


def slugify(text: str) -> str:
    norm = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode()
    return "".join(ch.lower() for ch in norm if ch.isalnum())


def college_domain(name: str, city: str = "") -> str:
    mapping = {
        "Thapar Institute of Engineering and Technology": "thapar.edu",
        "Punjab Engineering College": "pec.edu.in",
        "Chitkara University": "chitkara.edu.in",
        "Lovely Professional University": "lpu.in",
        "Chandigarh University": "cumail.in",
        "Panjab University": "pu.ac.in",
        "Delhi Technological University": "dtu.ac.in",
        "Netaji Subhas University of Technology": "nsut.ac.in",
        "Jadavpur University": "jadavpuruniversity.in",
        "Vellore Institute of Technology": "vitstudent.ac.in",
        "Manipal Institute of Technology": "learner.manipal.edu",
    }
    if name in mapping:
        return mapping[name]
    if name.startswith("Indian Institute of Technology"):
        city = slugify(name.rsplit(" ", 1)[-1])[:8]
        return f"iit{city}.ac.in"
    if "National Institute of Technology" in name:
        tail = name.rsplit(" ", 1)[-1].strip(",")
        # "...Institute of Technology" carries no place name -- use the city.
        anchor = city if tail.lower() in {"technology", "surathkal"} else tail
        return f"nit{slugify(anchor)[:8]}.ac.in"
    if "Indian Institute of Information Technology" in name:
        return f"iiit{slugify(city)[:8]}.ac.in"
    return slugify(name)[:14] + ".ac.in"


def pick_college():
    r = random.random()
    if r < 0.22:
        return random.choice(COLLEGES_HOME)
    if r < 0.68:
        return random.choice(COLLEGES_REGIONAL)
    return random.choice(COLLEGES_NATIONAL)


def registration_timestamp() -> datetime:
    """Bursty arrival process: launch spike, lull, deadline wall."""
    r = random.random()
    if r < 0.18:                                   # launch week
        base = REG_OPEN + timedelta(days=random.triangular(0, 7, 1))
    elif r < 0.45:                                 # steady middle
        base = REG_OPEN + timedelta(days=random.uniform(7, 32))
    elif r < 0.62:                                 # mid-campaign push
        base = REG_OPEN + timedelta(days=random.triangular(20, 28, 24))
    else:                                          # deadline wall
        days_left = random.expovariate(1 / 1.6)
        base = REG_CLOSE - timedelta(days=min(days_left, 8))
    # Students register in the evening, not at 4am.
    hour = int(random.triangular(9, 23, 21))
    base = base.replace(hour=hour, minute=random.randint(0, 59),
                        second=random.randint(0, 59))
    return min(max(base, REG_OPEN), REG_CLOSE)


def make_email(first: str, last: str, college: str, roll: str, city: str = "") -> str:
    style = random.random()
    f, l = slugify(first), slugify(last)
    if style < 0.45:                                # college-issued
        dom = college_domain(college, city)
        pat = random.choice([f"{f}{roll[-4:]}", f"{f}.{l}{roll[-2:]}", f"{f}_{l}"])
        return f"{pat}@{dom}"
    dom = random.choice(FREE_MAIL)
    pat = random.choice([
        f"{f}{l}", f"{f}.{l}", f"{f}{l}{random.randint(1, 999)}",
        f"{f}_{l}{random.randint(10, 99)}", f"{f}{random.randint(1000, 9999)}",
    ])
    return f"{pat}@{dom}"


def make_phone() -> str:
    num = f"{random.choice('6789')}{random.randint(10**8, 10**9 - 1)}"
    style = random.random()
    if style < 0.55:
        return num
    if style < 0.75:
        return f"+91{num}"
    if style < 0.88:
        return f"+91 {num[:5]} {num[5:]}"
    return f"91{num}"


# --------------------------------------------------------------------------
# Build the clean population first, then corrupt a copy of it.
# --------------------------------------------------------------------------

def build_population(n: int) -> list[dict]:
    people: list[dict] = []
    used_emails: set[str] = set()

    for i in range(n):
        gender = random.choices(GENDERS, weights=[62, 33, 2, 3])[0]
        if gender == "Female":
            first = random.choice(FIRST_NAMES_F)
        elif gender == "Male":
            first = random.choice(FIRST_NAMES_M)
        else:
            first = random.choice(FIRST_NAMES_M + FIRST_NAMES_F)
        last = random.choice(LAST_NAMES)

        college, city, state = pick_college()
        year = random.choices([1, 2, 3, 4], weights=[22, 31, 29, 18])[0]
        grad_year = 2026 + (4 - year) + (1 if random.random() < 0.05 else 0)
        roll = f"{str(grad_year - 4)[-2:]}{random.randint(100000, 999999)}"

        email = make_email(first, last, college, roll, city)
        guard = 0
        while email in used_emails and guard < 10:
            email = make_email(first, last, college, roll, city)
            guard += 1
        used_emails.add(email)

        ts = registration_timestamp()
        people.append({
            "person_id": i + 1,                      # ground truth only
            "full_name": f"{first} {last}",
            "email": email,
            "phone": make_phone(),
            "gender": gender,
            "college_name": college,
            "college_city": city,
            "college_state": state,
            "degree": random.choices(DEGREES, weights=[55, 14, 8, 9, 7, 4, 3])[0],
            "branch": random.choices(
                BRANCHES,
                weights=[30, 16, 12, 6, 6, 3, 3, 3, 8, 6, 4, 3])[0],
            "year_of_study": year,
            "graduation_year": grad_year,
            "roll_number": roll,
            "preferred_track": random.choices(
                [t[0] for t in TRACKS], weights=[31, 10, 14, 16, 13, 16])[0],
            "experience_level": random.choices(
                EXPERIENCE, weights=[38, 31, 21, 10])[0],
            "github_handle": (f"{slugify(first)}-{slugify(last)}"
                              if random.random() < 0.72 else ""),
            "tshirt_size": random.choices(TSHIRT, weights=[4, 18, 32, 27, 15, 4])[0],
            "dietary_preference": random.choices(DIET, weights=[46, 38, 5, 4, 7])[0],
            "accommodation_required": "Yes" if random.random() < 0.41 else "No",
            "heard_from": random.choice(SOURCES),
            "registered_at": ts,
        })
    return people


def jitter_email(email: str) -> str:
    """Produce a variant that is the *same mailbox* but a different string.

    These are the duplicates a naive `SELECT DISTINCT email` misses and the
    ETL's normalisation catches.
    """
    local, _, domain = email.partition("@")
    choice = random.random()
    if choice < 0.25:
        return f"{local.upper()}@{domain}"
    if choice < 0.45:
        return f"  {local}@{domain} "
    if choice < 0.65 and domain == "gmail.com":
        # Gmail ignores dots in the local part.
        if "." not in local and len(local) > 3:
            pos = len(local) // 2
            return f"{local[:pos]}.{local[pos:]}@{domain}"
        return f"{local.replace('.', '')}@{domain}"
    if choice < 0.80 and domain == "gmail.com":
        return f"{local}+hacktu@{domain}"           # plus-addressing
    if choice < 0.90:
        return f"{local}@{domain.upper()}"
    return f"{local.capitalize()}@{domain}"


def corrupt(rows: list[dict]) -> tuple[list[dict], dict]:
    """Inject the dirt and count exactly what was injected."""
    out: list[dict] = []
    stats = {
        "duplicate_rows_injected": 0,
        "exact_duplicate_rows": 0,
        "variant_duplicate_rows": 0,
        "malformed_email_rows": 0,
        "invalid_phone_rows": 0,
        "missing_college_rows": 0,
        "out_of_range_grad_year_rows": 0,
        "invalid_year_of_study_rows": 0,
        "whitespace_name_rows": 0,
    }

    for person in rows:
        out.append(dict(person))

        # ~12% of people submit the form more than once. A handful submit
        # three times (they "didn't get a confirmation email").
        r = random.random()
        n_dupes = 0
        if r < 0.098:
            n_dupes = 1
        elif r < 0.123:
            n_dupes = 2

        for _ in range(n_dupes):
            dup = dict(person)
            if random.random() < 0.30:
                stats["exact_duplicate_rows"] += 1
            else:
                dup["email"] = jitter_email(person["email"])
                stats["variant_duplicate_rows"] += 1
                # The re-submission usually drifts a little on soft fields.
                if random.random() < 0.5:
                    dup["tshirt_size"] = random.choice(TSHIRT)
                if random.random() < 0.4:
                    dup["preferred_track"] = random.choice([t[0] for t in TRACKS])
                if random.random() < 0.3:
                    dup["phone"] = make_phone()
            # The duplicate lands after the original.
            dup["registered_at"] = min(
                person["registered_at"] + timedelta(
                    minutes=random.choice([3, 11, 47, 180, 1440, 4320])),
                REG_CLOSE)
            out.append(dup)
            stats["duplicate_rows_injected"] += 1

    # Field-level corruption, applied across the whole (already duplicated) set.
    for row in out:
        if random.random() < 0.021:
            local, _, dom = row["email"].partition("@")
            row["email"] = random.choice([
                local,                                  # no @ at all
                f"{local}@{dom.rsplit('.', 1)[0]}",     # no TLD
                f"{local}@@{dom}",
                f"{local} @{dom}",
            ])
            stats["malformed_email_rows"] += 1

        if random.random() < 0.018:
            row["phone"] = random.choice(
                ["", "1234567890", "9999", "+91-", "not available", "0000000000"])
            stats["invalid_phone_rows"] += 1

        if random.random() < 0.012:
            row["college_name"] = random.choice(["", "  ", "N/A", "-"])
            stats["missing_college_rows"] += 1

        if random.random() < 0.010:
            row["graduation_year"] = random.choice([1998, 2045, 0, 20226])
            stats["out_of_range_grad_year_rows"] += 1

        if random.random() < 0.008:
            row["year_of_study"] = random.choice([0, 7, -1])
            stats["invalid_year_of_study_rows"] += 1

        if random.random() < 0.035:
            row["full_name"] = f"  {row['full_name'].upper()} "
            stats["whitespace_name_rows"] += 1

    random.shuffle(out)
    return out, stats


def main() -> None:
    people = build_population(N_UNIQUE_PARTICIPANTS)
    rows, stats = corrupt(people)

    columns = [
        "registration_id", "full_name", "email", "phone", "gender",
        "college_name", "college_city", "college_state", "degree", "branch",
        "year_of_study", "graduation_year", "roll_number", "preferred_track",
        "experience_level", "github_handle", "tshirt_size",
        "dietary_preference", "accommodation_required", "heard_from",
        "registered_at",
    ]

    raw_path = DATA / "hacktu_registrations_raw.csv"
    with raw_path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        for idx, row in enumerate(rows, start=1):
            rec = dict(row)
            rec["registration_id"] = f"HTU26-{idx:05d}"
            rec["registered_at"] = row["registered_at"].strftime("%Y-%m-%d %H:%M:%S")
            writer.writerow(rec)

    total = len(rows)
    stats.update({
        "seed": SEED,
        "unique_participants": N_UNIQUE_PARTICIPANTS,
        "total_raw_rows": total,
        "expected_duplicate_rate_pct": round(
            100 * stats["duplicate_rows_injected"] / total, 2),
        "registration_window": {
            "opens": REG_OPEN.isoformat(),
            "closes": REG_CLOSE.isoformat(),
            "event_start": EVENT_START.isoformat(),
        },
    })

    gt_path = DATA / "ground_truth.json"
    gt_path.write_text(json.dumps(stats, indent=2), encoding="utf-8")

    # Track reference table, used by the OLTP seed.
    tracks_path = DATA / "tracks.csv"
    with tracks_path.open("w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["track_name", "description", "capacity"])
        for name, desc, cap in TRACKS:
            w.writerow([name, desc, cap])

    print(f"wrote {raw_path}  ({total} rows)")
    print(f"wrote {gt_path}")
    print(f"wrote {tracks_path}")
    print(json.dumps(
        {k: v for k, v in stats.items() if k != "registration_window"}, indent=2))


if __name__ == "__main__":
    main()
