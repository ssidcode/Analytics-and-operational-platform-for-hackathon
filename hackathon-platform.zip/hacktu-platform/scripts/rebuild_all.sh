#!/usr/bin/env bash
#
# Rebuild the whole platform from nothing, in the right order.
#
#   ./scripts/rebuild_all.sh              full rebuild with run history
#   ./scripts/rebuild_all.sh --quick      skip the 45-run history replay
#
# Order matters: the star schema is dropped and recreated by the DDL, so
# every refresh has to come after it, and the team seed has to come after
# the ETL because the ETL truncates participants.

set -euo pipefail

cd "$(dirname "$0")/.."

export PGHOST="${PGHOST:-127.0.0.1}"
export PGUSER="${PGUSER:-hacktu}"
export PGPASSWORD="${PGPASSWORD:-hacktu_dev}"
export PGDATABASE="${PGDATABASE:-hacktu}"

QUICK=0
[[ "${1:-}" == "--quick" ]] && QUICK=1

psql_run() {
    psql -h "$PGHOST" -U "$PGUSER" -d "$PGDATABASE" -q -v ON_ERROR_STOP=1 "$@"
}

step() { printf '\n\033[1m==> %s\033[0m\n' "$1"; }

step "1/8  Generating synthetic registrations"
python3 scripts/generate_synthetic_data.py | tail -4

step "2/8  Applying OLTP schema"
psql_run -f sql/01_oltp_schema.sql

step "3/8  Applying OLAP star schema"
psql_run -f sql/02_olap_schema.sql 2>&1 | grep -v '^NOTICE' || true

step "4/8  Applying stored procedures"
psql_run -f sql/03_stored_procedures.sql

step "5/8  Creating indexes"
psql_run -f sql/04_indexes.sql

step "6/8  Granting the read-only role"
psql_run -f sql/05_readonly_role.sql
# Views created after the grant need it explicitly.
psql_run -c "GRANT SELECT ON ALL TABLES IN SCHEMA analytics TO hacktu_readonly;"

step "7/8  Running the ETL"
if [[ $QUICK -eq 1 ]]; then
    python3 -m etl.pipeline --skip-star | tail -10
else
    python3 scripts/simulate_run_history.py --every 1 --failures \
        2>/dev/null | tail -6
fi

step "8/8  Seeding teams, judging, and refreshing the star schema"
python3 scripts/seed_event_operations.py | tail -4
psql_run -c "CALL ops.refresh_star_schema();" 2>&1 | grep -v '^NOTICE' || true
psql_run -c "GRANT SELECT ON ALL TABLES IN SCHEMA analytics TO hacktu_readonly;"

step "Verification"
python3 scripts/verify_dedupe.py | tail -16
psql_run -c "
SELECT 'participants' AS object, COUNT(*) FROM analytics.fact_registration
UNION ALL SELECT 'teams',         COUNT(*) FROM analytics.dim_team
UNION ALL SELECT 'colleges',      COUNT(*) FROM analytics.dim_college
UNION ALL SELECT 'score rows',    COUNT(*) FROM analytics.fact_score
UNION ALL SELECT 'pipeline runs', COUNT(*) FROM analytics.fact_pipeline_run;"

printf '\n\033[1mDone.\033[0m  Dashboard:  streamlit run dashboard/app.py\n'
