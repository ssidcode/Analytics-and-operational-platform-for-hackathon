"""
Seed the operational side of the event: teams, problem statements, judges,
check-ins, submissions and raw scores.

Registration data comes from the ETL. This fills in everything that happens
*after* registration closes, so ops.assign_tracks() and ops.aggregate_scores()
have a realistic workload to run against.

Teams are formed from loaded participants with a realistic size mix (a few
solos, mostly 3-4). Scores are generated with per-team latent quality plus
per-judge bias, so the leaderboard has real separation rather than noise --
and a handful of teams are left deliberately under-judged so the
`is_complete` flag in aggregate_scores() has something to catch.
"""

from __future__ import annotations

import random
import sys
from datetime import datetime, timedelta
from pathlib import Path

import psycopg2.extras

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from etl.config import connect                      # noqa: E402

SEED = 760241
random.seed(SEED)

EVENT_START = datetime(2026, 2, 20, 9, 0)
JUDGING_START = datetime(2026, 2, 21, 14, 0)

TEAM_NAME_A = ["Null", "Byte", "Quantum", "Neural", "Syntax", "Kernel", "Vector",
               "Binary", "Cosmic", "Phantom", "Turbo", "Hyper", "Delta", "Omega",
               "Sigma", "Astra", "Crimson", "Velvet", "Iron", "Solar", "Lunar",
               "Nebula", "Zenith", "Apex", "Cipher", "Echo", "Flux", "Glitch",
               "Hexa", "Indigo", "Jolt", "Krypton", "Lambda", "Matrix", "Nexus",
               "Orbit", "Pixel", "Quark", "Raptor", "Stack", "Tensor", "Umbra",
               "Vertex", "Warp", "Xenon", "Yotta", "Zephyr", "Chai", "Masala",
               "Jugaad", "Desi", "Rangoli", "Monsoon", "Himalaya", "Ganga"]

TEAM_NAME_B = ["Pointers", "Runners", "Coders", "Hackers", "Builders", "Crew",
               "Squad", "Collective", "Labs", "Works", "Forge", "Foundry",
               "Syndicate", "Union", "Dynamics", "Systems", "Protocol", "Engine",
               "Overflow", "Exception", "Commit", "Rollback", "Daemons",
               "Threads", "Sockets", "Packets", "Nodes", "Shards", "Clusters",
               "Pipelines", "Gradients", "Transformers", "Compilers"]

JUDGES = [
    ("Dr. Ananya Krishnan", "IIT Ropar"), ("Rohan Mehta", "Razorpay"),
    ("Priya Raghavan", "Microsoft India"), ("Dr. Harpreet Singh", "Thapar Institute"),
    ("Vikram Choudhary", "Zomato"), ("Sneha Pillai", "Google India"),
    ("Dr. Meera Banerjee", "IISc Bengaluru"), ("Arjun Nair", "Swiggy"),
    ("Kavya Reddy", "Freshworks"), ("Dr. Sandeep Yadav", "IIIT Delhi"),
    ("Nikhil Bajwa", "Zerodha"), ("Ritu Deshpande", "Postman"),
    ("Dr. Imran Qureshi", "NIT Jalandhar"), ("Shalini Iyer", "CRED"),
    ("Manish Gill", "Atlassian India"), ("Dr. Tanvi Joshi", "IIT Delhi"),
    ("Aditya Rao", "PhonePe"), ("Pooja Malhotra", "Sprinklr"),
]

CRITERIA = [
    ("Technical Complexity", 0.30, 10),
    ("Innovation & Originality", 0.25, 10),
    ("Impact & Usefulness", 0.20, 10),
    ("Execution & Demo Quality", 0.15, 10),
    ("Presentation & Clarity", 0.10, 10),
]

PROBLEMS = {
    "AI/ML": [
        ("AIML-01", "Low-resource speech recognition for Indian languages", "Microsoft India"),
        ("AIML-02", "Retrieval-grounded assistant over public scheme documents", "Google India"),
        ("AIML-03", "On-device vision model for crop disease detection", None),
    ],
    "Web3 & Blockchain": [
        ("W3-01", "Transparent scholarship disbursal on-chain", None),
        ("W3-02", "Low-fee micropayment rails for creators", "Polygon"),
    ],
    "HealthTech": [
        ("HT-01", "Triage queue optimisation for district hospitals", None),
        ("HT-02", "Medication adherence tracking for chronic care", "Practo"),
        ("HT-03", "Offline-first ANM field data collection", None),
    ],
    "FinTech": [
        ("FT-01", "Credit scoring from alternative data for thin-file users", "Razorpay"),
        ("FT-02", "Real-time UPI fraud pattern detection", "PhonePe"),
        ("FT-03", "Expense-splitting with automatic settlement", "CRED"),
    ],
    "Sustainability": [
        ("SUS-01", "Municipal waste route optimisation", None),
        ("SUS-02", "Rooftop solar feasibility from satellite imagery", None),
        ("SUS-03", "Water table monitoring dashboard for panchayats", None),
    ],
    "Open Innovation": [
        ("OI-01", "Anything that solves a real campus problem", None),
        ("OI-02", "Accessibility tooling for Indian language interfaces", "Atlassian India"),
    ],
}


def seed(conn) -> dict:
    cur = conn.cursor()

    # Clean the operational tables; leave participants/colleges from the ETL.
    cur.execute("""
        TRUNCATE ops.score, ops.team_result, ops.submission, ops.check_in,
                 ops.team_member, ops.team, ops.judge, ops.scoring_criterion,
                 ops.problem_statement
        RESTART IDENTITY CASCADE
    """)

    cur.execute("SELECT track_id, track_name FROM ops.track ORDER BY track_id")
    tracks = cur.fetchall()
    track_by_name = {name: tid for tid, name in tracks}

    # --- problem statements ------------------------------------------------
    prob_rows = [(track_by_name[t], code, title, sponsor,
                  random.choice(["easy", "medium", "medium", "hard"]))
                 for t, items in PROBLEMS.items() if t in track_by_name
                 for code, title, sponsor in items]
    psycopg2.extras.execute_values(cur, """
        INSERT INTO ops.problem_statement (track_id, code, title, sponsor, difficulty)
        VALUES %s
    """, prob_rows)

    # --- criteria ----------------------------------------------------------
    psycopg2.extras.execute_values(cur, """
        INSERT INTO ops.scoring_criterion (criterion_name, weight, max_score)
        VALUES %s
    """, CRITERIA)

    # --- judges ------------------------------------------------------------
    judge_rows = []
    for i, (name, org) in enumerate(JUDGES):
        slug = name.lower().replace("dr. ", "").replace(" ", ".")
        tid = tracks[i % len(tracks)][0]
        judge_rows.append((name, org, f"{slug}@hacktu.in", tid))
    psycopg2.extras.execute_values(cur, """
        INSERT INTO ops.judge (judge_name, organisation, email, track_id)
        VALUES %s
    """, judge_rows)

    # --- teams -------------------------------------------------------------
    cur.execute("""
        SELECT participant_id, preferred_track_id, registered_at
        FROM ops.participant
        ORDER BY registered_at, participant_id
    """)
    participants = cur.fetchall()

    # Group by preferred track so teams are mostly track-coherent, which is
    # what actually happens -- people team up around the problem they want.
    by_pref: dict[int | None, list] = {}
    for pid, pref, reg in participants:
        by_pref.setdefault(pref, []).append((pid, reg))
    for bucket in by_pref.values():
        random.shuffle(bucket)

    used_names: set[str] = set()

    def team_name() -> str:
        for _ in range(200):
            n = f"{random.choice(TEAM_NAME_A)} {random.choice(TEAM_NAME_B)}"
            if n not in used_names:
                used_names.add(n)
                return n
        n = f"Team {len(used_names) + 1:03d}"
        used_names.add(n)
        return n

    teams: list[tuple[str, list[int]]] = []
    leftovers: list[tuple[int, datetime]] = []

    for _pref, bucket in by_pref.items():
        i = 0
        while i < len(bucket):
            size = random.choices([1, 2, 3, 4], weights=[4, 14, 34, 48])[0]
            chunk = bucket[i:i + size]
            i += size
            if len(chunk) < size and len(chunk) < 2:
                leftovers.extend(chunk)     # re-pool stragglers
                continue
            teams.append((team_name(), [p for p, _ in chunk]))

    # Fold the stragglers into teams of their own.
    random.shuffle(leftovers)
    i = 0
    while i < len(leftovers):
        size = random.choice([2, 3, 3, 4])
        chunk = leftovers[i:i + size]
        i += size
        if chunk:
            teams.append((team_name(), [p for p, _ in chunk]))

    team_rows = [(name, "registered") for name, _ in teams]
    psycopg2.extras.execute_values(cur, """
        INSERT INTO ops.team (team_name, status) VALUES %s
    """, team_rows)

    cur.execute("SELECT team_id, team_name FROM ops.team ORDER BY team_id")
    team_ids = {name: tid for tid, name in cur.fetchall()}

    member_rows = []
    for name, members in teams:
        tid = team_ids[name]
        for j, pid in enumerate(members):
            member_rows.append((tid, pid, j == 0))
    psycopg2.extras.execute_values(cur, """
        INSERT INTO ops.team_member (team_id, participant_id, is_leader) VALUES %s
    """, member_rows)

    conn.commit()
    return {"teams": len(teams), "members": len(member_rows),
            "judges": len(judge_rows), "problems": len(prob_rows)}


def seed_post_assignment(conn) -> dict:
    """Check-ins, submissions and scores. Run *after* ops.assign_tracks()."""
    cur = conn.cursor()

    # --- check-in: ~86% of registrants turn up, which is a normal show rate
    cur.execute("SELECT participant_id FROM ops.participant")
    pids = [r[0] for r in cur.fetchall()]
    checked = [p for p in pids if random.random() < 0.863]
    ci_rows = []
    for pid in checked:
        ts = EVENT_START + timedelta(minutes=random.triangular(-90, 420, 60))
        ci_rows.append((pid, ts, random.random() < 0.94,
                        f"D{random.randint(1, 40):02d}"))
    psycopg2.extras.execute_values(cur, """
        INSERT INTO ops.check_in (participant_id, checked_in_at, kit_collected, desk)
        VALUES %s ON CONFLICT (participant_id) DO NOTHING
    """, ci_rows)

    # --- teams that actually submit
    cur.execute("""
        SELECT t.team_id, t.track_id, COUNT(m.participant_id) AS size,
               COUNT(ci.participant_id) AS present
        FROM ops.team t
        JOIN ops.team_member m ON m.team_id = t.team_id
        LEFT JOIN ops.check_in ci ON ci.participant_id = m.participant_id
        GROUP BY t.team_id, t.track_id
    """)
    team_info = cur.fetchall()

    cur.execute("SELECT problem_id, track_id FROM ops.problem_statement")
    probs_by_track: dict[int, list[int]] = {}
    for pid_, tid in cur.fetchall():
        probs_by_track.setdefault(tid, []).append(pid_)

    submissions, updates, quality = [], [], {}
    for team_id, track_id, size, present in team_info:
        if present == 0:
            updates.append(("withdrawn", None, team_id))
            continue
        # A team with most of its members present almost always submits.
        p_submit = 0.55 + 0.35 * (present / max(size, 1))
        if random.random() > p_submit:
            updates.append(("checked_in", None, team_id))
            continue
        prob = random.choice(probs_by_track.get(track_id, [None])) \
            if track_id in probs_by_track else None
        deadline = EVENT_START + timedelta(hours=36)
        ts = deadline - timedelta(minutes=max(0, random.expovariate(1 / 90)))
        late = random.random() < 0.035
        if late:
            ts = deadline + timedelta(minutes=random.randint(1, 45))
        submissions.append((team_id, f"https://github.com/hacktu26/team-{team_id}",
                            f"https://hacktu26-{team_id}.vercel.app", ts, late))
        updates.append(("submitted", prob, team_id))
        # Latent quality: what the judges are trying to measure.
        quality[team_id] = min(max(random.gauss(0.62, 0.15), 0.08), 0.98)

    psycopg2.extras.execute_values(cur, """
        INSERT INTO ops.submission (team_id, repo_url, demo_url, submitted_at, is_late)
        VALUES %s ON CONFLICT (team_id) DO NOTHING
    """, submissions)

    cur.executemany(
        "UPDATE ops.team SET status = %s, problem_id = COALESCE(%s, problem_id) "
        "WHERE team_id = %s", updates)

    # --- scores
    cur.execute("SELECT criterion_id, criterion_name, max_score FROM ops.scoring_criterion")
    criteria = cur.fetchall()
    cur.execute("SELECT judge_id, track_id FROM ops.judge")
    judges = cur.fetchall()
    judges_by_track: dict[int | None, list[int]] = {}
    for jid, tid in judges:
        judges_by_track.setdefault(tid, []).append(jid)
    all_judges = [j for j, _ in judges]

    # Each judge has a persistent leniency bias -- the reason aggregate_scores
    # averages across judges rather than summing.
    bias = {jid: random.gauss(0, 0.07) for jid, _ in judges}

    track_of = {t: tr for t, tr, _, _ in team_info}
    score_rows = []
    incomplete_budget = 7          # teams deliberately left part-judged

    for team_id, q in quality.items():
        tr = track_of.get(team_id)
        pool = judges_by_track.get(tr) or all_judges
        n_judges = min(len(pool), random.choices([2, 3, 4], weights=[22, 58, 20])[0])
        panel = random.sample(pool, n_judges)

        skip_a_criterion = incomplete_budget > 0 and random.random() < 0.05
        if skip_a_criterion:
            incomplete_budget -= 1
        omitted = random.choice(criteria)[0] if skip_a_criterion else None

        for jid in panel:
            for cid, cname, max_score in criteria:
                if cid == omitted:
                    continue
                # Criterion-specific difficulty: demo quality is scored
                # harsher than presentation.
                offset = {"Technical Complexity": -0.04,
                          "Execution & Demo Quality": -0.06,
                          "Presentation & Clarity": 0.05}.get(cname, 0.0)
                val = q + bias[jid] + offset + random.gauss(0, 0.08)
                raw = round(min(max(val, 0.05), 1.0) * max_score * 2) / 2
                ts = JUDGING_START + timedelta(minutes=random.randint(0, 300))
                score_rows.append((team_id, jid, cid, 1, raw, ts))

    psycopg2.extras.execute_values(cur, """
        INSERT INTO ops.score (team_id, judge_id, criterion_id, round_no, raw_score, scored_at)
        VALUES %s ON CONFLICT DO NOTHING
    """, score_rows, page_size=1000)

    conn.commit()
    return {"check_ins": len(ci_rows), "submissions": len(submissions),
            "score_rows": len(score_rows)}


def main() -> None:
    with connect() as conn:
        s1 = seed(conn)
        print(f"  teams     {s1['teams']}   members {s1['members']}")
        print(f"  judges    {s1['judges']}   problems {s1['problems']}")

        print("\n  running ops.assign_tracks() ...")
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM ops.assign_tracks(FALSE)")
            rows = cur.fetchall()
        conn.commit()
        print(f"  {'track':<22}{'cap':>5}{'teams':>7}{'people':>8}"
              f"{'pref':>6}{'overflow':>10}{'headroom':>10}")
        for r in rows:
            print(f"  {r[0]:<22}{r[1]:>5}{r[2]:>7}{r[3]:>8}{r[4]:>6}{r[5]:>10}{r[6]:>10}")

        s2 = seed_post_assignment(conn)
        print(f"\n  check-ins {s2['check_ins']}   submissions {s2['submissions']}"
              f"   score rows {s2['score_rows']}")

        print("\n  running ops.aggregate_scores(1) ...")
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM ops.aggregate_scores(1::smallint)")
            lb = cur.fetchall()
        conn.commit()
        print(f"  {len(lb)} teams ranked. Top 10:")
        print(f"  {'#':>3}  {'team':<28}{'track':<20}{'score':>8}{'judges':>8}  complete")
        for r in lb[:10]:
            print(f"  {r[7]:>3}  {r[1]:<28}{(r[2] or '-'):<20}{float(r[3]):>8.2f}"
                  f"{r[4]:>8}  {'yes' if r[6] else 'NO'}")

        incomplete = [r for r in lb if not r[6]]
        print(f"\n  teams flagged incomplete: {len(incomplete)}")


if __name__ == "__main__":
    main()
