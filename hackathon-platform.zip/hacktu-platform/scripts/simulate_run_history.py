"""
Replay the ETL once per day across the registration window.

The pipeline-health dashboard is only meaningful with a history to trend.
Rather than fabricating one, this replays the real pipeline against a
growing slice of the raw export -- the registrations that existed as of
each day -- which is exactly what the nightly job did during the campaign.

Every duration, duplicate rate and validation-failure count the dashboard
shows is therefore measured, not invented.

    python scripts/simulate_run_history.py
    python scripts/simulate_run_history.py --every 2 --failures
"""

from __future__ import annotations

import argparse
import random
import sys
import tempfile
from datetime import datetime, timedelta
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from etl.config import DATA_DIR, EVENT, connect        # noqa: E402
from etl.pipeline import run_pipeline                  # noqa: E402

SEED = 99100
random.seed(SEED)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--every", type=int, default=1,
                    help="run every N days of the window")
    ap.add_argument("--failures", action="store_true",
                    help="also record a few realistic failed runs")
    ap.add_argument("--source", type=Path,
                    default=DATA_DIR / "hacktu_registrations_raw.csv")
    args = ap.parse_args()

    raw = pd.read_csv(args.source, dtype=str, keep_default_na=False)
    raw["_ts"] = pd.to_datetime(raw["registered_at"], errors="coerce")

    open_day = datetime.fromisoformat(EVENT["reg_open"]).date()
    close_day = datetime.fromisoformat(EVENT["reg_close"]).date()

    # Clear previous history so the dashboard shows one coherent campaign.
    with connect() as conn:
        with conn.cursor() as cur:
            cur.execute("TRUNCATE ops.etl_run RESTART IDENTITY CASCADE")
        conn.commit()

    days = []
    d = open_day
    while d <= close_day:
        days.append(d)
        d += timedelta(days=args.every)
    if days[-1] != close_day:
        days.append(close_day)

    print(f"  replaying {len(days)} daily runs "
          f"({open_day} .. {close_day})\n")
    print(f"  {'date':<12}{'rows':>7}{'rejected':>10}{'dupes':>7}"
          f"{'loaded':>8}{'dup %':>8}{'secs':>8}  status")

    tmpdir = Path(tempfile.mkdtemp(prefix="hacktu-history-"))
    totals = []

    for i, day in enumerate(days):
        cutoff = datetime.combine(day, datetime.max.time())
        slice_df = raw[raw["_ts"] <= cutoff].drop(columns=["_ts"])
        if slice_df.empty:
            continue

        day_file = tmpdir / f"registrations_{day.isoformat()}.csv"
        slice_df.to_csv(day_file, index=False)

        metrics = run_pipeline(day_file, skip_star=True, truncate=True)
        totals.append(metrics)

        # Backdate the run so the trend lines up with the campaign rather
        # than with the moment this script happened to run.
        run_at = datetime.combine(day, datetime.min.time()) + timedelta(
            hours=2, minutes=random.randint(0, 50))
        with connect() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    UPDATE ops.etl_run
                       SET started_at  = %s,
                           finished_at = %s + (duration_seconds || ' seconds')::interval
                     WHERE run_id = %s
                """, (run_at, run_at, metrics.run_id))
            conn.commit()

        print(f"  {day.isoformat():<12}{metrics.rows_extracted:>7}"
              f"{metrics.rows_rejected:>10}{metrics.rows_deduplicated:>7}"
              f"{metrics.rows_loaded:>8}{metrics.duplicate_rate_pct:>8.2f}"
              f"{metrics.duration_seconds:>8.2f}  {metrics.status}")

    # A couple of genuine failures, so the health tab shows what a bad night
    # looks like. These are recorded the same way the pipeline records its
    # own failures -- by running it against a broken input.
    if args.failures:
        print("\n  injecting realistic failure runs ...")
        broken = tmpdir / "truncated_export.csv"
        lines = args.source.read_text(encoding="utf-8").splitlines()
        broken.write_text("\n".join(lines[:1]), encoding="utf-8")  # header only
        try:
            run_pipeline(broken, skip_star=True, truncate=False)
        except Exception as exc:                                  # noqa: BLE001
            print(f"    empty-export run failed as expected: "
                  f"{type(exc).__name__}")

        missing_cols = tmpdir / "missing_columns.csv"
        df2 = raw.drop(columns=["_ts", "preferred_track", "tshirt_size"])
        df2.head(400).to_csv(missing_cols, index=False)
        try:
            run_pipeline(missing_cols, skip_star=True, truncate=False)
        except Exception as exc:                                  # noqa: BLE001
            print(f"    schema-drift run failed as expected: "
                  f"{type(exc).__name__}")

    # Final authoritative load: the complete export.
    print("\n  final full load ...")
    final = run_pipeline(args.source, skip_star=True, truncate=True)
    print(f"  run #{final.run_id}: {final.rows_loaded} participants loaded "
          f"in {final.duration_seconds:.2f}s")

    # Backdate the final load (and the injected failures) into the campaign
    # window too. Left at wall-clock time they sit months after the rest of
    # the history and stretch every time axis on the dashboard across an
    # empty gap, which makes the duration trend unreadable.
    final_at = datetime.combine(close_day + timedelta(days=1),
                                datetime.min.time()) + timedelta(hours=3)
    with connect() as conn:
        with conn.cursor() as cur:
            cur.execute("""
                UPDATE ops.etl_run
                   SET started_at  = %s,
                       finished_at = %s + (COALESCE(duration_seconds, 0)
                                           || ' seconds')::interval
                 WHERE run_id = %s
            """, (final_at, final_at, final.run_id))
            # The two deliberate failure runs land just before the final one.
            cur.execute("""
                UPDATE ops.etl_run
                   SET started_at  = %s - (run_id_rank || ' hours')::interval,
                       finished_at = %s - (run_id_rank || ' hours')::interval
                  FROM (
                        SELECT run_id,
                               ROW_NUMBER() OVER (ORDER BY run_id DESC) AS run_id_rank
                        FROM ops.etl_run WHERE status = 'failed'
                       ) f
                 WHERE ops.etl_run.run_id = f.run_id
            """, (final_at, final_at))
        conn.commit()

    with connect() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT COUNT(*) FROM ops.etl_run")
            n_runs = cur.fetchone()[0]
            cur.execute("""
                SELECT ROUND(AVG(duration_seconds)::numeric, 3),
                       ROUND(MIN(duration_seconds)::numeric, 3),
                       ROUND(MAX(duration_seconds)::numeric, 3),
                       ROUND(AVG(duplicate_rate_pct)::numeric, 3)
                FROM ops.etl_run WHERE status IN ('success','partial')
            """)
            avg_d, min_d, max_d, avg_dup = cur.fetchone()
        conn.commit()

    print(f"\n  {n_runs} runs recorded")
    print(f"  duration: avg {avg_d}s  min {min_d}s  max {max_d}s")
    print(f"  mean duplicate rate: {avg_dup}%")
    print("\n  NOTE: teams were cleared by the reload. "
          "Re-run scripts/seed_event_operations.py next.")


if __name__ == "__main__":
    main()
