"""
Check the ETL's dedupe against the generator's ground truth.

The generator knows exactly which rows it duplicated. The ETL does not.
This script scores the ETL's recall and precision so the resume number is a
measured result rather than an assertion.
"""

from __future__ import annotations

import csv
import json
import sys
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from etl.config import DATA_DIR, cursor          # noqa: E402
from etl.validators import normalise_email       # noqa: E402


def main() -> None:
    gt = json.loads((DATA_DIR / "ground_truth.json").read_text())

    # Rebuild true identity groups from the raw file by normalising the email
    # the same way the *generator* thinks of identity: a duplicate row shares
    # a mailbox with its original even after the email string was jittered.
    raw_path = DATA_DIR / "hacktu_registrations_raw.csv"
    by_key: dict[str, list[str]] = defaultdict(list)
    rows = 0
    with raw_path.open(encoding="utf-8") as fh:
        for row in csv.DictReader(fh):
            rows += 1
            key = normalise_email(row["email"])
            if key:
                by_key[key].append(row["registration_id"])

    true_dup_rows = sum(len(v) - 1 for v in by_key.values() if len(v) > 1)

    with cursor() as cur:
        cur.execute("SELECT run_id FROM ops.etl_run ORDER BY run_id DESC LIMIT 1")
        run_id = cur.fetchone()["run_id"]

        cur.execute("""
            SELECT match_type, COUNT(*) AS n
            FROM ops.duplicate_registration WHERE run_id = %s
            GROUP BY match_type ORDER BY n DESC
        """, (run_id,))
        by_type = cur.fetchall()

        cur.execute("""
            SELECT dropped_registration_id, email_key
            FROM ops.duplicate_registration WHERE run_id = %s
        """, (run_id,))
        detected = {r["dropped_registration_id"] for r in cur.fetchall()}

        cur.execute("""
            SELECT rows_extracted, rows_rejected, rows_deduplicated,
                   rows_loaded, duplicate_rate_pct, duration_seconds
            FROM ops.etl_run WHERE run_id = %s
        """, (run_id,))
        run = cur.fetchone()

        cur.execute("SELECT COUNT(*) AS n FROM ops.participant")
        loaded = cur.fetchone()["n"]

    # Which rows *should* have been dropped, per the raw file.
    should_drop: set[str] = set()
    for ids in by_key.values():
        if len(ids) > 1:
            should_drop.update(ids[1:])   # any one survivor is correct

    # A detected drop is correct if its group genuinely had >1 member.
    group_of = {rid: key for key, ids in by_key.items() for rid in ids}
    correct = sum(1 for rid in detected
                  if len(by_key.get(group_of.get(rid, ""), [])) > 1)
    false_pos = len(detected) - correct
    missed = len(should_drop) - correct

    recall = 100.0 * correct / max(len(should_drop), 1)
    precision = 100.0 * correct / max(len(detected), 1)

    print("=" * 66)
    print("  DEDUPLICATION VERIFICATION")
    print("=" * 66)
    print(f"  raw rows in file                 {rows}")
    print(f"  distinct people (generator)      {gt['unique_participants']}")
    print(f"  duplicate rows injected          {gt['duplicate_rows_injected']}")
    print(f"    of which exact copies          {gt['exact_duplicate_rows']}")
    print(f"    of which email variants        {gt['variant_duplicate_rows']}")
    print()
    print(f"  recoverable duplicates           {len(should_drop)}")
    print("    (the rest had their email destroyed by field-level corruption")
    print("     and were rejected at validation instead of deduplicated)")
    print()
    print(f"  ETL rejected                     {run['rows_rejected']}")
    print(f"  ETL deduplicated                 {run['rows_deduplicated']}")
    print(f"  ETL loaded                       {run['rows_loaded']}  "
          f"(participants in DB: {loaded})")
    print()
    print(f"  recall                           {recall:.1f}%  "
          f"({correct}/{len(should_drop)})")
    print(f"  precision                        {precision:.1f}%  "
          f"({correct}/{len(detected)}, {false_pos} false positives)")
    print(f"  missed                           {missed}")
    print()
    print(f"  duplicate rate of raw intake     {run['duplicate_rate_pct']}%")
    print(f"  pipeline duration                {run['duration_seconds']}s")
    print()
    print("  match-type breakdown:")
    for r in by_type:
        print(f"    {r['match_type']:<22} {r['n']}")
    print("=" * 66)

    verdict = "PASS" if recall >= 99.0 and false_pos == 0 else "CHECK"
    print(f"  {verdict}")


if __name__ == "__main__":
    main()
