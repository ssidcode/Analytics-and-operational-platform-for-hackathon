"""
The agentic text-to-SQL assistant.

"Agentic" here means a bounded loop rather than one-shot generation: the
model writes SQL, the SQL is checked and executed, and if it is refused by
the guard or errors in the database the *error text is handed back to the
model* so it can correct itself. Most real failures are a wrong column name
or a mis-remembered enum value, both of which a model fixes on the first
retry when it can see the message.

The loop is capped (MAX_ATTEMPTS) so a model that cannot get it right fails
visibly instead of burning tokens in a channel.

Flow per question:

    question
      -> generate SQL           (model, with curated schema + live values)
      -> SQLGuard.check()       (AST allowlist, LIMIT injection)
      -> execute as read-only role
      -> on failure: feed the error back, try again  [up to MAX_ATTEMPTS]
      -> summarise the rows in one or two sentences  (model)
      -> return AgentResult

The module has no Slack dependency, so it can be driven from the CLI, which
is how the eval suite tests it.
"""

from __future__ import annotations

import logging
import os
import re
import time
from dataclasses import dataclass, field
from typing import Any

from etl.config import DASHBOARD_URL, cursor
from slackbot.schema_context import build_schema_prompt
from slackbot.sql_guard import SQLGuard, Verdict, strip_markdown_fences

LOG = logging.getLogger("hacktu.agent")

MODEL = os.getenv("HACKTU_MODEL", "claude-sonnet-4-5")
MAX_ATTEMPTS = 3
MAX_ROWS_TO_MODEL = 40

SYSTEM_PROMPT = """You are the HackTU organisers' data assistant. You answer \
questions about hackathon registrations, teams, judging and the data \
pipeline by writing a single Postgres SELECT against the read-only analytics \
schema below.

{schema}

HOW TO RESPOND
Return the SQL inside a ```sql fenced block and nothing else. No prose, no \
explanation, no multiple options. If the question genuinely cannot be \
answered from this schema, return exactly:
  CANNOT_ANSWER: <one short sentence saying what is missing>

The people asking are event organisers, not engineers. They will see the \
result as a table, so choose column aliases that read as plain English."""

SUMMARY_PROMPT = """You are summarising a query result for a hackathon \
organiser in Slack. They can see the table, so do not read it out.

Question: {question}

SQL that ran:
{sql}

Result ({n_rows} row(s)):
{rows}

Write one or two short sentences stating the answer. Lead with the number or \
name that answers the question. Mention a caveat only if the data clearly \
shows one (e.g. a tie, an empty result, a value that looks like a data-quality \
problem). No preamble, no "Based on the query". Plain text, no markdown \
headers."""


@dataclass
class Attempt:
    sql: str
    allowed: bool
    error: str | None = None
    guard_reason: str | None = None


@dataclass
class AgentResult:
    question: str
    ok: bool
    sql: str | None = None
    columns: list[str] = field(default_factory=list)
    rows: list[tuple] = field(default_factory=list)
    summary: str = ""
    error: str | None = None
    attempts: list[Attempt] = field(default_factory=list)
    elapsed_ms: int = 0
    row_count: int = 0
    truncated: bool = False
    dashboard_url: str = DASHBOARD_URL
    tables_used: list[str] = field(default_factory=list)


class _Model:
    """Thin wrapper so the agent can run against a stub in tests."""

    def __init__(self, model: str = MODEL) -> None:
        self.model = model
        self._client = None

    @property
    def client(self):
        if self._client is None:
            import anthropic
            self._client = anthropic.Anthropic()
        return self._client

    def complete(self, system: str, messages: list[dict], max_tokens: int = 1200) -> str:
        resp = self.client.messages.create(
            model=self.model,
            max_tokens=max_tokens,
            system=system,
            messages=messages,
        )
        return "".join(b.text for b in resp.content if b.type == "text")


class TextToSQLAgent:
    def __init__(self, model: _Model | None = None,
                 guard: SQLGuard | None = None,
                 max_attempts: int = MAX_ATTEMPTS) -> None:
        self.model = model or _Model()
        self.guard = guard or SQLGuard()
        self.max_attempts = max_attempts

    # -- main entry point --------------------------------------------------

    def ask(self, question: str) -> AgentResult:
        started = time.perf_counter()
        result = AgentResult(question=question, ok=False)

        schema = build_schema_prompt()
        system = SYSTEM_PROMPT.format(schema=schema)
        messages: list[dict] = [{"role": "user", "content": question}]

        for attempt_no in range(1, self.max_attempts + 1):
            try:
                raw = self.model.complete(system, messages)
            except Exception as exc:                              # noqa: BLE001
                result.error = f"Could not reach the model: {exc}"
                result.elapsed_ms = int((time.perf_counter() - started) * 1000)
                return result

            if "CANNOT_ANSWER" in raw:
                reason = raw.split("CANNOT_ANSWER:", 1)[-1].strip()
                result.error = reason or "That isn't answerable from this data."
                result.elapsed_ms = int((time.perf_counter() - started) * 1000)
                return result

            sql = strip_markdown_fences(raw)
            verdict: Verdict = self.guard.check(sql)

            if not verdict.allowed:
                result.attempts.append(
                    Attempt(sql=sql, allowed=False, guard_reason=verdict.reason))
                LOG.info("attempt %d refused by guard: %s", attempt_no, verdict.reason)
                if attempt_no == self.max_attempts:
                    result.error = (
                        f"I could not produce a query I'm allowed to run. "
                        f"Last reason: {verdict.reason}")
                    break
                messages += [
                    {"role": "assistant", "content": raw},
                    {"role": "user", "content": (
                        f"That query was refused by the safety layer: "
                        f"{verdict.reason}\n\n"
                        "Rewrite it as a single read-only SELECT against the "
                        "analytics schema.")},
                ]
                continue

            # Run it.
            try:
                columns, rows = self._execute(verdict.sql)
            except Exception as exc:                              # noqa: BLE001
                msg = _clean_db_error(exc)
                result.attempts.append(
                    Attempt(sql=verdict.sql, allowed=True, error=msg))
                LOG.info("attempt %d failed in db: %s", attempt_no, msg)
                if attempt_no == self.max_attempts:
                    result.error = f"The query kept failing. Last error: {msg}"
                    result.sql = verdict.sql
                    break
                messages += [
                    {"role": "assistant", "content": raw},
                    {"role": "user", "content": (
                        f"That query failed with:\n{msg}\n\n"
                        "Fix it and return the corrected SELECT.")},
                ]
                continue

            result.attempts.append(Attempt(sql=verdict.sql, allowed=True))
            result.ok = True
            result.sql = verdict.sql
            result.columns = columns
            result.rows = rows
            result.row_count = len(rows)
            result.tables_used = verdict.tables
            # Only "truncated" if the guard imposed the cap and we hit it;
            # a user's own LIMIT 10 returning 10 rows is a complete answer.
            result.truncated = (verdict.limit_injected
                                and verdict.limit_applied is not None
                                and len(rows) >= verdict.limit_applied)
            result.summary = self._summarise(question, verdict.sql, columns, rows)
            break

        result.elapsed_ms = int((time.perf_counter() - started) * 1000)
        return result

    # -- helpers -----------------------------------------------------------

    def _execute(self, sql: str) -> tuple[list[str], list[tuple]]:
        with cursor(readonly=True, dict_rows=False) as cur:
            cur.execute(sql)
            columns = [d.name for d in cur.description] if cur.description else []
            rows = cur.fetchall()
        return columns, rows

    def _summarise(self, question: str, sql: str,
                   columns: list[str], rows: list[tuple]) -> str:
        if not rows:
            return ("No rows matched that. Either the filter is narrower than "
                    "you expected, or the data isn't in yet.")

        shown = rows[:MAX_ROWS_TO_MODEL]
        table = " | ".join(columns) + "\n"
        table += "\n".join(" | ".join("" if v is None else str(v) for v in r)
                           for r in shown)
        if len(rows) > len(shown):
            table += f"\n... and {len(rows) - len(shown)} more rows"

        prompt = SUMMARY_PROMPT.format(
            question=question, sql=sql, n_rows=len(rows), rows=table)
        try:
            return self.model.complete(
                "You write one-sentence answers for busy event organisers.",
                [{"role": "user", "content": prompt}],
                max_tokens=300).strip()
        except Exception:                                         # noqa: BLE001
            # The numbers are the point; a missing summary is survivable.
            return ""


def _clean_db_error(exc: Exception) -> str:
    """Postgres errors carry a position pointer that confuses the model."""
    msg = str(exc).strip()
    msg = re.sub(r"\nLINE \d+:.*$", "", msg, flags=re.DOTALL)
    msg = re.sub(r"\s+", " ", msg)
    return msg[:400]


if __name__ == "__main__":
    import sys

    logging.basicConfig(level=logging.INFO, format="%(message)s")
    question = " ".join(sys.argv[1:]) or "How many people registered in total?"

    agent = TextToSQLAgent()
    res = agent.ask(question)

    print(f"\nQ: {res.question}")
    if not res.ok:
        print(f"FAILED: {res.error}")
        for i, a in enumerate(res.attempts, 1):
            print(f"  attempt {i}: {a.guard_reason or a.error}")
        raise SystemExit(1)

    print(f"\n{res.sql}\n")
    print(" | ".join(res.columns))
    for row in res.rows[:20]:
        print(" | ".join("" if v is None else str(v) for v in row))
    if res.row_count > 20:
        print(f"... {res.row_count - 20} more")
    print(f"\n{res.summary}")
    print(f"\n[{res.elapsed_ms}ms, {len(res.attempts)} attempt(s)]")
