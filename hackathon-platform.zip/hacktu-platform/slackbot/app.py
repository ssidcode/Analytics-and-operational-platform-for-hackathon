"""
HackTU Slack bot (Slack Bolt, Socket Mode).

Organisers ask questions in the channels they already run the event from.
The bot answers in-thread with a table, a one-line summary, and a button
through to the dashboard.

Entry points:
    @hacktu how many people registered?      app_mention
    (DM)    which colleges sent the most?    message.im
    /hacktu <question>                       slash command
    /hacktu-pipeline                         ETL health
    /hacktu-help                             usage

Run:
    export SLACK_BOT_TOKEN=xoxb-...
    export SLACK_APP_TOKEN=xapp-...
    export ANTHROPIC_API_KEY=sk-ant-...
    python -m slackbot.app

Socket Mode is used so the bot needs no public URL -- it runs from a laptop
on the organisers' desk during the event, which is where it actually lived.
"""

from __future__ import annotations

import logging
import os
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from etl.config import DASHBOARD_URL, cursor                      # noqa: E402
from slackbot.agent import TextToSQLAgent                         # noqa: E402
from slackbot import formatting as F                              # noqa: E402

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-7s %(name)s  %(message)s",
    datefmt="%H:%M:%S")
LOG = logging.getLogger("hacktu.slack")

AGENT = TextToSQLAgent()

# Questions asked by people who are not organisers get a polite no. Set to a
# comma-separated list of Slack user ids to restrict; empty means open.
ALLOWED_USERS = {u.strip() for u in
                 os.getenv("HACKTU_ALLOWED_SLACK_USERS", "").split(",") if u.strip()}


def _strip_mention(text: str) -> str:
    return re.sub(r"<@[A-Z0-9]+>", "", text or "").strip()


def _authorised(user_id: str) -> bool:
    return not ALLOWED_USERS or user_id in ALLOWED_USERS


def answer(question: str, say, thread_ts: str | None = None) -> None:
    question = question.strip()
    if not question:
        say(blocks=F.help_blocks(DASHBOARD_URL), text="HackTU assistant",
            thread_ts=thread_ts)
        return

    LOG.info("Q: %s", question)
    result = AGENT.ask(question)

    if result.ok:
        say(blocks=F.result_blocks(result, DASHBOARD_URL),
            text=result.summary or "Here are the results.",
            thread_ts=thread_ts)
    else:
        say(blocks=F.error_blocks(result),
            text=result.error or "I couldn't answer that.",
            thread_ts=thread_ts)


def fetch_pipeline_runs(limit: int = 10) -> list[dict]:
    with cursor(readonly=True) as cur:
        cur.execute("""
            SELECT run_id, pipeline_name, started_at, duration_seconds, status,
                   rows_extracted, rows_loaded, rows_rejected,
                   rows_deduplicated, duplicate_rate_pct, validation_failures
            FROM analytics.v_pipeline_health
            LIMIT %s
        """, (limit,))
        return [dict(r) for r in cur.fetchall()]


def build_app():
    from slack_bolt import App

    app = App(token=os.environ["SLACK_BOT_TOKEN"])

    @app.event("app_mention")
    def on_mention(event, say):
        if not _authorised(event.get("user", "")):
            say(text="This assistant is limited to the organising team.",
                thread_ts=event.get("thread_ts") or event["ts"])
            return
        answer(_strip_mention(event.get("text", "")), say,
               thread_ts=event.get("thread_ts") or event["ts"])

    @app.event("message")
    def on_dm(event, say):
        # Only direct messages; ignore the bot's own posts and edits.
        if event.get("channel_type") != "im" or event.get("bot_id"):
            return
        if not _authorised(event.get("user", "")):
            say(text="This assistant is limited to the organising team.")
            return
        answer(event.get("text", ""), say)

    @app.command("/hacktu")
    def cmd_ask(ack, command, respond):
        ack()
        if not _authorised(command.get("user_id", "")):
            respond("This assistant is limited to the organising team.")
            return
        question = (command.get("text") or "").strip()
        if not question:
            respond(blocks=F.help_blocks(DASHBOARD_URL), text="HackTU assistant")
            return
        result = AGENT.ask(question)
        if result.ok:
            respond(blocks=F.result_blocks(result, DASHBOARD_URL),
                    text=result.summary or "Results",
                    response_type="in_channel")
        else:
            respond(blocks=F.error_blocks(result),
                    text=result.error or "Could not answer")

    @app.command("/hacktu-pipeline")
    def cmd_pipeline(ack, respond):
        ack()
        runs = fetch_pipeline_runs()
        respond(blocks=F.pipeline_blocks(runs, DASHBOARD_URL),
                text="Pipeline health", response_type="in_channel")

    @app.command("/hacktu-help")
    def cmd_help(ack, respond):
        ack()
        respond(blocks=F.help_blocks(DASHBOARD_URL), text="HackTU assistant")

    @app.action("show_sql")
    def on_show_sql(ack, body, respond):
        ack()
        sql = body["actions"][0].get("value") or "(no SQL recorded)"
        respond(replace_original=False, response_type="ephemeral",
                text=f"```sql\n{sql}\n```")

    @app.action("open_dashboard")
    def on_open_dashboard(ack):
        ack()          # URL buttons still need an ack

    @app.action("open_pipeline_dashboard")
    def on_open_pipeline(ack):
        ack()

    return app


def main() -> None:
    missing = [v for v in ("SLACK_BOT_TOKEN", "SLACK_APP_TOKEN")
               if not os.getenv(v)]
    if missing:
        print(f"Missing environment variable(s): {', '.join(missing)}")
        print("\nSet them and re-run. To try the assistant without Slack:")
        print("    python -m slackbot.agent 'how many people registered?'")
        print("    python -m slackbot.eval_agent")
        raise SystemExit(1)

    from slack_bolt.adapter.socket_mode import SocketModeHandler

    app = build_app()
    LOG.info("HackTU assistant starting (dashboard: %s)", DASHBOARD_URL)
    SocketModeHandler(app, os.environ["SLACK_APP_TOKEN"]).start()


if __name__ == "__main__":
    main()
