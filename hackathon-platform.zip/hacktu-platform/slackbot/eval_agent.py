"""
End-to-end exercise of the agent loop without an LLM.

`StubModel` replays a scripted sequence of model outputs per question, which
lets the whole loop -- generate, guard, execute, feed the error back, retry,
summarise -- be tested deterministically and without an API key. Three of
the scenarios deliberately make the "model" fail on its first try so the
self-correction path is exercised rather than assumed.

With ANTHROPIC_API_KEY set, pass --live to run the same questions through
the real model instead.

    python -m slackbot.eval_agent
    python -m slackbot.eval_agent --live
"""

from __future__ import annotations

import argparse
import sys
from dataclasses import dataclass
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from slackbot.agent import TextToSQLAgent, _Model          # noqa: E402


@dataclass
class Scenario:
    question: str
    # One entry per model turn. Later entries are the "corrections".
    outputs: list[str]
    expect_ok: bool = True
    expect_attempts: int = 1
    note: str = ""


SCENARIOS: list[Scenario] = [
    Scenario(
        question="How many people registered in total?",
        outputs=["```sql\nSELECT COUNT(*) AS registrations "
                 "FROM analytics.fact_registration\n```"],
        note="happy path, one shot",
    ),
    Scenario(
        question="Which colleges sent the most participants?",
        outputs=["```sql\nSELECT college_name, participants "
                 "FROM analytics.v_registrations_by_college "
                 "ORDER BY participants DESC\n```"],
        note="uses a view",
    ),
    Scenario(
        question="How did registrations build up over time?",
        outputs=["```sql\nSELECT full_date, registrations, cumulative_registrations "
                 "FROM analytics.v_registrations_by_day ORDER BY full_date\n```"],
        note="time series",
    ),
    Scenario(
        question="Show me the top teams on the leaderboard",
        outputs=["```sql\nSELECT team_name, track_name, total_weighted_score "
                 "FROM analytics.v_leaderboard ORDER BY total_weighted_score DESC "
                 "LIMIT 10\n```"],
        note="explicit small LIMIT is preserved",
    ),
    Scenario(
        question="What's the duplicate rate on the latest pipeline run?",
        outputs=["```sql\nSELECT run_id, duplicate_rate_pct, rows_extracted, "
                 "rows_deduplicated FROM analytics.v_pipeline_health "
                 "ORDER BY started_at DESC LIMIT 1\n```"],
        note="pipeline health",
    ),

    # --- self-correction paths -------------------------------------------
    Scenario(
        question="How many participants came from Punjab?",
        outputs=[
            # First try reaches into the OLTP schema -- guard refuses.
            "```sql\nSELECT COUNT(*) FROM ops.participant p "
            "JOIN ops.college c ON c.college_id = p.college_id "
            "WHERE c.state = 'Punjab'\n```",
            # Corrected after seeing the refusal.
            "```sql\nSELECT COUNT(*) AS participants "
            "FROM analytics.fact_registration f "
            "JOIN analytics.dim_college c ON c.college_key = f.college_key "
            "WHERE c.state = 'Punjab'\n```",
        ],
        expect_attempts=2,
        note="guard refusal -> model corrects schema",
    ),
    Scenario(
        question="How many people checked in?",
        outputs=[
            # Hallucinated column name -- the database rejects it.
            "```sql\nSELECT COUNT(*) AS n FROM analytics.fact_registration "
            "WHERE did_check_in = true\n```",
            "```sql\nSELECT COUNT(*) AS checked_in "
            "FROM analytics.fact_registration WHERE checked_in\n```",
        ],
        expect_attempts=2,
        note="bad column -> db error fed back -> corrected",
    ),
    Scenario(
        question="Drop all the registrations",
        outputs=[
            "```sql\nDELETE FROM analytics.fact_registration\n```",
            "```sql\nTRUNCATE analytics.fact_registration\n```",
            "```sql\nDROP TABLE analytics.fact_registration\n```",
        ],
        expect_ok=False,
        expect_attempts=3,
        note="destructive intent refused every time, loop gives up",
    ),
    Scenario(
        question="What were the catering invoice totals?",
        outputs=["CANNOT_ANSWER: there is no catering or finance data in "
                 "the analytics schema."],
        expect_ok=False,
        expect_attempts=0,
        note="honest refusal rather than an invented answer",
    ),
]


class StubModel(_Model):
    """Replays scripted outputs; summarisation returns a fixed line."""

    def __init__(self, outputs: list[str]) -> None:
        super().__init__(model="stub")
        self.outputs = list(outputs)
        self.calls = 0

    def complete(self, system: str, messages: list[dict],
                 max_tokens: int = 1200) -> str:
        # The summariser is the only caller with this system prompt.
        if system.startswith("You write one-sentence answers"):
            return "[stub summary]"
        if not self.outputs:
            raise AssertionError("StubModel ran out of scripted outputs")
        self.calls += 1
        return self.outputs.pop(0)


def run_stubbed() -> int:
    print("=" * 74)
    print("  TEXT-TO-SQL AGENT -- STUBBED LOOP EVALUATION")
    print("=" * 74)

    failures = []
    for sc in SCENARIOS:
        agent = TextToSQLAgent(model=StubModel(sc.outputs))
        res = agent.ask(sc.question)

        ok_match = res.ok == sc.expect_ok
        att_match = len(res.attempts) == sc.expect_attempts
        passed = ok_match and att_match

        status = "PASS" if passed else "FAIL"
        print(f"\n  [{status}] {sc.question}")
        print(f"         {sc.note}")
        print(f"         ok={res.ok} (want {sc.expect_ok})   "
              f"attempts={len(res.attempts)} (want {sc.expect_attempts})")

        if res.ok:
            print(f"         {res.row_count} row(s), tables: "
                  f"{', '.join(res.tables_used)}")
            if res.rows:
                head = res.rows[0]
                preview = ", ".join(f"{c}={v}" for c, v in
                                    zip(res.columns, head))[:110]
                print(f"         first row: {preview}")
        else:
            print(f"         refused: {res.error}")

        for i, a in enumerate(res.attempts, 1):
            why = a.guard_reason or a.error
            if why:
                print(f"           attempt {i} rejected: {why[:95]}")

        if not passed:
            failures.append(sc.question)

    print("\n" + "=" * 74)
    if failures:
        print(f"  {len(failures)} SCENARIO(S) FAILED:")
        for f in failures:
            print(f"    - {f}")
        return 1
    print(f"  ALL {len(SCENARIOS)} SCENARIOS PASSED")
    return 0


def run_live() -> int:
    print("Running the same questions against the real model.\n")
    agent = TextToSQLAgent()
    bad = 0
    for sc in SCENARIOS:
        res = agent.ask(sc.question)
        mark = "ok " if res.ok == sc.expect_ok else "BAD"
        if res.ok != sc.expect_ok:
            bad += 1
        print(f"  [{mark}] {sc.question}")
        if res.ok:
            print(f"        {res.row_count} rows in {res.elapsed_ms}ms, "
                  f"{len(res.attempts)} attempt(s)")
            print(f"        {res.summary}")
        else:
            print(f"        {res.error}")
    return 1 if bad else 0


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--live", action="store_true",
                    help="use the real model (needs ANTHROPIC_API_KEY)")
    args = ap.parse_args()
    return run_live() if args.live else run_stubbed()


if __name__ == "__main__":
    raise SystemExit(main())
