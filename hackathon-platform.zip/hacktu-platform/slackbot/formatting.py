"""
Slack Block Kit rendering.

Two constraints shape everything here: a Slack text block caps at 3000
characters, and organisers read these on a phone. So results are rendered
as a fixed-width table with columns sized to their content, truncated to
whatever fits, with a link to the dashboard for the full picture.
"""

from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal

MAX_BLOCK_CHARS = 2900
MAX_TABLE_ROWS = 15
MAX_COL_WIDTH = 34


def fmt_value(v: object) -> str:
    if v is None:
        return "—"
    if isinstance(v, bool):
        return "yes" if v else "no"
    if isinstance(v, Decimal):
        f = float(v)
        return f"{f:,.2f}".rstrip("0").rstrip(".") if f % 1 else f"{int(f):,}"
    if isinstance(v, float):
        return f"{v:,.2f}".rstrip("0").rstrip(".") if v % 1 else f"{int(v):,}"
    if isinstance(v, int):
        return f"{v:,}"
    if isinstance(v, datetime):
        return v.strftime("%d %b %H:%M")
    if isinstance(v, date):
        return v.strftime("%d %b %Y")
    return str(v)


def render_table(columns: list[str], rows: list[tuple],
                 max_rows: int = MAX_TABLE_ROWS) -> str:
    """Fixed-width table. Slack renders ``` blocks in a monospace font."""
    if not columns:
        return "_no columns_"
    if not rows:
        return "_no rows_"

    shown = rows[:max_rows]
    cells = [[fmt_value(v) for v in row] for row in shown]

    widths = []
    for i, col in enumerate(columns):
        longest = max([len(col)] + [len(r[i]) for r in cells])
        widths.append(min(longest, MAX_COL_WIDTH))

    def clip(text: str, w: int) -> str:
        return text if len(text) <= w else text[: w - 1] + "…"

    # Right-align anything that is entirely numeric.
    numeric = [
        all(_looks_numeric(r[i]) for r in cells) for i in range(len(columns))
    ]

    def line(values: list[str]) -> str:
        parts = []
        for i, v in enumerate(values):
            c = clip(v, widths[i])
            parts.append(c.rjust(widths[i]) if numeric[i] else c.ljust(widths[i]))
        return "  ".join(parts).rstrip()

    out = [line(list(columns)), line(["─" * w for w in widths])]
    out += [line(r) for r in cells]

    if len(rows) > len(shown):
        out.append(f"… {len(rows) - len(shown):,} more row(s)")

    text = "\n".join(out)
    if len(text) > MAX_BLOCK_CHARS:
        text = text[:MAX_BLOCK_CHARS - 20].rsplit("\n", 1)[0] + "\n… truncated"
    return text


def _looks_numeric(s: str) -> bool:
    return bool(s) and all(ch in "0123456789,.-—%" for ch in s)


def result_blocks(result, dashboard_url: str) -> list[dict]:
    """Block Kit payload for a successful answer."""
    blocks: list[dict] = []

    if result.summary:
        blocks.append({
            "type": "section",
            "text": {"type": "mrkdwn", "text": result.summary},
        })

    table = render_table(result.columns, result.rows)
    blocks.append({
        "type": "section",
        "text": {"type": "mrkdwn", "text": f"```\n{table}\n```"},
    })

    meta = (f"{result.row_count:,} row(s) · {result.elapsed_ms:,} ms"
            f" · {len(result.attempts)} attempt(s)")
    if result.truncated:
        meta += " · capped — open the dashboard for the full set"

    blocks.append({
        "type": "context",
        "elements": [{"type": "mrkdwn", "text": meta}],
    })

    actions = [
        {"type": "button",
         "text": {"type": "plain_text", "text": "Open dashboard"},
         "url": dashboard_url,
         "action_id": "open_dashboard"},
        {"type": "button",
         "text": {"type": "plain_text", "text": "Show SQL"},
         "action_id": "show_sql",
         "value": (result.sql or "")[:1900]},
    ]
    blocks.append({"type": "actions", "elements": actions})
    return blocks


def error_blocks(result) -> list[dict]:
    blocks = [{
        "type": "section",
        "text": {"type": "mrkdwn",
                 "text": f":warning:  {result.error or 'Something went wrong.'}"},
    }]
    if result.attempts:
        detail = "\n".join(
            f"• attempt {i}: {(a.guard_reason or a.error or '')[:160]}"
            for i, a in enumerate(result.attempts, 1)
            if a.guard_reason or a.error)
        if detail:
            blocks.append({"type": "context",
                           "elements": [{"type": "mrkdwn", "text": detail}]})
    return blocks


def pipeline_blocks(runs: list[dict], dashboard_url: str) -> list[dict]:
    """Rendering for /hacktu-pipeline -- the health summary."""
    if not runs:
        return [{"type": "section",
                 "text": {"type": "mrkdwn", "text": "No pipeline runs recorded yet."}}]

    latest = runs[0]
    icon = {"success": ":large_green_circle:",
            "partial": ":large_yellow_circle:",
            "failed": ":red_circle:",
            "running": ":hourglass_flowing_sand:"}.get(latest["status"], ":white_circle:")

    headline = (
        f"{icon}  *Last run #{latest['run_id']}* — {latest['status']}\n"
        f"*{float(latest['duration_seconds'] or 0):.2f}s* · "
        f"{latest['rows_extracted']:,} extracted → "
        f"{latest['rows_loaded']:,} loaded\n"
        f"*{float(latest['duplicate_rate_pct'] or 0):.2f}%* duplicate rate · "
        f"*{latest['rows_rejected']:,}* rejected · "
        f"*{latest['validation_failures']:,}* validation failures"
    )

    cols = ["run", "when", "status", "secs", "in", "loaded", "dup %", "dq fails"]
    rows = [(r["run_id"], r["started_at"], r["status"],
             float(r["duration_seconds"] or 0), r["rows_extracted"],
             r["rows_loaded"], float(r["duplicate_rate_pct"] or 0),
             r["validation_failures"])
            for r in runs[:10]]

    return [
        {"type": "section", "text": {"type": "mrkdwn", "text": headline}},
        {"type": "section",
         "text": {"type": "mrkdwn",
                  "text": f"```\n{render_table(cols, rows)}\n```"}},
        {"type": "actions", "elements": [
            {"type": "button",
             "text": {"type": "plain_text", "text": "Pipeline health dashboard"},
             "url": f"{dashboard_url}/?tab=pipeline",
             "action_id": "open_pipeline_dashboard"}]},
    ]


def help_blocks(dashboard_url: str) -> list[dict]:
    text = (
        "*HackTU data assistant*\n"
        "Ask in plain English — mention me, DM me, or use `/hacktu`.\n\n"
        "*Try:*\n"
        "• how many people registered?\n"
        "• which colleges sent the most participants?\n"
        "• how many registered in the last week before the deadline?\n"
        "• what's the check-in rate by track?\n"
        "• show me the top 10 teams\n"
        "• which teams are missing a submission?\n"
        "• what's the duplicate rate on the latest pipeline run?\n\n"
        "*Commands:*\n"
        "• `/hacktu <question>` — ask anything\n"
        "• `/hacktu-pipeline` — ETL health summary\n"
        "• `/hacktu-help` — this message\n\n"
        "_I can only read the analytics schema. I can't change anything._"
    )
    return [
        {"type": "section", "text": {"type": "mrkdwn", "text": text}},
        {"type": "actions", "elements": [
            {"type": "button",
             "text": {"type": "plain_text", "text": "Open dashboard"},
             "url": dashboard_url, "action_id": "open_dashboard"}]},
    ]
