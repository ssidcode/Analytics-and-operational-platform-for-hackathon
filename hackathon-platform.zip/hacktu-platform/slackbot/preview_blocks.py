"""
Render the Slack payloads to the terminal, against the live database.

Block Kit is tedious to eyeball inside Slack while iterating, and a table
that looks fine at 12 columns is unreadable on a phone. This prints exactly
what the bot would post.

    python -m slackbot.preview_blocks
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from slackbot import formatting as F                     # noqa: E402
from slackbot.agent import TextToSQLAgent                # noqa: E402
from slackbot.app import fetch_pipeline_runs             # noqa: E402
from slackbot.eval_agent import StubModel                # noqa: E402

DASH = "http://localhost:8501"

SAMPLES = [
    ("Which colleges sent the most participants?",
     "SELECT college_name, state, participants, checked_in "
     "FROM analytics.v_registrations_by_college "
     "ORDER BY participants DESC LIMIT 8"),
    ("How is each track doing against capacity?",
     "SELECT track_name, capacity, preferred_by, assigned_to, capacity_used_pct "
     "FROM analytics.v_track_demand ORDER BY assigned_to DESC"),
    ("Top teams on the leaderboard",
     "SELECT team_name, track_name, total_weighted_score, judges_scored "
     "FROM analytics.v_leaderboard ORDER BY total_weighted_score DESC LIMIT 8"),
    ("How many registered in the final week?",
     "SELECT d.reg_window_phase, COUNT(*) AS registrations "
     "FROM analytics.fact_registration f "
     "JOIN analytics.dim_date d ON d.date_key = f.date_key "
     "GROUP BY d.reg_window_phase ORDER BY registrations DESC"),
]


def show(blocks: list[dict]) -> None:
    for b in blocks:
        if b["type"] == "section":
            print(b["text"]["text"])
        elif b["type"] == "context":
            print("  " + " ".join(e["text"] for e in b["elements"]))
        elif b["type"] == "actions":
            labels = " ".join(f"[ {e['text']['text']} ]" for e in b["elements"])
            print("  " + labels)
    print()


def main() -> None:
    print("#" * 74)
    print("#  /hacktu-pipeline")
    print("#" * 74)
    show(F.pipeline_blocks(fetch_pipeline_runs(), DASH))

    for question, sql in SAMPLES:
        print("#" * 74)
        print(f"#  @hacktu {question}")
        print("#" * 74)
        agent = TextToSQLAgent(model=StubModel([f"```sql\n{sql}\n```"]))
        res = agent.ask(question)
        if res.ok:
            # The stub's summary is a placeholder; show the real shape instead.
            res.summary = f"_(summary written by the model at run time)_"
            show(F.result_blocks(res, DASH))
        else:
            show(F.error_blocks(res))

    print("#" * 74)
    print("#  a refused question")
    print("#" * 74)
    agent = TextToSQLAgent(model=StubModel([
        "```sql\nDELETE FROM analytics.fact_registration\n```",
        "```sql\nSELECT * FROM ops.participant\n```",
        "```sql\nDROP TABLE analytics.dim_team\n```",
    ]))
    show(F.error_blocks(agent.ask("delete all the registrations")))

    print("#" * 74)
    print("#  /hacktu-help")
    print("#" * 74)
    show(F.help_blocks(DASH))


if __name__ == "__main__":
    main()
