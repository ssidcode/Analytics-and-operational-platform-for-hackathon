"""
The schema description handed to the text-to-SQL model.

Two things make generated SQL reliable, and both live here:

  1. A *curated* schema description, not a dump of information_schema. The
     model needs to know what `reg_window_phase` means, not that it is
     varchar(16). Column comments carry the business meaning.
  2. Live column values for the low-cardinality dimensions, refreshed from
     the database. Without them the model guesses 'AI/ML' as 'AI and ML'
     and returns an empty result that looks like a real answer.

`build_schema_prompt()` is cached per process and refreshed on a TTL, so a
busy channel does not re-query the catalog on every question.
"""

from __future__ import annotations

import time

from etl.config import cursor

_CACHE: dict[str, tuple[float, str]] = {}
_TTL_SECONDS = 600

# ---------------------------------------------------------------------------
# Hand-written table documentation. This is the part that does the work.
# ---------------------------------------------------------------------------

TABLE_DOCS = """
SCHEMA: analytics  (star schema, read-only)

── FACTS ───────────────────────────────────────────────────────────────────

fact_registration -- ONE ROW PER PARTICIPANT (after de-duplication).
  This is the table for any "how many people" question.
    participant_key      -> dim_participant
    college_key          -> dim_college       (NULL if college was blank)
    preferred_track_key  -> dim_track         track the person asked for
    assigned_track_key   -> dim_track         track their team was placed in
    team_key             -> dim_team          (NULL if not on a team)
    date_key             -> dim_date          date of registration
    registered_at        timestamptz
    registration_count   always 1; SUM() it for totals
    source_row_count     how many raw form rows collapsed into this person
    duplicate_rows_folded  source_row_count - 1
    got_preferred_track  bool: assigned track == preferred track
    checked_in           bool: turned up on the day
    hours_to_deadline    hours between registering and the form closing
                         (large = registered early, near 0 = last minute)

fact_score -- ONE ROW PER (team, judge, criterion, round).
    team_key, judge_key, track_key, date_key
    criterion_name   e.g. 'Technical Complexity'
    round_no         1..3
    raw_score        what the judge typed, 0..max_score
    weight           criterion weight, sums to 1.0 across criteria
    weighted_score   (raw_score / max_score) * weight * 100
    max_score        usually 10
  A team's total is SUM(weighted_score) averaged over judges -- prefer the
  v_leaderboard view unless the question is about individual judges.

fact_pipeline_run -- ONE ROW PER ETL EXECUTION.
    run_id, pipeline_name, started_at, duration_seconds, status
    rows_extracted, rows_rejected, rows_deduplicated, rows_loaded
    duplicate_rate_pct    rows_deduplicated / rows_extracted * 100
    validation_failures   total failing rows across all data-quality rules
    reject_rule_count, warn_rule_count

── DIMENSIONS ──────────────────────────────────────────────────────────────

dim_participant
    participant_key, participant_id, full_name, email, gender,
    degree, branch, year_of_study (1-6), graduation_year,
    experience_level, has_github (bool), tshirt_size,
    dietary_preference, accommodation_required (bool), heard_from,
    was_duplicated (bool: this person submitted the form more than once)

dim_college
    college_key, college_id, college_name, city, state,
    is_host_college (bool), region ('North'|'South'|'East'|'West'|'Other'),
    is_local (bool: same state as the venue)

dim_track
    track_key, track_id, track_name, description, capacity

dim_team
    team_key, team_id, team_name, track_name, assignment_method,
    status, team_size, has_submission (bool)

dim_judge
    judge_key, judge_id, judge_name, organisation, track_name

dim_date
    date_key (YYYYMMDD int), full_date, day_of_week, day_name,
    week_of_year, month_no, month_name, quarter_no, year_no,
    is_weekend, days_to_event, reg_window_phase

── VIEWS (prefer these for common questions) ───────────────────────────────

v_registrations_by_day       full_date, day_name, reg_window_phase,
                             registrations, cumulative_registrations
v_registrations_by_college   college_name, city, state, region,
                             is_host_college, participants, checked_in,
                             avg_submissions_per_person
v_track_demand               track_name, capacity, preferred_by, assigned_to,
                             capacity_used_pct
v_pipeline_health            run_id, pipeline_name, started_at,
                             duration_seconds, status, rows_extracted,
                             rows_loaded, rows_rejected, rows_deduplicated,
                             duplicate_rate_pct, validation_failures,
                             reject_rate_pct
v_leaderboard                team_name, track_name, team_size, status,
                             total_weighted_score, judges_scored, score_cells
"""

QUERY_RULES = """
RULES
  * Postgres dialect. Output ONE SELECT statement and nothing else.
  * Every table must be in the `analytics` schema. The `ops` schema,
    pg_catalog and information_schema are not readable and will be refused.
  * Qualify tables as analytics.<table>.
  * Never write INSERT/UPDATE/DELETE/DROP/CREATE/ALTER/GRANT/COPY. The
    connection is read-only; such a query fails and wastes the user's turn.
  * Do not add a LIMIT unless the question implies a top-N; one is applied
    automatically.
  * Use ILIKE for name matching -- organisers type 'thapar', not the full
    institution name.
  * Count people with COUNT(*) on fact_registration, not on dim_participant,
    so the grain is unambiguous.
  * Round percentages and averages to 1 or 2 decimals.
  * Give computed columns readable aliases: `AS registrations`, not `AS c`.
  * For "per day"/"over time", join dim_date and order by full_date.
"""

# ---------------------------------------------------------------------------
# Live value sampling
# ---------------------------------------------------------------------------

_VALUE_QUERIES: list[tuple[str, str]] = [
    ("track_name", "SELECT track_name FROM analytics.dim_track ORDER BY track_name"),
    ("dim_college.state",
     "SELECT DISTINCT state FROM analytics.dim_college ORDER BY state"),
    ("dim_college.region",
     "SELECT DISTINCT region FROM analytics.dim_college ORDER BY region"),
    ("dim_participant.experience_level",
     "SELECT DISTINCT experience_level FROM analytics.dim_participant "
     "WHERE experience_level IS NOT NULL ORDER BY 1"),
    ("dim_participant.heard_from",
     "SELECT DISTINCT heard_from FROM analytics.dim_participant "
     "WHERE heard_from IS NOT NULL ORDER BY 1"),
    ("dim_participant.degree",
     "SELECT DISTINCT degree FROM analytics.dim_participant "
     "WHERE degree IS NOT NULL ORDER BY 1"),
    ("dim_team.status",
     "SELECT DISTINCT status FROM analytics.dim_team ORDER BY 1"),
    ("dim_team.assignment_method",
     "SELECT DISTINCT assignment_method FROM analytics.dim_team "
     "WHERE assignment_method IS NOT NULL ORDER BY 1"),
    ("fact_score.criterion_name",
     "SELECT DISTINCT criterion_name FROM analytics.fact_score ORDER BY 1"),
    ("dim_date.reg_window_phase",
     "SELECT DISTINCT reg_window_phase FROM analytics.dim_date "
     "WHERE reg_window_phase IS NOT NULL ORDER BY 1"),
]


def _fetch_enum_values(max_values: int = 25) -> str:
    lines = ["LIVE COLUMN VALUES (use these exact strings)"]
    with cursor(readonly=True) as cur:
        for label, sql in _VALUE_QUERIES:
            try:
                cur.execute(sql)
                vals = [str(list(r.values())[0]) for r in cur.fetchall()]
            except Exception:                                     # noqa: BLE001
                continue
            if not vals:
                continue
            shown = vals[:max_values]
            suffix = f"  (+{len(vals) - len(shown)} more)" if len(vals) > len(shown) else ""
            lines.append(f"  {label}: " + ", ".join(f"'{v}'" for v in shown) + suffix)
    return "\n".join(lines)


def _fetch_scale() -> str:
    """A few counts, so the model knows whether an answer is plausible."""
    queries = {
        "participants": "SELECT COUNT(*) AS n FROM analytics.fact_registration",
        "teams": "SELECT COUNT(*) AS n FROM analytics.dim_team",
        "colleges": "SELECT COUNT(*) AS n FROM analytics.dim_college",
        "judges": "SELECT COUNT(*) AS n FROM analytics.dim_judge",
        "score rows": "SELECT COUNT(*) AS n FROM analytics.fact_score",
        "pipeline runs": "SELECT COUNT(*) AS n FROM analytics.fact_pipeline_run",
    }
    parts = []
    with cursor(readonly=True) as cur:
        for label, sql in queries.items():
            try:
                cur.execute(sql)
                parts.append(f"{label}={cur.fetchone()['n']}")
            except Exception:                                     # noqa: BLE001
                continue
        try:
            cur.execute("""
                SELECT MIN(full_date) AS a, MAX(full_date) AS b
                FROM analytics.dim_date d
                JOIN analytics.fact_registration f ON f.date_key = d.date_key
            """)
            row = cur.fetchone()
            if row and row["a"]:
                parts.append(f"registration window={row['a']}..{row['b']}")
        except Exception:                                         # noqa: BLE001
            pass
    return "CURRENT SCALE: " + ", ".join(parts)


def build_schema_prompt(force_refresh: bool = False) -> str:
    now = time.time()
    cached = _CACHE.get("schema")
    if cached and not force_refresh and now - cached[0] < _TTL_SECONDS:
        return cached[1]

    prompt = "\n\n".join([
        TABLE_DOCS.strip(),
        _fetch_scale(),
        _fetch_enum_values(),
        QUERY_RULES.strip(),
    ])
    _CACHE["schema"] = (now, prompt)
    return prompt


if __name__ == "__main__":
    print(build_schema_prompt())
