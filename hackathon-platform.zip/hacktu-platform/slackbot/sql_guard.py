"""
Read-only safety layer for LLM-generated SQL.

An LLM writing SQL against a production database is a prompt injection away
from `DROP TABLE`. The defence here is deliberately not a regex blocklist --
blocklists lose to `DeLeTe`, to `/*x*/`, to string concatenation, and to
every other trick. Instead the statement is parsed into an AST and checked
against an allowlist: if the parse does not produce exactly one SELECT whose
every referenced table is on the approved list, it does not run.

This is layer 3 of 4. The role the agent connects as cannot write even if
this file is wrong (see sql/05_readonly_role.sql).

    guard = SQLGuard()
    verdict = guard.check(sql)
    if verdict.allowed:
        run(verdict.sql)        # note: the rewritten SQL, with LIMIT applied
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

import sqlglot
from sqlglot import exp

DIALECT = "postgres"

# Only these may be read. Everything in ops.* is absent by design: the bot
# answers analytical questions, and the star schema is what it is for.
ALLOWED_SCHEMAS = {"analytics"}

ALLOWED_TABLES = {
    "dim_date", "dim_participant", "dim_college", "dim_track",
    "dim_team", "dim_judge",
    "fact_registration", "fact_score", "fact_pipeline_run",
    "v_registrations_by_day", "v_registrations_by_college",
    "v_track_demand", "v_pipeline_health", "v_leaderboard",
}

# Expression types that must never appear anywhere in the tree. Anything
# that writes, changes structure, reads the filesystem, or escapes to
# another database.
FORBIDDEN_NODES: tuple[type, ...] = (
    exp.Insert, exp.Update, exp.Delete, exp.Drop, exp.Create, exp.Alter,
    exp.TruncateTable, exp.Grant, exp.Merge, exp.Command,
    exp.Transaction, exp.Commit, exp.Rollback, exp.Use,
)

# Functions that read or write outside the query. pg_read_file and friends
# are the classic escape; dblink and postgres_fdw reach another server;
# lo_* touch large objects on disk.
FORBIDDEN_FUNCTIONS = {
    "pg_read_file", "pg_read_binary_file", "pg_ls_dir", "pg_stat_file",
    "lo_import", "lo_export", "lo_get", "lo_put",
    "dblink", "dblink_exec", "dblink_connect", "postgres_fdw_handler",
    "pg_sleep", "pg_sleep_for", "pg_sleep_until",
    "pg_terminate_backend", "pg_cancel_backend",
    "pg_reload_conf", "pg_rotate_logfile",
    "set_config", "current_setting",
    "query_to_xml", "xpath",
    "copy", "system",
}

# Schemas that leak server internals or other tenants' data.
FORBIDDEN_SCHEMAS = {"pg_catalog", "information_schema", "pg_toast", "ops", "public"}

MAX_LIMIT = 500
DEFAULT_LIMIT = 100
MAX_SQL_LENGTH = 6000


@dataclass
class Verdict:
    allowed: bool
    sql: str = ""                      # the rewritten, safe-to-run statement
    reason: str = ""                   # why it was refused, shown to the user
    tables: list[str] = field(default_factory=list)
    limit_applied: int | None = None
    # True when the guard added or lowered the LIMIT. A user's own small
    # LIMIT is honoured, and a full result under that limit is not "capped".
    limit_injected: bool = False
    warnings: list[str] = field(default_factory=list)


class SQLGuard:
    def __init__(self, max_limit: int = MAX_LIMIT,
                 default_limit: int = DEFAULT_LIMIT) -> None:
        self.max_limit = max_limit
        self.default_limit = default_limit

    # -- public ------------------------------------------------------------

    def check(self, sql: str) -> Verdict:
        sql = (sql or "").strip().rstrip(";").strip()

        if not sql:
            return Verdict(False, reason="Empty query.")
        if len(sql) > MAX_SQL_LENGTH:
            return Verdict(False, reason=(
                f"Query is {len(sql)} characters, over the "
                f"{MAX_SQL_LENGTH}-character limit."))

        # A statement separator that survives into the parsed text means the
        # model tried to send more than one statement.
        try:
            statements = sqlglot.parse(sql, dialect=DIALECT)
        except Exception as exc:                                  # noqa: BLE001
            return Verdict(False, reason=f"Could not parse the SQL: {exc}")

        statements = [s for s in statements if s is not None]
        if len(statements) != 1:
            return Verdict(False, reason=(
                f"Expected exactly one statement, found {len(statements)}. "
                "Multi-statement queries are not allowed."))

        tree = statements[0]

        # Top level must be a SELECT (or a WITH whose body is a SELECT, or a
        # set operation over SELECTs).
        if not isinstance(tree, (exp.Select, exp.Union, exp.Except, exp.Intersect,
                                 exp.Subquery)):
            return Verdict(False, reason=(
                f"Only SELECT queries are allowed; this is a "
                f"{type(tree).__name__.upper()} statement."))

        for check in (self._check_forbidden_nodes,
                      self._check_into,
                      self._check_functions,
                      self._check_tables):
            verdict = check(tree)
            if verdict is not None:
                return verdict

        tables = sorted(self._referenced_tables(tree))
        tree, limit, injected = self._apply_limit(tree)

        return Verdict(
            allowed=True,
            sql=tree.sql(dialect=DIALECT, pretty=True),
            tables=tables,
            limit_applied=limit,
            limit_injected=injected,
        )

    # -- individual checks -------------------------------------------------

    def _check_forbidden_nodes(self, tree: exp.Expression) -> Verdict | None:
        for node in tree.walk():
            if isinstance(node, FORBIDDEN_NODES):
                return Verdict(False, reason=(
                    f"Statement contains a {type(node).__name__.upper()} "
                    "operation. This assistant can only read."))
        return None

    def _check_into(self, tree: exp.Expression) -> Verdict | None:
        """SELECT ... INTO creates a table. So does CREATE TABLE AS."""
        for node in tree.walk():
            if isinstance(node, exp.Into):
                return Verdict(False, reason=(
                    "SELECT ... INTO writes a new table and is not allowed."))
        return None

    def _check_functions(self, tree: exp.Expression) -> Verdict | None:
        for node in tree.walk():
            name = None
            if isinstance(node, exp.Anonymous):
                name = str(node.this or "")
            elif isinstance(node, exp.Func):
                name = node.sql_name()
            if not name:
                continue
            if name.lower() in FORBIDDEN_FUNCTIONS:
                return Verdict(False, reason=(
                    f"The function {name}() is not permitted."))
        return None

    def _check_tables(self, tree: exp.Expression) -> Verdict | None:
        # Names introduced by WITH are legitimate references, not base tables.
        cte_names = {
            (cte.alias_or_name or "").lower()
            for cte in tree.find_all(exp.CTE)
        }

        for table in tree.find_all(exp.Table):
            name = (table.name or "").lower()
            schema = (table.db or "").lower()
            catalog = (table.catalog or "").lower()

            if not name:
                continue
            if name in cte_names and not schema:
                continue

            if catalog:
                return Verdict(False, reason=(
                    "Cross-database references are not allowed "
                    f"(found `{catalog}.{schema}.{name}`)."))

            if schema and schema in FORBIDDEN_SCHEMAS:
                return Verdict(False, reason=(
                    f"The `{schema}` schema is not readable by this assistant. "
                    "Query the `analytics` schema instead."))

            if schema and schema not in ALLOWED_SCHEMAS:
                return Verdict(False, reason=(
                    f"Unknown schema `{schema}`. Only `analytics` is available."))

            if name not in ALLOWED_TABLES:
                close = _closest(name, ALLOWED_TABLES)
                hint = f" Did you mean `analytics.{close}`?" if close else ""
                return Verdict(False, reason=(
                    f"`{name}` is not a table this assistant can read.{hint}"))

        return None

    # -- rewriting ---------------------------------------------------------

    def _apply_limit(self, tree: exp.Expression) -> tuple[exp.Expression, int, bool]:
        """Cap the result set. A Slack message cannot show 50,000 rows anyway.

        Returns (tree, effective_limit, injected_by_guard).
        """
        existing = tree.args.get("limit") if hasattr(tree, "args") else None

        if existing is not None:
            try:
                current = int(existing.expression.this)
            except (AttributeError, TypeError, ValueError):
                current = None
            if current is not None and current <= self.max_limit:
                return tree, current, False
            return tree.limit(self.max_limit), self.max_limit, True

        return tree.limit(self.default_limit), self.default_limit, True

    def _referenced_tables(self, tree: exp.Expression) -> set[str]:
        cte_names = {(c.alias_or_name or "").lower() for c in tree.find_all(exp.CTE)}
        out = set()
        for t in tree.find_all(exp.Table):
            n = (t.name or "").lower()
            if n and n not in cte_names:
                out.add(n)
        return out


def _closest(name: str, options: set[str]) -> str | None:
    """Cheap suggestion for a near-miss table name."""
    import difflib
    matches = difflib.get_close_matches(name, sorted(options), n=1, cutoff=0.6)
    return matches[0] if matches else None


def strip_markdown_fences(text: str) -> str:
    """Models like to wrap SQL in ```sql fences. Take what is inside."""
    fenced = re.search(r"```(?:sql)?\s*\n(.*?)```", text, re.DOTALL | re.IGNORECASE)
    if fenced:
        return fenced.group(1).strip()
    return text.strip()
