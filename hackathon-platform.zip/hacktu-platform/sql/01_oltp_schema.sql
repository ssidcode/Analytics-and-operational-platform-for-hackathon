-- ============================================================================
-- HackTU -- OLTP schema (3NF)
--
-- This is the transactional side: registrations come in here, teams form
-- here, judges score here. Normalised so that a college rename or a track
-- capacity change is a single-row UPDATE, and so the ETL has a clean,
-- constraint-enforced target to load into.
--
-- Everything lives in the `ops` schema. The star schema that the dashboard
-- and the Slack bot read from lives in `analytics` (see 02_olap_schema.sql).
-- ============================================================================

CREATE EXTENSION IF NOT EXISTS citext;
CREATE EXTENSION IF NOT EXISTS pg_trgm;

DROP SCHEMA IF EXISTS ops CASCADE;
CREATE SCHEMA ops;

SET search_path TO ops, public;

-- ---------------------------------------------------------------------------
-- Reference / lookup tables
-- ---------------------------------------------------------------------------

CREATE TABLE ops.college (
    college_id      SERIAL PRIMARY KEY,
    college_name    TEXT        NOT NULL,
    city            TEXT        NOT NULL,
    state           TEXT        NOT NULL,
    -- Normalised key: lower-cased, punctuation-stripped name. Two spellings
    -- of the same institution collapse to one row via this unique index.
    name_key        TEXT        NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT uq_college_name_key UNIQUE (name_key)
);

CREATE TABLE ops.track (
    track_id        SERIAL PRIMARY KEY,
    track_name      TEXT        NOT NULL UNIQUE,
    description     TEXT,
    capacity        INTEGER     NOT NULL CHECK (capacity > 0),
    is_active       BOOLEAN     NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE ops.problem_statement (
    problem_id      SERIAL PRIMARY KEY,
    track_id        INTEGER     NOT NULL REFERENCES ops.track(track_id),
    code            TEXT        NOT NULL UNIQUE,
    title           TEXT        NOT NULL,
    sponsor         TEXT,
    difficulty      TEXT        NOT NULL DEFAULT 'medium'
                    CHECK (difficulty IN ('easy', 'medium', 'hard'))
);

-- ---------------------------------------------------------------------------
-- Participants
-- ---------------------------------------------------------------------------

CREATE TABLE ops.participant (
    participant_id      SERIAL PRIMARY KEY,
    -- The registration id from the intake form that *won* dedupe. Kept so an
    -- organiser can trace a row in the DB back to a row in the export.
    source_registration_id TEXT NOT NULL,
    full_name           TEXT        NOT NULL,
    email               CITEXT      NOT NULL,
    -- Canonical form of the email used for identity: lower-cased, Gmail dots
    -- and +tags removed. This is the dedupe key.
    email_key           TEXT        NOT NULL,
    phone_e164          TEXT,
    gender              TEXT,
    college_id          INTEGER     REFERENCES ops.college(college_id),
    degree              TEXT,
    branch              TEXT,
    year_of_study       SMALLINT    CHECK (year_of_study BETWEEN 1 AND 6),
    graduation_year     SMALLINT    CHECK (graduation_year BETWEEN 2020 AND 2035),
    roll_number         TEXT,
    experience_level    TEXT,
    github_handle       TEXT,
    tshirt_size         TEXT        CHECK (tshirt_size IN ('XS','S','M','L','XL','XXL')),
    dietary_preference  TEXT,
    accommodation_required BOOLEAN  NOT NULL DEFAULT FALSE,
    heard_from          TEXT,
    preferred_track_id  INTEGER     REFERENCES ops.track(track_id),
    registered_at       TIMESTAMPTZ NOT NULL,
    -- How many raw rows collapsed into this participant. 1 == submitted once.
    source_row_count    SMALLINT    NOT NULL DEFAULT 1,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT uq_participant_email_key UNIQUE (email_key)
);

-- ---------------------------------------------------------------------------
-- Teams
-- ---------------------------------------------------------------------------

CREATE TABLE ops.team (
    team_id         SERIAL PRIMARY KEY,
    team_name       TEXT        NOT NULL UNIQUE,
    track_id        INTEGER     REFERENCES ops.track(track_id),
    problem_id      INTEGER     REFERENCES ops.problem_statement(problem_id),
    -- Assignment bookkeeping, written by ops.assign_tracks().
    assignment_method TEXT      CHECK (assignment_method IN
                                 ('preference', 'balanced_overflow', 'manual')),
    assigned_at     TIMESTAMPTZ,
    status          TEXT        NOT NULL DEFAULT 'registered'
                    CHECK (status IN ('registered','checked_in','submitted','withdrawn','disqualified')),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE ops.team_member (
    team_id         INTEGER     NOT NULL REFERENCES ops.team(team_id) ON DELETE CASCADE,
    participant_id  INTEGER     NOT NULL REFERENCES ops.participant(participant_id) ON DELETE CASCADE,
    is_leader       BOOLEAN     NOT NULL DEFAULT FALSE,
    joined_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (team_id, participant_id),
    -- A participant belongs to exactly one team.
    CONSTRAINT uq_member_one_team UNIQUE (participant_id)
);

-- Exactly one leader per team, enforced by a partial unique index.
CREATE UNIQUE INDEX uq_team_single_leader
    ON ops.team_member (team_id) WHERE is_leader;

-- ---------------------------------------------------------------------------
-- Event operations: check-in, submissions, judging
-- ---------------------------------------------------------------------------

CREATE TABLE ops.check_in (
    check_in_id     SERIAL PRIMARY KEY,
    participant_id  INTEGER     NOT NULL UNIQUE
                                REFERENCES ops.participant(participant_id),
    checked_in_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    kit_collected   BOOLEAN     NOT NULL DEFAULT FALSE,
    desk            TEXT
);

CREATE TABLE ops.submission (
    submission_id   SERIAL PRIMARY KEY,
    team_id         INTEGER     NOT NULL UNIQUE REFERENCES ops.team(team_id),
    repo_url        TEXT,
    demo_url        TEXT,
    submitted_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    is_late         BOOLEAN     NOT NULL DEFAULT FALSE
);

CREATE TABLE ops.judge (
    judge_id        SERIAL PRIMARY KEY,
    judge_name      TEXT        NOT NULL,
    organisation    TEXT,
    email           CITEXT      NOT NULL UNIQUE,
    track_id        INTEGER     REFERENCES ops.track(track_id)
);

CREATE TABLE ops.scoring_criterion (
    criterion_id    SERIAL PRIMARY KEY,
    criterion_name  TEXT        NOT NULL UNIQUE,
    -- Weights across all active criteria are expected to sum to 1.0;
    -- ops.aggregate_scores() asserts this at run time.
    weight          NUMERIC(4,3) NOT NULL CHECK (weight > 0 AND weight <= 1),
    max_score       SMALLINT    NOT NULL DEFAULT 10 CHECK (max_score > 0),
    is_active       BOOLEAN     NOT NULL DEFAULT TRUE
);

CREATE TABLE ops.score (
    score_id        BIGSERIAL PRIMARY KEY,
    team_id         INTEGER     NOT NULL REFERENCES ops.team(team_id) ON DELETE CASCADE,
    judge_id        INTEGER     NOT NULL REFERENCES ops.judge(judge_id),
    criterion_id    INTEGER     NOT NULL REFERENCES ops.scoring_criterion(criterion_id),
    round_no        SMALLINT    NOT NULL DEFAULT 1 CHECK (round_no BETWEEN 1 AND 3),
    raw_score       NUMERIC(5,2) NOT NULL CHECK (raw_score >= 0),
    comment         TEXT,
    scored_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    -- One judge scores a given criterion for a given team once per round.
    CONSTRAINT uq_score_cell UNIQUE (team_id, judge_id, criterion_id, round_no)
);

-- Materialised result of ops.aggregate_scores(). Kept as a table rather than
-- a view because the leaderboard is read far more often than it is written,
-- and judges' scores land in bursts at the end of each round.
CREATE TABLE ops.team_result (
    team_id         INTEGER     PRIMARY KEY REFERENCES ops.team(team_id) ON DELETE CASCADE,
    round_no        SMALLINT    NOT NULL,
    weighted_score  NUMERIC(6,3) NOT NULL,
    judges_scored   SMALLINT    NOT NULL,
    criteria_scored SMALLINT    NOT NULL,
    is_complete     BOOLEAN     NOT NULL,
    overall_rank    INTEGER,
    track_rank      INTEGER,
    computed_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------------------
-- Pipeline observability
--
-- The ETL writes one row per run here plus one row per failed validation
-- rule. The Streamlit "pipeline health" tab and the Slack bot's /pipeline
-- command both read exclusively from these two tables.
-- ---------------------------------------------------------------------------

CREATE TABLE ops.etl_run (
    run_id              BIGSERIAL PRIMARY KEY,
    pipeline_name       TEXT        NOT NULL,
    started_at          TIMESTAMPTZ NOT NULL,
    finished_at         TIMESTAMPTZ,
    duration_seconds    NUMERIC(10,3),
    status              TEXT        NOT NULL DEFAULT 'running'
                        CHECK (status IN ('running','success','failed','partial')),
    source_file         TEXT,
    rows_extracted      INTEGER     NOT NULL DEFAULT 0,
    rows_rejected       INTEGER     NOT NULL DEFAULT 0,
    rows_deduplicated   INTEGER     NOT NULL DEFAULT 0,
    rows_loaded         INTEGER     NOT NULL DEFAULT 0,
    duplicate_rate_pct  NUMERIC(6,3),
    error_message       TEXT,
    git_sha             TEXT
);

CREATE TABLE ops.data_quality_event (
    event_id        BIGSERIAL PRIMARY KEY,
    run_id          BIGINT      NOT NULL REFERENCES ops.etl_run(run_id) ON DELETE CASCADE,
    rule_name       TEXT        NOT NULL,
    severity        TEXT        NOT NULL CHECK (severity IN ('reject','warn','info')),
    column_name     TEXT,
    failure_count   INTEGER     NOT NULL DEFAULT 0,
    rows_checked    INTEGER     NOT NULL DEFAULT 0,
    sample_values   JSONB,
    detected_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Rows that failed a `reject`-severity rule land here instead of being
-- silently dropped, so an organiser can fix and re-submit them.
CREATE TABLE ops.rejected_registration (
    rejected_id     BIGSERIAL PRIMARY KEY,
    run_id          BIGINT      NOT NULL REFERENCES ops.etl_run(run_id) ON DELETE CASCADE,
    source_registration_id TEXT,
    payload         JSONB       NOT NULL,
    failed_rules    TEXT[]      NOT NULL,
    rejected_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Every raw row that was folded into a surviving participant. This is what
-- makes the duplicate-rate number auditable rather than a claim.
CREATE TABLE ops.duplicate_registration (
    duplicate_id    BIGSERIAL PRIMARY KEY,
    run_id          BIGINT      NOT NULL REFERENCES ops.etl_run(run_id) ON DELETE CASCADE,
    kept_registration_id    TEXT NOT NULL,
    dropped_registration_id TEXT NOT NULL,
    email_key       TEXT        NOT NULL,
    match_type      TEXT        NOT NULL
                    CHECK (match_type IN ('exact_row','normalised_email','phone_and_name')),
    detected_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
