-- ============================================================================
-- HackTU -- OLAP star schema
--
-- Read-only analytical model. The Slack text-to-SQL agent is pointed at this
-- schema and *only* this schema: it is denormalised enough that a generated
-- query rarely needs more than one join, which is exactly what makes an LLM
-- reliable at writing against it. The dashboard reads from here too.
--
-- Grain:
--   fact_registration  -- one row per participant (post-dedupe)
--   fact_score         -- one row per (team, judge, criterion, round)
--   fact_pipeline_run  -- one row per ETL execution
-- ============================================================================

DROP SCHEMA IF EXISTS analytics CASCADE;
CREATE SCHEMA analytics;

SET search_path TO analytics, public;

-- ---------------------------------------------------------------------------
-- Dimensions
-- ---------------------------------------------------------------------------

CREATE TABLE analytics.dim_date (
    date_key        INTEGER     PRIMARY KEY,          -- YYYYMMDD
    full_date       DATE        NOT NULL UNIQUE,
    day_of_week     SMALLINT    NOT NULL,
    day_name        TEXT        NOT NULL,
    week_of_year    SMALLINT    NOT NULL,
    month_no        SMALLINT    NOT NULL,
    month_name      TEXT        NOT NULL,
    quarter_no      SMALLINT    NOT NULL,
    year_no         SMALLINT    NOT NULL,
    is_weekend      BOOLEAN     NOT NULL,
    -- Event-relative flags, so "how did registrations behave in the last week
    -- before close" is a WHERE clause and not a date-arithmetic puzzle.
    days_to_event   INTEGER,
    reg_window_phase TEXT       CHECK (reg_window_phase IN
                        ('pre_launch','launch_week','mid_campaign','final_week','post_close'))
);

CREATE TABLE analytics.dim_participant (
    participant_key SERIAL      PRIMARY KEY,
    participant_id  INTEGER     NOT NULL UNIQUE,      -- natural key from ops
    full_name       TEXT        NOT NULL,
    email           TEXT        NOT NULL,
    gender          TEXT,
    degree          TEXT,
    branch          TEXT,
    year_of_study   SMALLINT,
    graduation_year SMALLINT,
    experience_level TEXT,
    has_github      BOOLEAN     NOT NULL DEFAULT FALSE,
    tshirt_size     TEXT,
    dietary_preference TEXT,
    accommodation_required BOOLEAN,
    heard_from      TEXT,
    -- Was this person's registration folded from more than one raw submission?
    was_duplicated  BOOLEAN     NOT NULL DEFAULT FALSE
);

CREATE TABLE analytics.dim_college (
    college_key     SERIAL      PRIMARY KEY,
    college_id      INTEGER     NOT NULL UNIQUE,
    college_name    TEXT        NOT NULL,
    city            TEXT        NOT NULL,
    state           TEXT        NOT NULL,
    -- Pre-computed buckets the organisers actually slice by.
    is_host_college BOOLEAN     NOT NULL DEFAULT FALSE,
    region          TEXT        NOT NULL,
    is_local        BOOLEAN     NOT NULL DEFAULT FALSE   -- same state as venue
);

CREATE TABLE analytics.dim_track (
    track_key       SERIAL      PRIMARY KEY,
    track_id        INTEGER     NOT NULL UNIQUE,
    track_name      TEXT        NOT NULL,
    description     TEXT,
    capacity        INTEGER     NOT NULL
);

CREATE TABLE analytics.dim_team (
    team_key        SERIAL      PRIMARY KEY,
    team_id         INTEGER     NOT NULL UNIQUE,
    team_name       TEXT        NOT NULL,
    track_name      TEXT,
    assignment_method TEXT,
    status          TEXT        NOT NULL,
    team_size       SMALLINT    NOT NULL DEFAULT 0,
    has_submission  BOOLEAN     NOT NULL DEFAULT FALSE
);

CREATE TABLE analytics.dim_judge (
    judge_key       SERIAL      PRIMARY KEY,
    judge_id        INTEGER     NOT NULL UNIQUE,
    judge_name      TEXT        NOT NULL,
    organisation    TEXT,
    track_name      TEXT
);

-- ---------------------------------------------------------------------------
-- Facts
-- ---------------------------------------------------------------------------

CREATE TABLE analytics.fact_registration (
    registration_key    BIGSERIAL PRIMARY KEY,
    participant_key     INTEGER   NOT NULL REFERENCES analytics.dim_participant(participant_key),
    college_key         INTEGER   REFERENCES analytics.dim_college(college_key),
    preferred_track_key INTEGER   REFERENCES analytics.dim_track(track_key),
    assigned_track_key  INTEGER   REFERENCES analytics.dim_track(track_key),
    team_key            INTEGER   REFERENCES analytics.dim_team(team_key),
    date_key            INTEGER   NOT NULL REFERENCES analytics.dim_date(date_key),
    registered_at       TIMESTAMPTZ NOT NULL,
    -- Measures
    registration_count  SMALLINT  NOT NULL DEFAULT 1,
    source_row_count    SMALLINT  NOT NULL DEFAULT 1,
    duplicate_rows_folded SMALLINT NOT NULL DEFAULT 0,
    got_preferred_track BOOLEAN   NOT NULL DEFAULT FALSE,
    checked_in          BOOLEAN   NOT NULL DEFAULT FALSE,
    hours_to_deadline   NUMERIC(8,2)
);

CREATE TABLE analytics.fact_score (
    score_key       BIGSERIAL PRIMARY KEY,
    team_key        INTEGER   NOT NULL REFERENCES analytics.dim_team(team_key),
    judge_key       INTEGER   NOT NULL REFERENCES analytics.dim_judge(judge_key),
    track_key       INTEGER   REFERENCES analytics.dim_track(track_key),
    date_key        INTEGER   REFERENCES analytics.dim_date(date_key),
    criterion_name  TEXT      NOT NULL,
    round_no        SMALLINT  NOT NULL,
    raw_score       NUMERIC(5,2) NOT NULL,
    weight          NUMERIC(4,3) NOT NULL,
    weighted_score  NUMERIC(6,3) NOT NULL,
    max_score       SMALLINT  NOT NULL
);

CREATE TABLE analytics.fact_pipeline_run (
    run_key             BIGSERIAL PRIMARY KEY,
    run_id              BIGINT    NOT NULL UNIQUE,
    pipeline_name       TEXT      NOT NULL,
    date_key            INTEGER   REFERENCES analytics.dim_date(date_key),
    started_at          TIMESTAMPTZ NOT NULL,
    duration_seconds    NUMERIC(10,3),
    status              TEXT      NOT NULL,
    rows_extracted      INTEGER   NOT NULL DEFAULT 0,
    rows_rejected       INTEGER   NOT NULL DEFAULT 0,
    rows_deduplicated   INTEGER   NOT NULL DEFAULT 0,
    rows_loaded         INTEGER   NOT NULL DEFAULT 0,
    duplicate_rate_pct  NUMERIC(6,3),
    validation_failures INTEGER   NOT NULL DEFAULT 0,
    reject_rule_count   INTEGER   NOT NULL DEFAULT 0,
    warn_rule_count     INTEGER   NOT NULL DEFAULT 0
);

-- ---------------------------------------------------------------------------
-- Convenience views
--
-- The text-to-SQL agent is shown these alongside the tables. A view that
-- answers a whole class of question ("how many from each college") keeps the
-- generated SQL short, and short generated SQL is correct generated SQL.
-- ---------------------------------------------------------------------------

CREATE VIEW analytics.v_registrations_by_day AS
SELECT d.full_date,
       d.day_name,
       d.reg_window_phase,
       COUNT(*)                                      AS registrations,
       SUM(COUNT(*)) OVER (ORDER BY d.full_date)     AS cumulative_registrations
FROM analytics.fact_registration f
JOIN analytics.dim_date d ON d.date_key = f.date_key
GROUP BY d.full_date, d.day_name, d.reg_window_phase;

CREATE VIEW analytics.v_registrations_by_college AS
SELECT c.college_name,
       c.city,
       c.state,
       c.region,
       c.is_host_college,
       COUNT(*)                                   AS participants,
       COUNT(*) FILTER (WHERE f.checked_in)       AS checked_in,
       ROUND(AVG(f.source_row_count), 2)          AS avg_submissions_per_person
FROM analytics.fact_registration f
JOIN analytics.dim_college c ON c.college_key = f.college_key
GROUP BY c.college_name, c.city, c.state, c.region, c.is_host_college;

CREATE VIEW analytics.v_track_demand AS
SELECT t.track_name,
       t.capacity,
       COUNT(*) FILTER (WHERE f.preferred_track_key = t.track_key) AS preferred_by,
       COUNT(*) FILTER (WHERE f.assigned_track_key = t.track_key)  AS assigned_to,
       ROUND(100.0 * COUNT(*) FILTER (WHERE f.assigned_track_key = t.track_key)
             / NULLIF(t.capacity, 0), 1)                           AS capacity_used_pct
FROM analytics.dim_track t
LEFT JOIN analytics.fact_registration f
       ON t.track_key IN (f.preferred_track_key, f.assigned_track_key)
GROUP BY t.track_name, t.capacity, t.track_key;

CREATE VIEW analytics.v_pipeline_health AS
SELECT r.run_id,
       r.pipeline_name,
       r.started_at,
       r.duration_seconds,
       r.status,
       r.rows_extracted,
       r.rows_loaded,
       r.rows_rejected,
       r.rows_deduplicated,
       r.duplicate_rate_pct,
       r.validation_failures,
       ROUND(100.0 * r.rows_rejected / NULLIF(r.rows_extracted, 0), 3) AS reject_rate_pct
FROM analytics.fact_pipeline_run r
ORDER BY r.started_at DESC;

-- Mirrors ops.aggregate_scores(): average each criterion across the judges
-- who scored it, THEN sum the criteria. Summing raw cells instead would
-- make a team judged by four people out-score a better team judged by two.
-- The result is on a 0-100 scale.
CREATE VIEW analytics.v_leaderboard AS
WITH per_criterion AS (
    SELECT s.team_key,
           s.criterion_name,
           AVG(s.weighted_score)       AS criterion_score,
           COUNT(DISTINCT s.judge_key) AS judges
    FROM analytics.fact_score s
    WHERE s.round_no = 1
    GROUP BY s.team_key, s.criterion_name
)
SELECT t.team_name,
       t.track_name,
       t.team_size,
       t.status,
       ROUND(SUM(pc.criterion_score), 2) AS total_weighted_score,
       MAX(pc.judges)                    AS judges_scored,
       COUNT(*)                          AS criteria_scored,
       COUNT(*) = 5                      AS fully_judged
FROM per_criterion pc
JOIN analytics.dim_team t ON t.team_key = pc.team_key
GROUP BY t.team_name, t.track_name, t.team_size, t.status
ORDER BY total_weighted_score DESC;

-- ---------------------------------------------------------------------------
-- Data-quality views
--
-- The dashboard and the Slack bot both need the data-quality detail, and
-- both read as `hacktu_readonly`, which has no access to `ops` at all. So
-- the pipeline's quality signals are projected into `analytics` as views.
-- This keeps the read-only role genuinely confined to one schema instead of
-- being widened the first time something needed a column from elsewhere.
-- ---------------------------------------------------------------------------

CREATE OR REPLACE VIEW analytics.v_dq_rule_history AS
SELECT e.rule_name,
       e.severity,
       e.column_name,
       SUM(e.failure_count)                        AS total_failures,
       COUNT(*) FILTER (WHERE e.failure_count > 0) AS runs_triggered,
       COUNT(*)                                    AS runs_evaluated,
       MAX(e.failure_count)                        AS worst_run
FROM ops.data_quality_event e
GROUP BY e.rule_name, e.severity, e.column_name;

CREATE OR REPLACE VIEW analytics.v_dq_latest_run AS
SELECT e.run_id,
       e.rule_name,
       e.severity,
       e.column_name,
       e.failure_count,
       e.rows_checked,
       ROUND(100.0 * e.failure_count / NULLIF(e.rows_checked, 0), 2) AS failure_pct,
       e.sample_values
FROM ops.data_quality_event e
WHERE e.run_id = (SELECT MAX(run_id) FROM ops.etl_run
                   WHERE status IN ('success', 'partial'));

CREATE OR REPLACE VIEW analytics.v_duplicate_breakdown AS
SELECT d.run_id,
       d.match_type,
       COUNT(*) AS duplicates
FROM ops.duplicate_registration d
WHERE d.run_id = (SELECT MAX(run_id) FROM ops.etl_run
                   WHERE status IN ('success', 'partial'))
GROUP BY d.run_id, d.match_type;

CREATE OR REPLACE VIEW analytics.v_rejected_registration AS
SELECT r.run_id,
       r.source_registration_id,
       r.failed_rules,
       r.payload ->> 'full_name'    AS full_name,
       r.payload ->> 'email'        AS email,
       r.payload ->> 'college_name' AS college_name,
       r.payload ->> 'registered_at' AS registered_at
FROM ops.rejected_registration r
WHERE r.run_id = (SELECT MAX(run_id) FROM ops.etl_run
                   WHERE status IN ('success', 'partial'));
