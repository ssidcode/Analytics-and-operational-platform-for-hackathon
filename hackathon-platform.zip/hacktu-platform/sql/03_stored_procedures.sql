-- ============================================================================
-- HackTU -- stored procedures
--
-- Two pieces of logic live in the database rather than in Python:
--
--   ops.assign_tracks()     -- capacity-constrained track allocation
--   ops.aggregate_scores()  -- weighted score roll-up + ranking
--
-- Both are set-based and transactional. Track assignment in particular has
-- to be atomic: if it half-ran, some teams would hold a slot in a track
-- that is already full, and the only fix is a manual audit of 150 teams.
-- ============================================================================

SET search_path TO ops, public;

-- ---------------------------------------------------------------------------
-- ops.normalise_email(text) -> text
--
-- The identity function for a participant. Everything downstream -- dedupe,
-- the unique constraint, the duplicate audit table -- agrees on this.
--   * lower-cased, trimmed
--   * +tag stripped from the local part
--   * dots stripped from the local part for Gmail-family domains only
--     (Gmail ignores them; most other providers do not)
-- ---------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION ops.normalise_email(p_email TEXT)
RETURNS TEXT
LANGUAGE plpgsql
IMMUTABLE
AS $$
DECLARE
    v_clean  TEXT;
    v_local  TEXT;
    v_domain TEXT;
BEGIN
    IF p_email IS NULL THEN
        RETURN NULL;
    END IF;

    v_clean := lower(btrim(p_email));
    IF v_clean = '' OR position('@' IN v_clean) = 0 THEN
        RETURN NULLIF(v_clean, '');
    END IF;

    v_local  := split_part(v_clean, '@', 1);
    v_domain := split_part(v_clean, '@', 2);

    -- Drop the +tag.
    v_local := split_part(v_local, '+', 1);

    -- Gmail (and googlemail) ignore dots in the local part.
    IF v_domain IN ('gmail.com', 'googlemail.com') THEN
        v_local := replace(v_local, '.', '');
    END IF;

    IF v_local = '' THEN
        RETURN NULL;
    END IF;

    RETURN v_local || '@' || v_domain;
END;
$$;

COMMENT ON FUNCTION ops.normalise_email(TEXT) IS
'Canonical participant identity: lower/trim, strip +tag, strip dots for Gmail.';

-- ---------------------------------------------------------------------------
-- ops.normalise_college_name(text) -> text
-- ---------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION ops.normalise_college_name(p_name TEXT)
RETURNS TEXT
LANGUAGE sql
IMMUTABLE
AS $$
    SELECT NULLIF(
        regexp_replace(
            lower(btrim(coalesce(p_name, ''))),
            '[^a-z0-9]+', '', 'g'),
        '');
$$;

-- ---------------------------------------------------------------------------
-- ops.assign_tracks(p_dry_run boolean) -> table
--
-- Allocates every unassigned, non-withdrawn team to a track.
--
-- Policy, in order:
--   1. A team's track is the modal preferred track of its members; ties are
--      broken by which tied track has more headroom left.
--   2. Teams are served in registration order of their *leader* -- first
--      come, first served, which is the rule the organisers advertise.
--   3. A team that cannot fit in its preferred track (capacity reached in
--      team-units) overflows to the active track with the most remaining
--      headroom, and is marked 'balanced_overflow' so the count of people
--      who did not get their first choice is reportable rather than hidden.
--
-- Capacity is counted in *participants*, not teams, because that is what the
-- venue and the mentor rota are actually sized against.
--
-- Returns a per-track summary. With p_dry_run => true nothing is written,
-- which is what the Slack bot's `/assign-tracks preview` calls.
-- ---------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION ops.assign_tracks(p_dry_run BOOLEAN DEFAULT FALSE)
RETURNS TABLE (
    track_name          TEXT,
    capacity            INTEGER,
    teams_assigned      INTEGER,
    participants_assigned INTEGER,
    by_preference       INTEGER,
    by_overflow         INTEGER,
    headroom            INTEGER
)
LANGUAGE plpgsql
AS $$
DECLARE
    v_team          RECORD;
    v_target        INTEGER;
    v_method        TEXT;
    v_size          INTEGER;
BEGIN
    -- Working set: live capacity per track, seeded with teams already placed.
    CREATE TEMP TABLE _cap ON COMMIT DROP AS
    SELECT t.track_id,
           t.track_name,
           t.capacity,
           COALESCE(used.n, 0)::INTEGER AS used
    FROM ops.track t
    LEFT JOIN (
        SELECT tm_team.track_id, COUNT(m.participant_id)::INTEGER AS n
        FROM ops.team tm_team
        JOIN ops.team_member m ON m.team_id = tm_team.team_id
        WHERE tm_team.track_id IS NOT NULL
        GROUP BY tm_team.track_id
    ) used ON used.track_id = t.track_id
    WHERE t.is_active;

    CREATE TEMP TABLE _assignment (
        team_id   INTEGER PRIMARY KEY,
        track_id  INTEGER NOT NULL,
        method    TEXT    NOT NULL,
        team_size INTEGER NOT NULL
    ) ON COMMIT DROP;

    -- Teams needing a track, ordered by their leader's registration time.
    FOR v_team IN
        SELECT tm.team_id,
               COUNT(m.participant_id)::INTEGER AS team_size,
               MIN(p_lead.registered_at)        AS leader_registered_at,
               -- Modal preferred track among members.
               (SELECT p2.preferred_track_id
                  FROM ops.team_member m2
                  JOIN ops.participant p2 ON p2.participant_id = m2.participant_id
                 WHERE m2.team_id = tm.team_id
                   AND p2.preferred_track_id IS NOT NULL
                 GROUP BY p2.preferred_track_id
                 ORDER BY COUNT(*) DESC, p2.preferred_track_id
                 LIMIT 1)                       AS modal_track_id
        FROM ops.team tm
        JOIN ops.team_member m  ON m.team_id = tm.team_id
        LEFT JOIN ops.participant p_lead
               ON p_lead.participant_id = m.participant_id AND m.is_leader
        WHERE tm.track_id IS NULL
          AND tm.status NOT IN ('withdrawn', 'disqualified')
        GROUP BY tm.team_id
        ORDER BY MIN(p_lead.registered_at) NULLS LAST, tm.team_id
    LOOP
        v_size   := GREATEST(v_team.team_size, 1);
        v_target := NULL;
        v_method := NULL;

        -- 1. Preferred track, if it still has room for the whole team.
        IF v_team.modal_track_id IS NOT NULL THEN
            SELECT c.track_id INTO v_target
            FROM _cap c
            WHERE c.track_id = v_team.modal_track_id
              AND c.used + v_size <= c.capacity;
            IF FOUND AND v_target IS NOT NULL THEN
                v_method := 'preference';
            END IF;
        END IF;

        -- 2. Overflow to the emptiest active track that can hold the team.
        IF v_target IS NULL THEN
            SELECT c.track_id INTO v_target
            FROM _cap c
            WHERE c.used + v_size <= c.capacity
            ORDER BY (c.capacity - c.used) DESC, c.track_id
            LIMIT 1;
            v_method := 'balanced_overflow';
        END IF;

        -- 3. Nothing fits anywhere: leave unassigned for a human to triage
        --    rather than silently overfilling a room.
        IF v_target IS NULL THEN
            CONTINUE;
        END IF;

        INSERT INTO _assignment (team_id, track_id, method, team_size)
        VALUES (v_team.team_id, v_target, v_method, v_size);

        UPDATE _cap SET used = used + v_size WHERE track_id = v_target;
    END LOOP;

    IF NOT p_dry_run THEN
        UPDATE ops.team t
        SET track_id          = a.track_id,
            assignment_method = a.method,
            assigned_at       = now()
        FROM _assignment a
        WHERE a.team_id = t.team_id;
    END IF;

    RETURN QUERY
    SELECT c.track_name,
           c.capacity,
           COALESCE(s.teams, 0)::INTEGER,
           COALESCE(s.people, 0)::INTEGER,
           COALESCE(s.pref, 0)::INTEGER,
           COALESCE(s.over, 0)::INTEGER,
           (c.capacity - c.used)::INTEGER
    FROM _cap c
    LEFT JOIN (
        SELECT a.track_id,
               COUNT(*)::INTEGER                                              AS teams,
               SUM(a.team_size)::INTEGER                                      AS people,
               COUNT(*) FILTER (WHERE a.method = 'preference')::INTEGER       AS pref,
               COUNT(*) FILTER (WHERE a.method = 'balanced_overflow')::INTEGER AS over
        FROM _assignment a
        GROUP BY a.track_id
    ) s ON s.track_id = c.track_id
    ORDER BY c.track_name;
END;
$$;

COMMENT ON FUNCTION ops.assign_tracks(BOOLEAN) IS
'Capacity-constrained track allocation: modal member preference, FCFS by leader, overflow to emptiest track.';

-- ---------------------------------------------------------------------------
-- ops.aggregate_scores(p_round smallint) -> table
--
-- Rolls raw per-criterion judge scores into one weighted score per team and
-- ranks them overall and within track. Writes ops.team_result.
--
-- Handling that matters:
--   * Judges score on different scales per criterion (max_score), so each
--     raw score is normalised to [0,1] before weighting.
--   * A team scored by 3 judges and a team scored by 1 are not comparable on
--     a SUM, so the roll-up averages across judges, then weights.
--   * A team missing a criterion is flagged is_complete = false and still
--     ranked, but the flag is surfaced on the leaderboard so nobody awards a
--     prize off a half-judged row.
-- ---------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION ops.aggregate_scores(p_round SMALLINT DEFAULT 1)
RETURNS TABLE (
    team_id         INTEGER,
    team_name       TEXT,
    track_name      TEXT,
    weighted_score  NUMERIC,
    judges_scored   INTEGER,
    criteria_scored INTEGER,
    is_complete     BOOLEAN,
    overall_rank    INTEGER,
    track_rank      INTEGER
)
LANGUAGE plpgsql
AS $$
-- The RETURNS TABLE column names (team_id, team_name, ...) collide with real
-- column names inside the query body. Resolve such references to the column,
-- which is what every one of them means here.
#variable_conflict use_column
DECLARE
    v_weight_sum   NUMERIC;
    v_criteria_n   INTEGER;
BEGIN
    SELECT COALESCE(SUM(c.weight), 0), COUNT(*)
      INTO v_weight_sum, v_criteria_n
      FROM ops.scoring_criterion c
     WHERE c.is_active;

    IF v_criteria_n = 0 THEN
        RAISE EXCEPTION 'No active scoring criteria configured';
    END IF;

    -- A rubric whose weights do not sum to 1 produces scores that are not
    -- comparable across rounds. Fail loudly instead of ranking on nonsense.
    IF abs(v_weight_sum - 1.0) > 0.001 THEN
        RAISE EXCEPTION
            'Active scoring criteria weights sum to %, expected 1.000', v_weight_sum;
    END IF;

    RETURN QUERY
    WITH per_criterion AS (
        -- Average across judges first, per criterion, on a normalised scale.
        SELECT s.team_id,
               s.criterion_id,
               AVG(s.raw_score / NULLIF(sc.max_score, 0)) AS norm_score,
               MAX(sc.weight)                             AS weight,
               COUNT(DISTINCT s.judge_id)                 AS judges
        FROM ops.score s
        JOIN ops.scoring_criterion sc ON sc.criterion_id = s.criterion_id
        WHERE s.round_no = p_round
          AND sc.is_active
        GROUP BY s.team_id, s.criterion_id
    ),
    per_team AS (
        SELECT pc.team_id,
               -- Weighted, then scaled to a readable 0-100.
               ROUND(SUM(pc.norm_score * pc.weight) * 100, 3) AS weighted_score,
               MAX(pc.judges)::INTEGER                        AS judges_scored,
               COUNT(*)::INTEGER                              AS criteria_scored
        FROM per_criterion pc
        GROUP BY pc.team_id
    ),
    ranked AS (
        SELECT pt.team_id,
               t.team_name,
               tr.track_name,
               pt.weighted_score,
               pt.judges_scored,
               pt.criteria_scored,
               (pt.criteria_scored = v_criteria_n) AS is_complete,
               RANK() OVER (ORDER BY pt.weighted_score DESC)::INTEGER AS overall_rank,
               RANK() OVER (PARTITION BY tr.track_id
                            ORDER BY pt.weighted_score DESC)::INTEGER AS track_rank
        FROM per_team pt
        JOIN ops.team t  ON t.team_id = pt.team_id
        LEFT JOIN ops.track tr ON tr.track_id = t.track_id
        WHERE t.status NOT IN ('withdrawn', 'disqualified')
    ),
    upserted AS (
        INSERT INTO ops.team_result AS res (
            team_id, round_no, weighted_score, judges_scored,
            criteria_scored, is_complete, overall_rank, track_rank, computed_at)
        SELECT r.team_id, p_round, r.weighted_score, r.judges_scored,
               r.criteria_scored, r.is_complete, r.overall_rank, r.track_rank, now()
        FROM ranked r
        ON CONFLICT (team_id) DO UPDATE
        SET round_no        = EXCLUDED.round_no,
            weighted_score  = EXCLUDED.weighted_score,
            judges_scored   = EXCLUDED.judges_scored,
            criteria_scored = EXCLUDED.criteria_scored,
            is_complete     = EXCLUDED.is_complete,
            overall_rank    = EXCLUDED.overall_rank,
            track_rank      = EXCLUDED.track_rank,
            computed_at     = now()
        RETURNING res.team_id
    )
    SELECT r.team_id, r.team_name, r.track_name, r.weighted_score,
           r.judges_scored, r.criteria_scored, r.is_complete,
           r.overall_rank, r.track_rank
    FROM ranked r
    WHERE EXISTS (SELECT 1 FROM upserted u WHERE u.team_id = r.team_id)
    ORDER BY r.overall_rank, r.team_name;
END;
$$;

COMMENT ON FUNCTION ops.aggregate_scores(SMALLINT) IS
'Weighted leaderboard roll-up: normalise by criterion max, average across judges, weight, rank overall + per track.';

-- ---------------------------------------------------------------------------
-- ops.refresh_star_schema() -- rebuild the analytics layer from ops.
--
-- Full rebuild rather than incremental: the whole dataset is ~550 rows and a
-- rebuild takes well under a second, so the complexity of change-tracking
-- buys nothing here. Runs inside one transaction so readers never see a
-- half-populated star.
-- ---------------------------------------------------------------------------

CREATE OR REPLACE PROCEDURE ops.refresh_star_schema(
    p_event_start DATE DEFAULT DATE '2026-02-20',
    p_reg_close   DATE DEFAULT DATE '2026-02-18',
    p_host_state  TEXT DEFAULT 'Punjab',
    p_host_college TEXT DEFAULT 'Thapar Institute of Engineering and Technology'
)
LANGUAGE plpgsql
AS $$
BEGIN
    TRUNCATE analytics.fact_registration, analytics.fact_score,
             analytics.fact_pipeline_run RESTART IDENTITY;
    TRUNCATE analytics.dim_participant, analytics.dim_college,
             analytics.dim_track, analytics.dim_team, analytics.dim_judge,
             analytics.dim_date RESTART IDENTITY CASCADE;

    -- dim_date spans the registration window through the event.
    INSERT INTO analytics.dim_date (
        date_key, full_date, day_of_week, day_name, week_of_year,
        month_no, month_name, quarter_no, year_no, is_weekend,
        days_to_event, reg_window_phase)
    SELECT to_char(d, 'YYYYMMDD')::INTEGER,
           d::DATE,
           EXTRACT(ISODOW FROM d),
           trim(to_char(d, 'Day')),
           EXTRACT(WEEK FROM d),
           EXTRACT(MONTH FROM d),
           trim(to_char(d, 'Month')),
           EXTRACT(QUARTER FROM d),
           EXTRACT(YEAR FROM d),
           EXTRACT(ISODOW FROM d) >= 6,
           (p_event_start - d::DATE),
           CASE
               WHEN d::DATE > p_reg_close                       THEN 'post_close'
               WHEN p_reg_close - d::DATE <= 7                  THEN 'final_week'
               WHEN d::DATE < DATE '2026-01-05'                 THEN 'pre_launch'
               WHEN d::DATE - DATE '2026-01-05' <= 7            THEN 'launch_week'
               ELSE 'mid_campaign'
           END
    -- Spans well past the event: fact_pipeline_run joins dim_date on the run
    -- timestamp, and the pipeline keeps running (re-ingests, backfills) long
    -- after the hackathon is over.
    FROM generate_series(DATE '2025-12-01',
                         GREATEST(p_event_start + 365, CURRENT_DATE + 90),
                         INTERVAL '1 day') d;

    INSERT INTO analytics.dim_track (track_id, track_name, description, capacity)
    SELECT track_id, track_name, description, capacity FROM ops.track;

    INSERT INTO analytics.dim_college (
        college_id, college_name, city, state, is_host_college, region, is_local)
    SELECT c.college_id,
           c.college_name,
           c.city,
           c.state,
           c.college_name = p_host_college,
           CASE c.state
               WHEN 'Punjab' THEN 'North'      WHEN 'Haryana' THEN 'North'
               WHEN 'Delhi' THEN 'North'       WHEN 'Chandigarh' THEN 'North'
               WHEN 'Uttar Pradesh' THEN 'North' WHEN 'Uttarakhand' THEN 'North'
               WHEN 'Rajasthan' THEN 'North'
               WHEN 'Maharashtra' THEN 'West'  WHEN 'Gujarat' THEN 'West'
               WHEN 'Karnataka' THEN 'South'   WHEN 'Tamil Nadu' THEN 'South'
               WHEN 'Kerala' THEN 'South'      WHEN 'Telangana' THEN 'South'
               WHEN 'Andhra Pradesh' THEN 'South'
               WHEN 'West Bengal' THEN 'East'  WHEN 'Odisha' THEN 'East'
               WHEN 'Jharkhand' THEN 'East'    WHEN 'Assam' THEN 'East'
               ELSE 'Other'
           END,
           c.state = p_host_state
    FROM ops.college c;

    INSERT INTO analytics.dim_participant (
        participant_id, full_name, email, gender, degree, branch,
        year_of_study, graduation_year, experience_level, has_github,
        tshirt_size, dietary_preference, accommodation_required,
        heard_from, was_duplicated)
    SELECT p.participant_id, p.full_name, p.email::TEXT, p.gender, p.degree,
           p.branch, p.year_of_study, p.graduation_year, p.experience_level,
           COALESCE(p.github_handle, '') <> '', p.tshirt_size,
           p.dietary_preference, p.accommodation_required, p.heard_from,
           p.source_row_count > 1
    FROM ops.participant p;

    INSERT INTO analytics.dim_team (
        team_id, team_name, track_name, assignment_method, status,
        team_size, has_submission)
    SELECT t.team_id, t.team_name, tr.track_name, t.assignment_method, t.status,
           COALESCE(m.n, 0),
           EXISTS (SELECT 1 FROM ops.submission s WHERE s.team_id = t.team_id)
    FROM ops.team t
    LEFT JOIN ops.track tr ON tr.track_id = t.track_id
    LEFT JOIN (SELECT team_id, COUNT(*)::SMALLINT AS n
               FROM ops.team_member GROUP BY team_id) m ON m.team_id = t.team_id;

    INSERT INTO analytics.dim_judge (judge_id, judge_name, organisation, track_name)
    SELECT j.judge_id, j.judge_name, j.organisation, tr.track_name
    FROM ops.judge j
    LEFT JOIN ops.track tr ON tr.track_id = j.track_id;

    INSERT INTO analytics.fact_registration (
        participant_key, college_key, preferred_track_key, assigned_track_key,
        team_key, date_key, registered_at, registration_count, source_row_count,
        duplicate_rows_folded, got_preferred_track, checked_in, hours_to_deadline)
    SELECT dp.participant_key,
           dc.college_key,
           dtp.track_key,
           dta.track_key,
           dteam.team_key,
           to_char(p.registered_at, 'YYYYMMDD')::INTEGER,
           p.registered_at,
           1,
           p.source_row_count,
           GREATEST(p.source_row_count - 1, 0),
           -- Teams are assigned later than registration, so assigned_track is
           -- NULL for most of the window. NULL means "not yet", not "no".
           COALESCE(dtp.track_key IS NOT NULL AND dtp.track_key = dta.track_key,
                    FALSE),
           EXISTS (SELECT 1 FROM ops.check_in ci
                    WHERE ci.participant_id = p.participant_id),
           ROUND(EXTRACT(EPOCH FROM
                 ((p_reg_close + TIME '23:59') - p.registered_at)) / 3600.0, 2)
    FROM ops.participant p
    LEFT JOIN analytics.dim_participant dp ON dp.participant_id = p.participant_id
    LEFT JOIN analytics.dim_college dc     ON dc.college_id = p.college_id
    LEFT JOIN analytics.dim_track dtp      ON dtp.track_id = p.preferred_track_id
    LEFT JOIN ops.team_member tm           ON tm.participant_id = p.participant_id
    LEFT JOIN ops.team t                   ON t.team_id = tm.team_id
    LEFT JOIN analytics.dim_team dteam     ON dteam.team_id = t.team_id
    LEFT JOIN analytics.dim_track dta      ON dta.track_id = t.track_id;

    INSERT INTO analytics.fact_score (
        team_key, judge_key, track_key, date_key, criterion_name,
        round_no, raw_score, weight, weighted_score, max_score)
    SELECT dteam.team_key,
           dj.judge_key,
           dtr.track_key,
           to_char(s.scored_at, 'YYYYMMDD')::INTEGER,
           sc.criterion_name,
           s.round_no,
           s.raw_score,
           sc.weight,
           ROUND((s.raw_score / NULLIF(sc.max_score, 0)) * sc.weight * 100, 3),
           sc.max_score
    FROM ops.score s
    JOIN ops.scoring_criterion sc      ON sc.criterion_id = s.criterion_id
    JOIN ops.team t                    ON t.team_id = s.team_id
    JOIN analytics.dim_team dteam      ON dteam.team_id = s.team_id
    JOIN analytics.dim_judge dj        ON dj.judge_id = s.judge_id
    LEFT JOIN analytics.dim_track dtr  ON dtr.track_id = t.track_id;

    INSERT INTO analytics.fact_pipeline_run (
        run_id, pipeline_name, date_key, started_at, duration_seconds, status,
        rows_extracted, rows_rejected, rows_deduplicated, rows_loaded,
        duplicate_rate_pct, validation_failures, reject_rule_count, warn_rule_count)
    SELECT r.run_id,
           r.pipeline_name,
           to_char(r.started_at, 'YYYYMMDD')::INTEGER,
           r.started_at,
           r.duration_seconds,
           r.status,
           r.rows_extracted,
           r.rows_rejected,
           r.rows_deduplicated,
           r.rows_loaded,
           r.duplicate_rate_pct,
           COALESCE(q.total_failures, 0),
           COALESCE(q.reject_rules, 0),
           COALESCE(q.warn_rules, 0)
    FROM ops.etl_run r
    LEFT JOIN (
        SELECT run_id,
               SUM(failure_count)::INTEGER                                AS total_failures,
               COUNT(*) FILTER (WHERE severity = 'reject'
                                  AND failure_count > 0)::INTEGER         AS reject_rules,
               COUNT(*) FILTER (WHERE severity = 'warn'
                                  AND failure_count > 0)::INTEGER         AS warn_rules
        FROM ops.data_quality_event
        GROUP BY run_id
    ) q ON q.run_id = r.run_id;
END;
$$;
