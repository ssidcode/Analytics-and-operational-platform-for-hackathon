-- ============================================================================
-- HackTU -- indexes
--
-- Deliberately a separate migration from the table definitions so the
-- benchmark harness can measure the same query set with and without them
-- (benchmarks/bench_indexes.py drops and recreates exactly this file).
--
-- Each index below exists because a specific query in the dashboard, the
-- ETL, or the Slack agent's generated SQL was reading more pages than it
-- needed to. The comment on each one names that query.
-- ============================================================================

SET search_path TO ops, public;

-- --------------------------------------------------------------------------
-- OLTP
-- --------------------------------------------------------------------------

-- ETL dedupe probe: "does this email_key already exist?", once per raw row.
-- (The UNIQUE constraint already provides this; stated here for the record.)

-- Registration-trend queries filter and group on the timestamp.
CREATE INDEX IF NOT EXISTS ix_participant_registered_at
    ON ops.participant (registered_at);

-- "How many from <college>", and the college leaderboard on the dashboard.
CREATE INDEX IF NOT EXISTS ix_participant_college
    ON ops.participant (college_id);

-- Track-demand queries, and the modal-preference subquery inside
-- ops.assign_tracks().
CREATE INDEX IF NOT EXISTS ix_participant_preferred_track
    ON ops.participant (preferred_track_id);

-- Covering index for the single most common dashboard query: registrations
-- per day per track. Lets the planner answer from the index alone.
CREATE INDEX IF NOT EXISTS ix_participant_regdate_track_covering
    ON ops.participant (registered_at, preferred_track_id)
    INCLUDE (college_id, year_of_study);

-- Fuzzy name search -- the Slack agent's "find the participant called
-- Simran from Thapar" path, which is ILIKE '%...%' and therefore unindexable
-- without trigrams.
CREATE INDEX IF NOT EXISTS ix_participant_name_trgm
    ON ops.participant USING gin (full_name gin_trgm_ops);

CREATE INDEX IF NOT EXISTS ix_college_name_trgm
    ON ops.college USING gin (college_name gin_trgm_ops);

-- Team membership is walked from both ends: "who is on this team" and
-- "what team is this person on". The PK covers the first, this the second.
CREATE INDEX IF NOT EXISTS ix_team_member_participant
    ON ops.team_member (participant_id);

CREATE INDEX IF NOT EXISTS ix_team_track
    ON ops.team (track_id) WHERE track_id IS NOT NULL;

-- ops.assign_tracks() scans for unassigned teams on every invocation.
CREATE INDEX IF NOT EXISTS ix_team_unassigned
    ON ops.team (status) WHERE track_id IS NULL;

-- ops.aggregate_scores() groups scores by (team, criterion) within a round.
CREATE INDEX IF NOT EXISTS ix_score_round_team
    ON ops.score (round_no, team_id, criterion_id);

CREATE INDEX IF NOT EXISTS ix_score_judge
    ON ops.score (judge_id);

-- --------------------------------------------------------------------------
-- Pipeline observability
--
-- The dashboard's health tab is "last N runs, newest first" plus a
-- per-run drill-down into failed rules.
-- --------------------------------------------------------------------------

CREATE INDEX IF NOT EXISTS ix_etl_run_started
    ON ops.etl_run (started_at DESC);

CREATE INDEX IF NOT EXISTS ix_etl_run_pipeline_started
    ON ops.etl_run (pipeline_name, started_at DESC);

CREATE INDEX IF NOT EXISTS ix_dq_event_run
    ON ops.data_quality_event (run_id, severity);

CREATE INDEX IF NOT EXISTS ix_dq_event_rule
    ON ops.data_quality_event (rule_name, detected_at DESC);

CREATE INDEX IF NOT EXISTS ix_rejected_run
    ON ops.rejected_registration (run_id);

CREATE INDEX IF NOT EXISTS ix_duplicate_run
    ON ops.duplicate_registration (run_id, match_type);

CREATE INDEX IF NOT EXISTS ix_duplicate_email_key
    ON ops.duplicate_registration (email_key);

-- --------------------------------------------------------------------------
-- OLAP star schema
--
-- Classic star-join support: an index on every foreign key of every fact
-- table, so the planner can pick hash joins over dimension scans, plus the
-- date key which nearly every query filters on.
-- --------------------------------------------------------------------------

SET search_path TO analytics, public;

CREATE INDEX IF NOT EXISTS ix_fact_reg_date
    ON analytics.fact_registration (date_key);

CREATE INDEX IF NOT EXISTS ix_fact_reg_college
    ON analytics.fact_registration (college_key);

CREATE INDEX IF NOT EXISTS ix_fact_reg_pref_track
    ON analytics.fact_registration (preferred_track_key);

CREATE INDEX IF NOT EXISTS ix_fact_reg_assigned_track
    ON analytics.fact_registration (assigned_track_key);

CREATE INDEX IF NOT EXISTS ix_fact_reg_team
    ON analytics.fact_registration (team_key);

CREATE INDEX IF NOT EXISTS ix_fact_reg_participant
    ON analytics.fact_registration (participant_key);

-- The registration-trend chart: group by date, no table touch needed.
CREATE INDEX IF NOT EXISTS ix_fact_reg_date_covering
    ON analytics.fact_registration (date_key)
    INCLUDE (registration_count, source_row_count, checked_in);

CREATE INDEX IF NOT EXISTS ix_fact_score_team
    ON analytics.fact_score (team_key, round_no);

CREATE INDEX IF NOT EXISTS ix_fact_score_judge
    ON analytics.fact_score (judge_key);

CREATE INDEX IF NOT EXISTS ix_fact_score_track
    ON analytics.fact_score (track_key);

CREATE INDEX IF NOT EXISTS ix_fact_pipeline_started
    ON analytics.fact_pipeline_run (started_at DESC);

CREATE INDEX IF NOT EXISTS ix_dim_college_state
    ON analytics.dim_college (state);

CREATE INDEX IF NOT EXISTS ix_dim_college_name_trgm
    ON analytics.dim_college USING gin (college_name gin_trgm_ops);

CREATE INDEX IF NOT EXISTS ix_dim_participant_name_trgm
    ON analytics.dim_participant USING gin (full_name gin_trgm_ops);
