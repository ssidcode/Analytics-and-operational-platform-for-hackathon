-- ============================================================================
-- HackTU -- read-only role for the Slack assistant
--
-- This is the outermost layer of the text-to-SQL safety story, and the only
-- one that does not depend on the application being correct. Even if the
-- SQL guard in slackbot/sql_guard.py were bypassed entirely, the connection
-- the agent holds cannot write, cannot reach the OLTP schema, and cannot run
-- a query for longer than eight seconds.
--
-- Layers, outermost first:
--   1. this role              -- SELECT on `analytics` only, read-only txn
--   2. statement_timeout      -- a runaway query dies on its own
--   3. sql_guard.py           -- AST-level allowlist before anything is sent
--   4. LIMIT injection        -- result sets are capped
-- ============================================================================

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'hacktu_readonly') THEN
        CREATE ROLE hacktu_readonly LOGIN PASSWORD 'hacktu_ro_dev';
    END IF;
END $$;

REVOKE ALL ON DATABASE hacktu FROM hacktu_readonly;
GRANT CONNECT ON DATABASE hacktu TO hacktu_readonly;

-- No access to public or to the transactional schema at all. A generated
-- query that mentions ops.participant fails at the permission check.
REVOKE ALL ON SCHEMA public, ops, analytics FROM hacktu_readonly;

GRANT USAGE  ON SCHEMA analytics TO hacktu_readonly;
GRANT SELECT ON ALL TABLES IN SCHEMA analytics TO hacktu_readonly;
ALTER DEFAULT PRIVILEGES IN SCHEMA analytics
    GRANT SELECT ON TABLES TO hacktu_readonly;

-- A question asked in Slack should never hold a connection open; if it takes
-- longer than this, the query is wrong, not slow.
ALTER ROLE hacktu_readonly SET statement_timeout = '8s';
ALTER ROLE hacktu_readonly SET default_transaction_read_only = on;
ALTER ROLE hacktu_readonly SET search_path = analytics;
